import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Monitor,
  Zap,
  Shield,
  Users,
  Sparkles,
  CheckCircle,
  Globe,
  TrendingUp,
  Clock,
  Heart,
  Award,
  Layers,
  Smartphone,
  Lock,
  BarChart3,
  Calendar,
  MessageCircle,
  ExternalLink,
  Rocket,
  Star,
  ArrowRight
} from "lucide-react";
import { motion } from "framer-motion";

const FeatureCard = ({ icon: Icon, title, description, color, bgColor }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    whileHover={{ y: -8, scale: 1.02 }}
    transition={{ duration: 0.3 }}
  >
    <Card className="border-none shadow-xl hover:shadow-2xl transition-all h-full">
      <CardContent className="p-6">
        <div className={`p-4 rounded-2xl ${bgColor} w-fit mb-4`}>
          <Icon className={`w-8 h-8 ${color}`} />
        </div>
        <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  </motion.div>
);

const StatCard = ({ number, label, icon: Icon }) => (
  <motion.div
    initial={{ opacity: 0, scale: 0.9 }}
    animate={{ opacity: 1, scale: 1 }}
    whileHover={{ scale: 1.05 }}
    transition={{ duration: 0.2 }}
  >
    <Card className="border-none shadow-lg bg-white">
      <CardContent className="p-6 text-center">
        <Icon className="w-8 h-8 text-blue-600 mx-auto mb-3" />
        <p className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
          {number}
        </p>
        <p className="text-gray-600 font-medium">{label}</p>
      </CardContent>
    </Card>
  </motion.div>
);

const ProfessionCard = ({ rank, title, description, count }) => {
  const colors = {
    1: "from-yellow-400 to-orange-500",
    2: "from-gray-400 to-gray-500",
    3: "from-amber-600 to-yellow-700",
    4: "from-blue-500 to-purple-500",
    5: "from-purple-500 to-pink-500"
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: rank * 0.1 }}
    >
      <Card className="border-none shadow-lg hover:shadow-xl transition-all">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colors[rank]} flex items-center justify-center text-white font-bold text-xl shadow-lg`}>
              {rank}
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-gray-900 mb-1">{title}</h3>
              <p className="text-sm text-gray-600">{description}</p>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-blue-600">{count}</p>
              <p className="text-xs text-gray-500">profissões</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function WebsiteBuilder() {
  const features = [
    {
      icon: Zap,
      title: "Criação Rápida",
      description: "Crie seu site profissional em minutos com templates prontos",
      color: "text-yellow-600",
      bgColor: "bg-yellow-50"
    },
    {
      icon: Layers,
      title: "Templates por Profissão",
      description: "Modelos específicos para cada área de atuação",
      color: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      icon: Shield,
      title: "Seguro e Confiável",
      description: "HTTPS automático, backups diários e proteção LGPD",
      color: "text-emerald-600",
      bgColor: "bg-emerald-50"
    },
    {
      icon: Users,
      title: "Acessibilidade Total",
      description: "Feito para todos, incluindo idosos e pessoas com deficiência",
      color: "text-purple-600",
      bgColor: "bg-purple-50"
    }
  ];

  const resources = [
    "Editor visual drag & drop intuitivo",
    "Integração com redes sociais e WhatsApp",
    "Domínio próprio personalizado",
    "Dashboard com estatísticas detalhadas",
    "Sistema de agendamentos e formulários",
    "Hospedagem automática incluída"
  ];

  const professions = [
    {
      rank: 1,
      title: "Saúde",
      description: "Profissionais da área da saúde e bem-estar",
      count: "10"
    },
    {
      rank: 2,
      title: "Educação",
      description: "Professores, pedagogos e profissionais da educação",
      count: "10"
    },
    {
      rank: 3,
      title: "Administração e Negócios",
      description: "Gestores, administradores e profissionais de negócios",
      count: "10"
    },
    {
      rank: 4,
      title: "Tecnologia e Inovação",
      description: "Desenvolvedores, programadores e profissionais de TI",
      count: "10"
    },
    {
      rank: 5,
      title: "Engenharia e Construção",
      description: "Engenheiros, arquitetos e profissionais da construção",
      count: "10"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50/50 via-purple-50/50 to-pink-50/50">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 opacity-10" />
        <div className="relative max-w-7xl mx-auto px-4 py-16 md:py-24">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <Badge className="bg-gradient-to-r from-blue-500 to-purple-500 text-white text-base px-6 py-2 mb-6">
              <Sparkles className="w-4 h-4 mr-2" />
              Plataforma Universal de Sites Profissionais
            </Badge>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                Crie Seu Site
              </span>
              <br />
              <span className="text-gray-900">Profissional em Minutos</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-4xl mx-auto">
              Democratize sua presença digital. Templates personalizados para todas as profissões,
              editor intuitivo e acessibilidade completa.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="https://construindosonhosweb.com.br/home" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-2xl h-16 px-12 text-lg">
                  <Rocket className="w-6 h-6 mr-3" />
                  Criar Meu Site Agora
                  <ArrowRight className="w-6 h-6 ml-3" />
                </Button>
              </a>
              
              <a 
                href="https://construindosonhosweb.com.br/dashboard" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button size="lg" variant="outline" className="h-16 px-12 text-lg border-2 border-purple-300 hover:bg-purple-50">
                  <Monitor className="w-6 h-6 mr-3" />
                  Meus Sites
                </Button>
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-gradient-to-r from-blue-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <StatCard number="8+" label="Áreas Profissionais" icon={Award} />
            <StatCard number="100+" label="Profissões Cobertas" icon={Users} />
            <StatCard number="99%" label="Disponibilidade" icon={TrendingUp} />
            <StatCard number="24/7" label="Suporte" icon={Clock} />
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 py-16">
        {/* Why Choose Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Por Que Escolher o Construindo Sonhos Web?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Tudo que você precisa para ter uma presença digital profissional
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, idx) => (
              <FeatureCard key={idx} {...feature} />
            ))}
          </div>
        </motion.div>

        {/* Resources Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mb-20"
        >
          <Card className="border-none shadow-2xl overflow-hidden">
            <div className="grid lg:grid-cols-2 gap-8">
              <div className="p-8 lg:p-12">
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                  Recursos Poderosos Incluídos
                </h2>
                <p className="text-lg text-gray-600 mb-8">
                  Tudo que você precisa para se destacar online, sem complicação
                </p>
                
                <div className="space-y-4">
                  {resources.map((resource, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.4 + idx * 0.1 }}
                      className="flex items-center gap-3"
                    >
                      <div className="p-2 rounded-lg bg-emerald-100">
                        <CheckCircle className="w-5 h-5 text-emerald-600" />
                      </div>
                      <span className="text-gray-700 font-medium">{resource}</span>
                    </motion.div>
                  ))}
                </div>
              </div>

              <div className="bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 p-8 lg:p-12 flex items-center justify-center">
                <div className="text-center text-white">
                  <Globe className="w-32 h-32 mx-auto mb-6 opacity-20" />
                  <h3 className="text-3xl font-bold mb-4">Para Todas as Profissões</h3>
                  <p className="text-xl opacity-90">
                    Saúde, Educação, Tecnologia, Engenharia, Arte, Direito e muito mais
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Top Professions Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-base px-6 py-2 mb-4">
              <Star className="w-4 h-4 mr-2" />
              Mais Populares
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Top 5 Áreas por Número de Profissões
            </h2>
          </div>

          <div className="grid gap-6 max-w-4xl mx-auto">
            {professions.map((profession) => (
              <ProfessionCard key={profession.rank} {...profession} />
            ))}
          </div>
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="border-none shadow-2xl bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white overflow-hidden">
            <CardContent className="p-12 text-center">
              <Sparkles className="w-16 h-16 mx-auto mb-6 opacity-80" />
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                Pronto para Decolar sua Presença Digital?
              </h2>
              <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
                Junte-se a milhares de profissionais que já transformaram sua carreira com um site profissional
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a 
                  href="https://construindosonhosweb.com.br/home" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100 shadow-xl h-16 px-12 text-lg">
                    <Rocket className="w-6 h-6 mr-3" />
                    Começar Grátis Agora
                    <ExternalLink className="w-5 h-5 ml-3" />
                  </Button>
                </a>
              </div>

              <p className="mt-6 text-white/80">
                ✨ Plano gratuito disponível • 🚀 Criação em minutos • 💯 Sem compromisso
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}