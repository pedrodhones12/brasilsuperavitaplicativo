
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { TrendingUp, CheckCircle, AlertCircle, MapPin, Target, DollarSign, Shield, Rocket, Plus, Users, Calendar, ArrowRight, Sparkles, Star, Play, Image as ImageIcon, Map, Lock, UserPlus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import ImageCarousel from "../components/projects/ImageCarousel";
import VideoPlayer from "../components/projects/VideoPlayer";
import LocationMap from "../components/projects/LocationMap";

const a1 = [{id:"bronze",name:"Bronze",minAmount:5000,color:"from-amber-600 to-amber-700",benefits:["Certificado de investidor local","Acesso a relatórios mensais","Reconhecimento público"]},{id:"prata",name:"Prata",minAmount:10000,color:"from-gray-400 to-gray-500",benefits:["Todos os benefícios Bronze","Participação em eventos exclusivos","Percentual de retorno em produtos culturais","Prioridade no suporte"]},{id:"ouro",minAmount:15000,name:"Ouro",color:"from-yellow-400 to-yellow-600",benefits:["Todos os benefícios Prata","Retorno financeiro ampliado","Destaque público como investidor premium","Prioridade em novos projetos","Mentoria e networking"]}];

const b2 = {tecnologico:"from-blue-500 to-blue-600",cultural:"from-purple-500 to-purple-600",sustentabilidade:"from-emerald-500 to-emerald-600",infraestrutura:"from-orange-500 to-orange-600",educacao:"from-indigo-500 to-indigo-600",saude:"from-red-500 to-pink-600",turismo:"from-cyan-500 to-teal-600",comercio:"from-amber-500 to-yellow-600",inovacao:"from-violet-500 to-fuchsia-600"};

const c3 = {tecnologico:"Tecnológico",cultural:"Cultural",sustentabilidade:"Sustentabilidade",infraestrutura:"Infraestrutura",educacao:"Educação",saude:"Saúde",turismo:"Turismo",comercio:"Comércio",inovacao:"Inovação"};

const ProjectCard = React.memo(({project: d4, onSelect: e5, isAuth: f6}) => {
  const g7 = (d4.current_funding / d4.funding_goal) * 100;
  const h8 = d4.end_date ? Math.max(0, Math.ceil((new Date(d4.end_date) - new Date()) / (1000*60*60*24))) : 0;
  const i9 = d4.gallery_images?.length > 0;
  const j10 = !!d4.video_url;
  
  const k11 = () => {
    if (!f6) {
      base44.auth.redirectToLogin(window.location.pathname);
      return;
    }
    e5(d4);
  };
  
  const l12 = b2[d4.sector] || b2.tecnologico;
  const m13 = c3[d4.sector] || "Tecnológico";
  
  return (
    <motion.div initial={{opacity:0,scale:0.95}} animate={{opacity:1,scale:1}} whileHover={{y:-8,scale:1.02}} transition={{duration:0.3}}>
      <Card className="overflow-hidden border-none shadow-xl hover:shadow-2xl transition-all duration-300 h-full flex flex-col cursor-pointer group" onClick={k11}>
        <div className="relative h-56 bg-gradient-to-br from-emerald-400 to-blue-500 overflow-hidden">
          {d4.image_url ? (
            <img src={d4.image_url} alt={d4.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy"/>
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Rocket className="w-20 h-20 text-white/50"/>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"/>
          <div className="absolute top-4 left-4 flex flex-col gap-2">
            <Badge className={`bg-gradient-to-r ${l12} text-white border-none font-semibold shadow-lg`}>{m13}</Badge>
            {j10 && <Badge className="bg-red-500 text-white border-none"><Play className="w-3 h-3 mr-1"/>Vídeo</Badge>}
            {i9 && <Badge className="bg-purple-500 text-white border-none"><ImageIcon className="w-3 h-3 mr-1"/>+{d4.gallery_images.length}</Badge>}
            {d4.equity_offered && (
              <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-none font-bold">
                <TrendingUp className="w-3 h-3 mr-1"/>{d4.equity_offered}% Equity
              </Badge>
            )}
          </div>
          <div className="absolute top-4 right-4 flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/95 backdrop-blur-sm shadow-lg">
            <MapPin className="w-4 h-4 text-emerald-600"/>
            <span className="text-sm font-bold text-gray-900">{d4.city}/{d4.state}</span>
          </div>
          {g7 >= 75 && (
            <div className="absolute bottom-4 left-4">
              <Badge className="bg-yellow-500 text-white border-none font-semibold shadow-lg animate-pulse">
                <Star className="w-3 h-3 mr-1"/>Quase completo!
              </Badge>
            </div>
          )}
          {!f6 && (
            <div className="absolute inset-0 bg-black/70 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="text-center text-white space-y-2">
                <Lock className="w-12 h-12 mx-auto mb-2"/>
                <p className="font-bold">Faça login para investir</p>
              </div>
            </div>
          )}
        </div>
        <CardContent className="p-6 flex-1 flex flex-col">
          <h3 className="text-2xl font-bold text-gray-900 mb-3 line-clamp-2 group-hover:text-emerald-600 transition-colors">{d4.title}</h3>
          <p className="text-gray-600 text-sm mb-6 line-clamp-3 flex-1">{d4.description}</p>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-600">Meta de Investimento</span>
                <span className="text-sm font-bold text-emerald-600">{g7.toFixed(0)}%</span>
              </div>
              <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                <motion.div initial={{width:0}} animate={{width:`${Math.min(g7,100)}%`}} transition={{duration:1,delay:0.3}} className="h-full bg-gradient-to-r from-emerald-500 to-blue-500"/>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-emerald-50 rounded-lg">
                <p className="text-xs text-emerald-700 mb-1">Arrecadado</p>
                <p className="text-lg font-bold text-emerald-900">R$ {(d4.current_funding || 0).toLocaleString('pt-BR')}</p>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-xs text-blue-700 mb-1">Meta</p>
                <p className="text-lg font-bold text-blue-900">R$ {d4.funding_goal?.toLocaleString('pt-BR')}</p>
              </div>
            </div>
            <div className="flex items-center justify-between pt-4 border-t border-gray-200">
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4"/>
                  <span className="font-semibold">{d4.investors_count || 0}</span>
                </div>
                {h8 > 0 && (
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4"/>
                    <span className="font-semibold">{h8}d</span>
                  </div>
                )}
              </div>
              <Button size="sm" className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 shadow-lg group-hover:shadow-xl transition-all">
                {f6 ? (
                  <>Investir Agora<ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform"/></>
                ) : (
                  <><Lock className="w-4 h-4 mr-2"/>Login para Investir</>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
});
ProjectCard.displayName = 'ProjectCard';

const InvestmentModal = React.memo(({project: n14, open: o15, onClose: p16, user: q17}) => {
  const r18 = useQueryClient();
  const navigate = useNavigate();
  const [s19, t20] = useState("bronze");
  const [u21, v22] = useState("");
  const [w23, x24] = useState("overview");
  const y25 = a1.find(z26 => z26.id === s19);
  
  const handleInvestNow = () => {
    const ah34 = u21 ? parseFloat(u21) : y25.minAmount;
    if (ah34 < y25.minAmount) {
      alert(`O valor mínimo para a categoria ${y25.name} é R$ ${y25.minAmount.toLocaleString('pt-BR')}`);
      return;
    }
    
    navigate(createPageUrl(`InvestmentCheckout?project=${n14.id}&category=${s19}&amount=${ah34}`));
    p16();
  };
  
  if (!n14) return null;
  
  const ao41 = n14.gallery_images?.length > 0 ? [n14.image_url, ...n14.gallery_images].filter(Boolean) : (n14.image_url ? [n14.image_url] : []);
  
  return (
    <Dialog open={o15} onOpenChange={p16}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
            Investir em {n14.title}
          </DialogTitle>
          <DialogDescription className="text-base">
            <div className="flex items-center gap-2 mt-2">
              <MapPin className="w-4 h-4 text-gray-500"/>
              <span>{n14.city}/{n14.state}</span>
            </div>
          </DialogDescription>
        </DialogHeader>
        <div className="px-6 pb-6">
          <Tabs value={w23} onValueChange={x24} className="w-full">
            <TabsList className="w-full grid grid-cols-3 mb-6">
              <TabsTrigger value="overview">Visão Geral</TabsTrigger>
              <TabsTrigger value="media">Mídia</TabsTrigger>
              <TabsTrigger value="invest">Investir</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-6">
              {ao41.length > 0 && (
                <div>
                  <ImageCarousel images={ao41} title={n14.title}/>
                </div>
              )}
              <Card className="border-emerald-200 bg-emerald-50/50">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3">Sobre o Projeto</h3>
                  <p className="text-gray-700 mb-4 leading-relaxed">{n14.description}</p>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-3 bg-white rounded-lg">
                      <p className="text-xs text-gray-500 mb-1">Meta</p>
                      <p className="text-lg font-bold text-gray-900">R$ {n14.funding_goal?.toLocaleString('pt-BR')}</p>
                    </div>
                    <div className="text-center p-3 bg-white rounded-lg">
                      <p className="text-xs text-gray-500 mb-1">Arrecadado</p>
                      <p className="text-lg font-bold text-emerald-600">R$ {(n14.current_funding || 0).toLocaleString('pt-BR')}</p>
                    </div>
                    <div className="text-center p-3 bg-white rounded-lg">
                      <p className="text-xs text-gray-500 mb-1">Investidores</p>
                      <p className="text-lg font-bold text-blue-600">{n14.investors_count || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              {n14.expected_impact && (
                <Card className="border-blue-200 bg-blue-50/50">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-3">Impactos Esperados</h3>
                    <p className="text-gray-700 leading-relaxed">{n14.expected_impact}</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            <TabsContent value="media" className="space-y-6">
              {n14.video_url && (
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <Play className="w-6 h-6 text-emerald-600"/>Vídeo Pitch do Projeto
                  </h3>
                  <VideoPlayer videoUrl={n14.video_url} title={n14.title}/>
                </div>
              )}
              {((n14.latitude && n14.longitude) || (n14.city && n14.state)) && (
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <Map className="w-6 h-6 text-blue-600"/>Localização do Projeto
                  </h3>
                  <LocationMap latitude={n14.latitude} longitude={n14.longitude} city={n14.city} state={n14.state} title={n14.title}/>
                </div>
              )}
              {ao41.length > 1 && (
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <ImageIcon className="w-6 h-6 text-purple-600"/>Galeria de Imagens
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {ao41.map((ap42, aq43) => (
                      <motion.div key={aq43} whileHover={{scale:1.05}} className="aspect-square rounded-lg overflow-hidden shadow-lg">
                        <img src={ap42} alt={`${n14.title} - ${aq43+1}`} className="w-full h-full object-cover" loading="lazy"/>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="invest" className="space-y-6">
              {n14.investment_type === "equity" && n14.equity_offered && (
                <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <TrendingUp className="w-8 h-8 text-purple-600" />
                      <div>
                        <h3 className="text-xl font-bold text-purple-900">Participação Societária</h3>
                        <p className="text-sm text-purple-700">Torne-se sócio deste projeto</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="p-4 bg-white rounded-lg text-center">
                        <p className="text-sm text-gray-600 mb-1">Equity Oferecido</p>
                        <p className="text-4xl font-bold text-purple-600">{n14.equity_offered}%</p>
                      </div>
                      {n14.company_valuation && (
                        <div className="p-4 bg-white rounded-lg text-center">
                          <p className="text-sm text-gray-600 mb-1">Valuation</p>
                          <p className="text-2xl font-bold text-gray-900">
                            R$ {(n14.company_valuation / 1000).toFixed(0)}k
                          </p>
                        </div>
                      )}
                    </div>
                    {n14.expected_return && (
                      <Alert className="border-blue-200 bg-blue-50">
                        <Sparkles className="h-4 w-4 text-blue-600" />
                        <AlertDescription className="text-blue-900">
                          <strong>Retorno Esperado:</strong> {n14.expected_return}
                        </AlertDescription>
                      </Alert>
                    )}
                  </CardContent>
                </Card>
              )}

              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Escolha sua Categoria</h3>
                <RadioGroup value={s19} onValueChange={t20}>
                  <div className="space-y-4">
                    {a1.map((ar44) => (
                      <div key={ar44.id} className={`p-6 rounded-xl border-2 cursor-pointer transition-all duration-300 ${s19 === ar44.id ? 'border-emerald-500 shadow-lg bg-emerald-50' : 'border-gray-200 hover:border-emerald-300'}`} onClick={() => t20(ar44.id)}>
                        <div className="flex items-start gap-4">
                          <RadioGroupItem value={ar44.id} id={ar44.id} className="mt-1"/>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-3">
                              <h3 className={`text-2xl font-bold bg-gradient-to-r ${ar44.color} bg-clip-text text-transparent`}>{ar44.name}</h3>
                              <Badge className="bg-gradient-to-r from-emerald-500 to-blue-500 text-white border-none">A partir de R$ {ar44.minAmount.toLocaleString('pt-BR')}</Badge>
                            </div>
                            <ul className="space-y-2">
                              {ar44.benefits.map((as45, at46) => (
                                <li key={at46} className="flex items-center gap-2 text-sm text-gray-700">
                                  <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0"/>{as45}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
                <div className="mt-6 space-y-2">
                  <Label htmlFor="custom-amount" className="text-base font-semibold">Valor Personalizado (opcional)</Label>
                  <Input id="custom-amount" type="number" min={y25?.minAmount} step="100" value={u21} onChange={(au47) => v22(au47.target.value)} placeholder={`Mínimo: R$ ${y25?.minAmount.toLocaleString('pt-BR')}`} className="h-12 text-lg"/>
                </div>
              </div>
              
              <Button onClick={handleInvestNow} className="w-full h-14 text-lg bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 shadow-lg">
                <ArrowRight className="w-5 h-5 mr-2" />
                Continuar para Checkout
              </Button>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
});
InvestmentModal.displayName = 'InvestmentModal';

// ✅ FUNÇÃO PARA VERIFICAR SE É ADMIN
const isAdminUser = (email) => {
  const adminEmails = ['pedrodhones15@gmail.com', 'pedrodhones15.com'];
  return adminEmails.some(adminEmail => email?.toLowerCase().includes(adminEmail.toLowerCase()));
};

export default function Invest() {
  const r18 = useNavigate();
  const [aw49, ax50] = useState(null);
  const [ay51, az52] = useState(null);
  const [ba53, bb54] = useState(false);
  const [bc55, bd56] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false); // Changed to false - no loading initially
  
  useEffect(() => {
    const bg59 = async () => {
      try {
        const bh60 = await base44.auth.isAuthenticated();
        bd56(bh60);
        if (bh60) {
          const bi61 = await base44.auth.me();
          ax50(bi61);
          
          // ✅ VERIFICAR SE É ADMIN
          const adminStatus = isAdminUser(bi61.email);
          setIsAdmin(adminStatus);
        }
      } catch (bj62) {
        console.error("Error checking auth:", bj62);
        bd56(false);
        setIsAdmin(false);
      }
    };
    bg59();
  }, [r18]);
  
  const {data: bk63 = []} = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list('-created_date')
  });
  
  const bl64 = bk63.filter(bm65 => bm65.status === 'ativa');
  
  const bn66 = async (bo67) => {
    // ✅ VERIFICAR AUTENTICAÇÃO PRIMEIRO
    if (!bc55) {
      base44.auth.redirectToLogin(window.location.pathname);
      return;
    }

    // ✅ VERIFICAR ASSINATURA ATIVA (ADMIN NÃO PRECISA)
    if (!isAdmin) {
      try {
        const subscriptions = await base44.entities.Subscription.filter({ 
          user_email: aw49?.email 
        });
        
        const activeSubscription = subscriptions.find(
          sub => sub.status === 'authorized' || sub.status === 'pending'
        );

        if (!activeSubscription) {
          r18(createPageUrl("Subscriptions"));
          return;
        }
      } catch (error) {
        console.error("Error checking subscription:", error);
        r18(createPageUrl("Subscriptions"));
        return;
      }
    }

    // Tudo OK - abrir modal
    az52(bo67);
    bb54(true);
  };
  
  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/50 to-blue-50/50">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{opacity:0,y:-20}} animate={{opacity:1,y:0}} className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <TrendingUp className="w-10 h-10 text-emerald-600"/>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
              Investir em Projetos
            </h1>
          </div>
          <p className="text-lg text-gray-600">Seja parte da transformação das cidades brasileiras. Escolha um projeto e faça a diferença!</p>
        </motion.div>
        
        {!bc55 && (
          <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:0.1}} className="mb-8">
            <Alert className="border-amber-300 bg-amber-50">
              <Lock className="h-5 w-5 text-amber-600"/>
              <AlertDescription className="text-amber-900">
                <div className="flex items-center justify-between">
                  <div>
                    <strong className="text-lg">Faça login para investir!</strong>
                    <p className="mt-1">Você pode explorar os projetos, mas precisa estar cadastrado para investir.</p>
                  </div>
                  <Button onClick={() => base44.auth.redirectToLogin(window.location.pathname)} className="bg-amber-600 hover:bg-amber-700 text-white ml-4">
                    <UserPlus className="w-4 h-4 mr-2"/>Entrar / Cadastrar
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          </motion.div>
        )}
        
        <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:0.2}} className="mb-12">
          <Card className="border-none shadow-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-purple-600 via-blue-600 to-emerald-600 p-8 md:p-12 text-white">
              <div className="max-w-4xl mx-auto">
                <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-4">
                      <Sparkles className="w-8 h-8"/>
                      <h2 className="text-3xl md:text-4xl font-bold">Tem um Projeto?</h2>
                    </div>
                    <p className="text-xl text-white/90 mb-2">Crie sua campanha de investimento agora e receba apoio para realizar seu sonho!</p>
                    <p className="text-white/80">✨ Plataforma completa • 🎯 Acompanhamento em tempo real • 💰 Taxa transparente de 6,5%</p>
                  </div>
                  <Button onClick={() => r18(createPageUrl("CreateProject"))} size="lg" className="bg-white text-purple-600 hover:bg-gray-100 shadow-xl hover:shadow-2xl transition-all px-8 py-6 text-lg font-bold whitespace-nowrap">
                    <Plus className="w-6 h-6 mr-2"/>Criar Meu Projeto Agora
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
        
        <motion.div initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.3}} className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="border-none shadow-lg bg-gradient-to-br from-emerald-50 to-white">
            <CardContent className="p-6 text-center">
              <Target className="w-12 h-12 text-emerald-600 mx-auto mb-3"/>
              <p className="text-4xl font-bold text-gray-900 mb-2">{bl64.length}</p>
              <p className="text-gray-600">Projetos Disponíveis</p>
            </CardContent>
          </Card>
          <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-white">
            <CardContent className="p-6 text-center">
              <Users className="w-12 h-12 text-blue-600 mx-auto mb-3"/>
              <p className="text-4xl font-bold text-gray-900 mb-2">{bk63.reduce((bp68, bq69) => bp68 + (bq69.investors_count || 0), 0)}</p>
              <p className="text-gray-600">Investidores Ativos</p>
            </CardContent>
          </Card>
          <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-white">
            <CardContent className="p-6 text-center">
              <DollarSign className="w-12 h-12 text-purple-600 mx-auto mb-3"/>
              <p className="text-4xl font-bold text-gray-900 mb-2">R$ {(bk63.reduce((br70, bs71) => br70 + (bs71.current_funding || 0), 0)).toLocaleString('pt-BR')}</p>
              <p className="text-gray-600">Investido ao Total</p>
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.4}}>
          <h2 className="text-3xl font-bold text-gray-900 mb-8 flex items-center gap-3">
            <Rocket className="w-8 h-8 text-blue-600"/>Projetos Disponíveis para Investimento
          </h2>
          {bl64.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <AnimatePresence>
                {bl64.map((bt72, bu73) => (
                  <motion.div key={bt72.id} initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} transition={{delay:0.5+bu73*0.1}}>
                    <ProjectCard project={bt72} onSelect={bn66} isAuth={bc55}/>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          ) : (
            <Card className="p-16 text-center border-2 border-dashed border-gray-300">
              <AlertCircle className="w-20 h-20 text-gray-400 mx-auto mb-4"/>
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">Nenhum projeto disponível no momento</h3>
              <p className="text-gray-600 mb-6">Seja o primeiro a criar um projeto e atrair investidores!</p>
              <Button onClick={() => r18(createPageUrl("CreateProject"))} className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 text-lg px-8 py-6">
                <Plus className="w-5 h-5 mr-2"/>Criar Primeiro Projeto
              </Button>
            </Card>
          )}
        </motion.div>
      </div>
      {bc55 && (
        <InvestmentModal project={ay51} open={ba53} onClose={() => bb54(false)} user={aw49}/>
      )}
    </div>
  );
}
