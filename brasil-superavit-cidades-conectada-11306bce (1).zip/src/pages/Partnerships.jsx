
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Handshake, DollarSign, TrendingUp, FileText, Globe, CheckCircle, Clock, Users,
  BarChart3, Rocket, MapPin, Video, Image as ImageIcon, Link as LinkIcon, X, Send,
  Heart, MessageCircle, Share2, Building2, Factory, Leaf, Lightbulb, ExternalLink,
  Download, Sparkles, Info, Edit, Trash2, MoreVertical, ChevronsUpDown, Check
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";

// Lista de cidades brasileiras organizadas por estado
const BRAZILIAN_CITIES = {
  "AC": ["Rio Branco", "Cruzeiro do Sul", "Sena Madureira", "Tarauacá"],
  "AL": ["Maceió", "Arapiraca", "Palmeira dos Índios", "Rio Largo"],
  "AP": ["Macapá", "Santana", "Laranjal do Jari", "Oiapoque"],
  "AM": ["Manaus", "Parintins", "Itacoatiara", "Manacapuru"],
  "BA": ["Salvador", "Feira de Santana", "Vitória da Conquista", "Camaçari", "Juazeiro", "Ilhéus", "Lauro de Freitas", "Itabuna", "Porto Seguro"],
  "CE": ["Fortaleza", "Caucaia", "Juazeiro do Norte", "Maracanaú", "Sobral"],
  "DF": ["Brasília"],
  "ES": ["Vitória", "Vila Velha", "Serra", "Cariacica", "Linhares"],
  "GO": ["Goiânia", "Aparecida de Goiânia", "Anápolis", "Rio Verde", "Luziânia"],
  "MA": ["São Luís", "Imperatriz", "São José de Ribamar", "Timon", "Caxias"],
  "MT": ["Cuiabá", "Várzea Grande", "Rondonópolis", "Sinop", "Tangará da Serra"],
  "MS": ["Campo Grande", "Dourados", "Três Lagoas", "Corumbá", "Ponta Porã"],
  "MG": ["Belo Horizonte", "Uberlândia", "Contagem", "Juiz de Fora", "Betim", "Montes Claros", "Ribeirão das Neves", "Uberaba", "Governador Valadares", "Ipatinga", "Sete Lagoas", "Divinópolis", "Santa Luzia", "Ibirité", "Poços de Caldas", "Patos de Minas", "Teófilo Otoni", "Sabará", "Pouso Alegre", "Barbacena", "Varginha", "Araguari", "Conselheiro Lafaiete", "Itabira", "Passos", "Ubá"],
  "PA": ["Belém", "Ananindeua", "Santarém", "Marabá", "Parauapebas", "Castanhal"],
  "PB": ["João Pessoa", "Campina Grande", "Santa Rita", "Patos", "Bayeux"],
  "PR": ["Curitiba", "Londrina", "Maringá", "Ponta Grossa", "Cascavel", "São José dos Pinhais", "Foz do Iguaçu", "Colombo", "Guarapuava", "Paranaguá", "Araucária"],
  "PE": ["Recife", "Jaboatão dos Guararapes", "Olinda", "Caruaru", "Petrolina", "Paulista", "Cabo de Santo Agostinho"],
  "PI": ["Teresina", "Parnaíba", "Picos", "Piripiri", "Floriano"],
  "RJ": ["Rio de Janeiro", "São Gonçalo", "Duque de Caxias", "Nova Iguaçu", "Niterói", "Belford Roxo", "São João de Meriti", "Campos dos Goytacazes", "Petrópolis", "Volta Redonda", "Magé", "Itaboraí", "Macaé", "Cabo Frio", "Nova Friburgo", "Angra dos Reis", "Barra Mansa", "Teresópolis", "Mesquita", "Nilópolis"],
  "RN": ["Natal", "Mossoró", "Parnamirim", "São Gonçalo do Amarante", "Macaíba"],
  "RS": ["Porto Alegre", "Caxias do Sul", "Pelotas", "Canoas", "Santa Maria", "Gravataí", "Viamão", "Novo Hamburgo", "São Leopoldo", "Rio Grande", "Alvorada", "Passo Fundo", "Sapucaia do Sul", "Uruguaiana", "Santa Cruz do Sul", "Cachoeirinha", "Bagé", "Bento Gonçalves", "Erechim", "Guaíba"],
  "RO": ["Porto Velho", "Ji-Paraná", "Ariquemes", "Vilhena", "Cacoal"],
  "RR": ["Boa Vista", "Rorainópolis", "Caracaraí", "Mucajaí"],
  "SC": ["Florianópolis", "Joinville", "Blumenau", "São José", "Criciúma", "Chapecó", "Itajaí", "Jaraguá do Sul", "Lages", "Palhoça", "Balneário Camboriú", "Brusque"],
  "SP": ["São Paulo", "Guarulhos", "Campinas", "São Bernardo do Campo", "Santo André", "Osasco", "São José dos Campos", "Ribeirão Preto", "Sorocaba", "Mauá", "São José do Rio Preto", "Santos", "Diadema", "Jundiaí", "Carapicuíba", "Piracicaba", "Bauru", "São Vicente", "Itaquaquecetuba", "Franca", "Guarujá", "Taubaté", "Praia Grande", "Limeira", "Suzano", "Taboão da Serra", "Sumaré", "Barueri", "Embu das Artes", "São Carlos", "Marília", "Indaiatuba", "Cotia", "Americana", "Jacareí", "Araraquara", "Hortolândia", "Presidente Prudente", "Itapevi"],
  "SE": ["Aracaju", "Nossa Senhora do Socorro", "Lagarto", "Itabaiana", "Estância"],
  "TO": ["Palmas", "Araguaína", "Gurupi", "Porto Nacional", "Paraíso do Tocantins"]
};

// Criar lista plana de cidades com seus estados
const CITIES_LIST = Object.entries(BRAZILIAN_CITIES).flatMap(([state, cities]) =>
  cities.map(city => ({ city, state, label: `${city} - ${state}` }))
);

const statusConfig = {
  proposed: { label: "Proposta", color: "bg-yellow-100 text-yellow-800", icon: Clock },
  negotiating: { label: "Negociando", color: "bg-blue-100 text-blue-800", icon: Users },
  signed: { label: "Assinado", color: "bg-purple-100 text-purple-800", icon: FileText },
  active: { label: "Ativo", color: "bg-emerald-100 text-emerald-800", icon: CheckCircle },
  completed: { label: "Finalizado", color: "bg-gray-100 text-gray-800", icon: CheckCircle },
  terminated: { label: "Encerrado", color: "bg-red-100 text-red-800", icon: Clock }
};

const sectorIcons = {
  tecnologico: Rocket,
  industrial: Factory,
  sustentabilidade: Leaf,
  agronegocio: Leaf,
  turismo: Globe,
  comercio: Building2,
  inovacao: Lightbulb
};

const FeedPost = React.memo(({ post, currentUser, onEdit, onDelete, onLike, onComment }) => {
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const SectorIcon = sectorIcons[post.sector] || Building2;
  const isAuthor = currentUser?.email === post.author_email;

  const renderMedia = () => {
    if (post.media_type === 'video' && post.media_url) {
      return (
        <div className="mb-4 rounded-xl overflow-hidden border-2 border-gray-200 bg-black">
          <video controls className="w-full h-auto max-h-80" src={post.media_url} preload="metadata">
            Seu navegador não suporta vídeo.
          </video>
        </div>
      );
    }

    if (post.media_type === 'photo' && post.media_url) {
      return (
        <div className="mb-4 rounded-xl overflow-hidden border-2 border-gray-200">
          <img src={post.media_url} alt="Post media" className="w-full h-auto object-cover max-h-80" loading="lazy" />
        </div>
      );
    }

    if (post.media_type === 'document' && post.media_url) {
      return (
        <a href={post.media_url} target="_blank" rel="noopener noreferrer" className="mb-4 block">
          <motion.div whileHover={{ scale: 1.02 }} className="p-4 md:p-5 rounded-xl bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-200 hover:border-emerald-400 transition-all cursor-pointer shadow-md">
            <div className="flex items-center gap-3 md:gap-4">
              <div className="p-3 md:p-4 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 shadow-lg flex-shrink-0">
                <FileText className="w-6 h-6 md:w-8 md:h-8 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-gray-900 text-sm md:text-base truncate">{post.media_filename || 'Documento'}</p>
                <p className="text-xs md:text-sm text-gray-600">Clique para abrir ou baixar</p>
              </div>
              <Download className="w-5 h-5 md:w-6 md:h-6 text-emerald-600 flex-shrink-0" />
            </div>
          </motion.div>
        </a>
      );
    }

    if (post.media_type === 'link' && post.link_url) {
      return (
        <a href={post.link_url} target="_blank" rel="noopener noreferrer" className="mb-4 block">
          <motion.div whileHover={{ scale: 1.01 }} className="rounded-xl border-2 border-gray-200 hover:border-purple-400 transition-all overflow-hidden cursor-pointer shadow-md">
            {post.link_image && (
              <div className="relative h-48 md:h-56 overflow-hidden">
                <img src={post.link_image} alt="Link preview" className="w-full h-full object-cover" />
                <div className="absolute top-3 md:top-4 right-3 md:right-4 p-2 rounded-full bg-white/90 backdrop-blur-sm">
                  <ExternalLink className="w-4 h-4 md:w-5 md:h-5 text-gray-700" />
                </div>
              </div>
            )}
            <div className="p-4 md:p-5 bg-gradient-to-br from-gray-50 to-white">
              <h4 className="font-bold text-base md:text-lg text-gray-900 mb-2 line-clamp-2">{post.link_title || post.link_url}</h4>
              {post.link_description && (
                <p className="text-xs md:text-sm text-gray-600 line-clamp-3 mb-3">{post.link_description}</p>
              )}
              <div className="flex items-center gap-2">
                <LinkIcon className="w-3 h-3 md:w-4 md:h-4 text-gray-400" />
                <p className="text-xs text-gray-500 font-medium">{new URL(post.link_url).hostname}</p>
              </div>
            </div>
          </motion.div>
        </a>
      );
    }

    return null;
  };

  return (
    <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
      <CardContent className="p-4 md:p-6">
        <div className="flex items-start gap-3 md:gap-4 mb-4">
          <Avatar className="w-10 h-10 md:w-12 md:h-12 border-2 border-white shadow-md flex-shrink-0">
            <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white font-semibold text-sm">
              {post.author_name?.substring(0, 2).toUpperCase() || 'CI'}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 mb-1 flex-wrap flex-1 min-w-0">
                <h3 className="font-bold text-gray-900 text-sm md:text-base truncate">{post.author_name}</h3>
                <Badge variant="outline" className="flex items-center gap-1 text-xs flex-shrink-0">
                  <MapPin className="w-3 h-3" />
                  {post.city}
                </Badge>
                {post.sector && (
                  <Badge className="bg-gradient-to-r from-emerald-500 to-blue-500 text-white border-none text-xs flex-shrink-0">
                    <SectorIcon className="w-3 h-3 mr-1" />
                    {post.sector}
                  </Badge>
                )}
              </div>

              {/* Edit/Delete Menu */}
              {isAuthor && (
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-48" align="end">
                    <div className="space-y-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="w-full justify-start gap-2"
                        onClick={() => onEdit && onEdit(post)}
                      >
                        <Edit className="w-4 h-4" />
                        Editar
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="w-full justify-start gap-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={() => {
                          if (window.confirm('Tem certeza que deseja excluir esta publicação?')) {
                            onDelete && onDelete(post.id);
                          }
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                        Excluir
                      </Button>
                    </div>
                  </PopoverContent>
                </Popover>
              )}
            </div>
            <div className="flex items-center gap-2 text-xs md:text-sm text-gray-500">
              <Clock className="w-3 h-3" />
              <span>{format(new Date(post.created_date), "dd MMM 'às' HH:mm", { locale: ptBR })}</span>
            </div>
          </div>
        </div>

        <div className="mb-4">
          <p className="text-gray-700 whitespace-pre-line leading-relaxed text-sm md:text-base break-words">{post.content}</p>
        </div>

        {renderMedia()}

        <div className="flex items-center gap-3 md:gap-4 pt-4 border-t border-gray-200 flex-wrap">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onLike && onLike(post.id)}
            className="gap-2 text-gray-600 text-xs md:text-sm hover:text-red-600 hover:bg-red-50"
          >
            <Heart className="w-4 h-4 md:w-5 md:h-5" />
            <span className="font-semibold">{post.likes_count || 0}</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowComments(!showComments)}
            className="gap-2 text-gray-600 text-xs md:text-sm hover:text-blue-600 hover:bg-blue-50"
          >
            <MessageCircle className="w-4 h-4 md:w-5 md:h-5" />
            <span className="font-semibold">{post.comments_count || 0}</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="gap-2 text-gray-600 text-xs md:text-sm hover:text-emerald-600 hover:bg-emerald-50"
          >
            <Share2 className="w-4 h-4 md:w-5 md:h-5" />
            <span className="hidden md:inline font-semibold">Compartilhar</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
});
FeedPost.displayName = 'FeedPost';

const CitySearchCombobox = ({ value, onChange, placeholder = "Buscar cidade..." }) => {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCities = CITIES_LIST.filter(item =>
    item.label.toLowerCase().includes(searchQuery.toLowerCase())
  ).slice(0, 50); // Limitar a 50 resultados

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between h-10 text-left font-normal"
        >
          {value ? value : placeholder}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-0" align="start">
        <Command>
          <CommandInput
            placeholder="Digite cidade ou estado..."
            value={searchQuery}
            onValueChange={setSearchQuery}
          />
          <CommandEmpty>Nenhuma cidade encontrada.</CommandEmpty>
          <CommandGroup className="max-h-64 overflow-auto">
            {filteredCities.map((item) => (
              <CommandItem
                key={item.label}
                value={item.label}
                onSelect={() => {
                  onChange(item.label);
                  setOpen(false);
                  setSearchQuery("");
                }}
              >
                <Check
                  className={cn(
                    "mr-2 h-4 w-4",
                    value === item.label ? "opacity-100" : "opacity-0"
                  )}
                />
                <MapPin className="mr-2 h-4 w-4 text-emerald-600" />
                {item.city}
                <Badge variant="outline" className="ml-2 text-xs">
                  {item.state}
                </Badge>
              </CommandItem>
            ))}
          </CommandGroup>
        </Command>
      </PopoverContent>
    </Popover>
  );
};

export default function Partnerships() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("partnerships");
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [editingPost, setEditingPost] = useState(null);
  const [postData, setPostData] = useState({
    content: "",
    city: "",
    sector: "",
    media_type: "none",
    media_url: "",
    media_filename: "",
    link_url: "",
    link_title: "",
    link_description: ""
  });
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: partnerships = [], isLoading: partnershipsLoading } = useQuery({
    queryKey: ['my-partnerships', user?.email],
    queryFn: async () => {
      const asInvestor = await base44.entities.Partnership.filter({
        investor_email: user?.email
      }, '-created_date');
      const asEntrepreneur = await base44.entities.Partnership.filter({
        entrepreneur_email: user?.email
      }, '-created_date');
      return { asInvestor, asEntrepreneur };
    },
    enabled: !!user?.email
  });

  const { data: feedPosts = [] } = useQuery({
    queryKey: ['partnership-feed'],
    queryFn: () => base44.entities.SocialPost.filter({ visibility: 'local' }, '-created_date', 50)
  });

  const createPostMutation = useMutation({
    mutationFn: (data) => base44.entities.SocialPost.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partnership-feed'] });
      setShowCreatePost(false);
      setEditingPost(null);
      setPostData({
        content: "",
        city: "",
        sector: "",
        media_type: "none",
        media_url: "",
        media_filename: "",
        link_url: "",
        link_title: "",
        link_description: ""
      });
      alert("✅ Publicação criada com sucesso!");
    }
  });

  const updatePostMutation = useMutation({
    mutationFn: ({ postId, data }) => base44.entities.SocialPost.update(postId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partnership-feed'] });
      setShowCreatePost(false);
      setEditingPost(null);
      setPostData({
        content: "",
        city: "",
        sector: "",
        media_type: "none",
        media_url: "",
        media_filename: "",
        link_url: "",
        link_title: "",
        link_description: ""
      });
      alert("✅ Publicação atualizada com sucesso!");
    }
  });

  const deletePostMutation = useMutation({
    mutationFn: (postId) => base44.entities.SocialPost.delete(postId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partnership-feed'] });
      alert("✅ Publicação excluída com sucesso!");
    }
  });

  const handleFileUpload = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 100 * 1024 * 1024) {
      alert("Arquivo muito grande! Máximo: 100MB");
      return;
    }
    setUploadingMedia(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setPostData(prev => ({
        ...prev,
        media_type: type,
        media_url: file_url,
        media_filename: file.name
      }));
    } catch (error) {
      alert("Erro ao enviar arquivo");
    } finally {
      setUploadingMedia(false);
    }
  };

  const handleSubmitPost = () => {
    if (!postData.content.trim() || !postData.city || !postData.sector) {
      alert("Preencha título, cidade e setor");
      return;
    }

    // Extrair apenas o nome da cidade do formato "Cidade - UF"
    const cityParts = postData.city.split(' - ');
    const cityName = cityParts[0];

    if (editingPost) {
      updatePostMutation.mutate({
        postId: editingPost.id,
        data: {
          content: postData.content,
          city: cityName,
          sector: postData.sector,
          media_type: postData.media_type,
          media_url: postData.media_url,
          media_filename: postData.media_filename,
          link_url: postData.link_url,
          link_title: postData.link_title,
          link_description: postData.link_description
        }
      });
    } else {
      const newPost = {
        content: postData.content,
        city: cityName,
        sector: postData.sector,
        media_type: postData.media_type,
        media_url: postData.media_url,
        media_filename: postData.media_filename,
        link_url: postData.link_url,
        link_title: postData.link_title,
        link_description: postData.link_description,
        author_email: user.email,
        author_name: user.full_name,
        post_type: 'announcement',
        visibility: 'local'
      };
      createPostMutation.mutate(newPost);
    }
  };

  const handleEdit = (post) => {
    setEditingPost(post);
    // Find the full label (e.g., "São Paulo - SP") for the city for combobox
    const fullCityLabel = CITIES_LIST.find(item => item.city === post.city)?.label || post.city;

    setPostData({
      content: post.content,
      city: fullCityLabel,
      sector: post.sector,
      media_type: post.media_type || "none",
      media_url: post.media_url || "",
      media_filename: post.media_filename || "",
      link_url: post.link_url || "",
      link_title: post.link_title || "",
      link_description: post.link_description || ""
    });
    setShowCreatePost(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const totalInvested = partnerships.asInvestor?.reduce((sum, p) => sum + (p.investment_amount_brl || 0), 0) || 0;
  const totalReceived = partnerships.asEntrepreneur?.reduce((sum, p) => sum + (p.investment_amount_brl || 0), 0) || 0;
  const totalDividends = partnerships.asInvestor?.reduce((sum, p) => sum + (p.dividends_paid || 0), 0) || 0;
  const activePartnerships = [...(partnerships.asInvestor || []), ...(partnerships.asEntrepreneur || [])].filter(p => p.status === 'active').length;

  return (
    <div className="min-h-screen p-2 md:p-4 lg:p-8 bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="mb-6 md:mb-8">
          <div className="flex items-center gap-3 md:gap-4 mb-4">
            <div className="p-3 md:p-4 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-xl flex-shrink-0">
              <Handshake className="w-8 h-8 md:w-10 md:h-10 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl md:text-4xl lg:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent leading-tight">
                Parcerias & Oportunidades
              </h1>
              <p className="text-sm md:text-xl text-gray-600 mt-1">
                Conecte-se com cidades e investidores para projetos conjuntos
              </p>
            </div>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-6 mb-6 md:mb-8">
          <Card className="border-none shadow-lg">
            <CardContent className="p-3 md:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-xs md:text-sm text-gray-500 mb-1 truncate">Total Investido</p>
                  <p className="text-lg md:text-2xl font-bold text-gray-900">R$ {totalInvested.toLocaleString('pt-BR')}</p>
                </div>
                <div className="p-2 md:p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex-shrink-0">
                  <DollarSign className="w-5 h-5 md:w-6 md:h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-3 md:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-xs md:text-sm text-gray-500 mb-1 truncate">Total Recebido</p>
                  <p className="text-lg md:text-2xl font-bold text-gray-900">R$ {totalReceived.toLocaleString('pt-BR')}</p>
                </div>
                <div className="p-2 md:p-3 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex-shrink-0">
                  <TrendingUp className="w-5 h-5 md:w-6 md:h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-3 md:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-xs md:text-sm text-gray-500 mb-1 truncate">Dividendos</p>
                  <p className="text-lg md:text-2xl font-bold text-gray-900">R$ {totalDividends.toLocaleString('pt-BR')}</p>
                </div>
                <div className="p-2 md:p-3 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex-shrink-0">
                  <BarChart3 className="w-5 h-5 md:w-6 md:h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-3 md:p-6">
              <div className="flex items-center justify-between">
                <div className="min-w-0">
                  <p className="text-xs md:text-sm text-gray-500 mb-1 truncate">Parcerias Ativas</p>
                  <p className="text-lg md:text-2xl font-bold text-gray-900">{activePartnerships}</p>
                </div>
                <div className="p-2 md:p-3 rounded-xl bg-gradient-to-br from-orange-500 to-orange-600 flex-shrink-0">
                  <Handshake className="w-5 h-5 md:w-6 md:h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-8">
          <div className="lg:col-span-2">
            <Card className="border-none shadow-xl mb-4 md:mb-6">
              <CardContent className="p-4 md:p-6">
                {/* Tabs */}
                <div className="flex gap-2 md:gap-3 mb-4 md:mb-6 overflow-x-auto">
                  <Button
                    onClick={() => setActiveTab("feed")}
                    variant={activeTab === "feed" ? "default" : "outline"}
                    className={activeTab === "feed" ? "bg-gradient-to-r from-emerald-500 to-blue-500 text-xs md:text-sm" : "text-xs md:text-sm whitespace-nowrap"}
                  >
                    <Globe className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
                    Feed
                  </Button>
                  <Button
                    onClick={() => setActiveTab("partnerships")}
                    variant={activeTab === "partnerships" ? "default" : "outline"}
                    className={activeTab === "partnerships" ? "bg-gradient-to-r from-purple-500 to-pink-500 text-xs md:text-sm" : "text-xs md:text-sm whitespace-nowrap"}
                  >
                    <Handshake className="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" />
                    Parcerias
                  </Button>
                </div>

                {activeTab === "feed" && (
                  <div className="space-y-4 md:space-y-6">
                    {/* Create/Edit Post */}
                    {!showCreatePost ? (
                      <Button
                        onClick={() => setShowCreatePost(true)}
                        className="w-full h-12 md:h-14 bg-gradient-to-r from-emerald-500 to-blue-500 text-sm md:text-lg"
                      >
                        <Sparkles className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                        Publicar Projeto ou Oportunidade
                      </Button>
                    ) : (
                      <Card className="border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-blue-50">
                        <CardContent className="p-4 md:p-6 space-y-3 md:space-y-4">
                          <div className="flex justify-between items-center mb-3 md:mb-4">
                            <h3 className="text-base md:text-lg font-bold text-gray-900">
                              {editingPost ? "Editar Publicação" : "Nova Oportunidade"}
                            </h3>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                setShowCreatePost(false);
                                setEditingPost(null);
                                setPostData({
                                  content: "",
                                  city: "",
                                  sector: "",
                                  media_type: "none",
                                  media_url: "",
                                  media_filename: "",
                                  link_url: "",
                                  link_title: "",
                                  link_description: ""
                                });
                              }}
                              className="h-7 w-7 md:h-8 md:w-8 p-0"
                            >
                              <X className="w-4 h-4 md:w-5 md:h-5" />
                            </Button>
                          </div>

                          {editingPost && (
                            <Alert className="border-blue-200 bg-blue-50">
                              <Edit className="h-4 w-4 text-blue-600" />
                              <AlertDescription className="text-blue-900">
                                <strong>Editando publicação</strong> - Faça suas alterações e clique em "{editingPost ? 'Atualizar' : 'Publicar'}"
                              </AlertDescription>
                            </Alert>
                          )}

                          <Textarea
                            placeholder="Descreva seu projeto, invenção ou oportunidade de parceria..."
                            value={postData.content}
                            onChange={(e) => setPostData(prev => ({ ...prev, content: e.target.value }))}
                            className="min-h-24 md:min-h-32 text-sm md:text-base"
                          />

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                            <div>
                              <label className="text-sm font-medium text-gray-700 mb-2 block">
                                🔍 Buscar Cidade e Estado
                              </label>
                              <CitySearchCombobox
                                value={postData.city}
                                onChange={(value) => setPostData(prev => ({ ...prev, city: value }))}
                                placeholder="Digite para buscar..."
                              />
                            </div>
                            <div>
                              <label className="text-sm font-medium text-gray-700 mb-2 block">
                                Setor
                              </label>
                              <select
                                value={postData.sector}
                                onChange={(e) => setPostData(prev => ({ ...prev, sector: e.target.value }))}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm md:text-base h-10"
                              >
                                <option value="">Selecione o Setor</option>
                                <option value="tecnologico">Tecnológico</option>
                                <option value="industrial">Industrial</option>
                                <option value="agronegocio">Agronegócio</option>
                                <option value="turismo">Turismo</option>
                                <option value="comercio">Comércio</option>
                                <option value="sustentabilidade">Sustentabilidade</option>
                                <option value="inovacao">Inovação</option>
                              </select>
                            </div>
                          </div>

                          {/* Media Upload Buttons */}
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
                            <label className="cursor-pointer">
                              <input
                                type="file"
                                accept="image/*"
                                onChange={(e) => handleFileUpload(e, 'photo')}
                                className="hidden"
                                disabled={uploadingMedia}
                              />
                              <div className="p-3 md:p-4 text-center border-2 border-dashed rounded-xl hover:border-blue-500 transition-all">
                                <ImageIcon className="w-6 h-6 md:w-8 md:h-8 mx-auto mb-2 text-blue-600" />
                                <p className="text-xs md:text-sm font-semibold text-gray-700">Foto</p>
                              </div>
                            </label>

                            <label className="cursor-pointer">
                              <input
                                type="file"
                                accept="video/*"
                                onChange={(e) => handleFileUpload(e, 'video')}
                                className="hidden"
                                disabled={uploadingMedia}
                              />
                              <div className="p-3 md:p-4 text-center border-2 border-dashed rounded-xl hover:border-red-500 transition-all">
                                <Video className="w-6 h-6 md:w-8 md:h-8 mx-auto mb-2 text-red-600" />
                                <p className="text-xs md:text-sm font-semibold text-gray-700">Vídeo</p>
                              </div>
                            </label>

                            <label className="cursor-pointer">
                              <input
                                type="file"
                                accept=".pdf,.doc,.docx"
                                onChange={(e) => handleFileUpload(e, 'document')}
                                className="hidden"
                                disabled={uploadingMedia}
                              />
                              <div className="p-3 md:p-4 text-center border-2 border-dashed rounded-xl hover:border-emerald-500 transition-all">
                                <FileText className="w-6 h-6 md:w-8 md:h-8 mx-auto mb-2 text-emerald-600" />
                                <p className="text-xs md:text-sm font-semibold text-gray-700">Documento</p>
                              </div>
                            </label>

                            <div
                              className="p-3 md:p-4 text-center border-2 border-dashed rounded-xl hover:border-purple-500 transition-all cursor-pointer"
                              onClick={() => setPostData(prev => ({ ...prev, media_type: 'link' }))}
                            >
                              <LinkIcon className="w-6 h-6 md:w-8 md:h-8 mx-auto mb-2 text-purple-600" />
                              <p className="text-xs md:text-sm font-semibold text-gray-700">Link</p>
                            </div>
                          </div>

                          {/* Link Form */}
                          {postData.media_type === 'link' && (
                            <div className="space-y-3 p-3 md:p-4 bg-white rounded-lg">
                              <Input
                                placeholder="🔗 URL"
                                value={postData.link_url}
                                onChange={(e) => setPostData(prev => ({ ...prev, link_url: e.target.value }))}
                                className="text-sm"
                              />
                              <Input
                                placeholder="📝 Título (opcional)"
                                value={postData.link_title}
                                onChange={(e) => setPostData(prev => ({ ...prev, link_title: e.target.value }))}
                                className="text-sm"
                              />
                            </div>
                          )}

                          {uploadingMedia && <p className="text-center text-blue-600 text-sm">Enviando arquivo...</p>}

                          {/* Action Buttons */}
                          <div className="flex gap-3 pt-3 md:pt-4">
                            <Button
                              variant="outline"
                              onClick={() => {
                                setShowCreatePost(false);
                                setEditingPost(null);
                                setPostData({
                                  content: "",
                                  city: "",
                                  sector: "",
                                  media_type: "none",
                                  media_url: "",
                                  media_filename: "",
                                  link_url: "",
                                  link_title: "",
                                  link_description: ""
                                });
                              }}
                              className="flex-1 h-10 md:h-12 text-sm md:text-base"
                            >
                              Cancelar
                            </Button>
                            <Button
                              onClick={handleSubmitPost}
                              disabled={!postData.content || !postData.city || !postData.sector || uploadingMedia}
                              className="flex-1 h-10 md:h-12 bg-gradient-to-r from-emerald-500 to-blue-500 text-sm md:text-base"
                            >
                              <Send className="w-4 h-4 mr-2" />
                              {editingPost ? "Atualizar" : "Publicar"}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Feed Posts */}
                    <div className="space-y-4 md:space-y-6">
                      {feedPosts.map(post => (
                        <FeedPost
                          key={post.id}
                          post={post}
                          currentUser={user}
                          onEdit={handleEdit}
                          onDelete={(postId) => deletePostMutation.mutate(postId)}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === "partnerships" && (
                  <div className="space-y-4 md:space-y-6">
                    <Alert className="bg-blue-50 border-blue-200">
                      <Info className="w-4 h-4 md:w-5 md:h-5 text-blue-600" />
                      <AlertDescription className="text-gray-700 text-xs md:text-sm">
                        <strong>Em Breve:</strong> Sistema completo de visualização e gestão de parcerias estará disponível em breve!
                      </AlertDescription>
                    </Alert>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-4 md:space-y-6">
            <Card className="border-none shadow-xl bg-gradient-to-br from-emerald-50 to-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-sm md:text-base">
                  <Sparkles className="w-4 h-4 md:w-5 md:h-5 text-emerald-600" />
                  Dicas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 md:space-y-3 text-xs md:text-sm">
                <p>✨ Publique fotos, vídeos e documentos dos seus projetos</p>
                <p>🤝 Conecte-se com outras cidades para parcerias</p>
                <p>💡 Compartilhe suas invenções e inovações</p>
                <p>📊 Acompanhe suas parcerias ativas</p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-xl">
              <CardHeader>
                <CardTitle className="text-xs md:text-sm">Setores Populares</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {["Agronegócio", "Turismo", "Tecnologia", "Industrial"].map(sector => (
                  <Badge key={sector} variant="outline" className="mr-2 text-xs">
                    {sector}
                  </Badge>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
