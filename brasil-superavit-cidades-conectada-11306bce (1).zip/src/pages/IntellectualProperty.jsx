import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Shield,
  Plus,
  CheckCircle,
  Clock,
  FileText,
  ExternalLink,
  AlertCircle,
  BookOpen,
  Users
} from "lucide-react";
import { motion } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

// ✅ FUNÇÃO PARA VERIFICAR SE É ADMIN
const isAdminUser = (email) => {
  const adminEmails = ['pedrodhones15@gmail.com', 'pedrodhones15.com'];
  return adminEmails.some(adminEmail => email?.toLowerCase().includes(adminEmail.toLowerCase()));
};

const protectionTypeInfo = {
  marca: {
    name: "Marca",
    description: "Nome, logotipo, símbolo ou identidade visual",
    validity: "10 anos (renovável)",
    color: "from-blue-500 to-blue-600",
    icon: Shield
  },
  patente: {
    name: "Patente",
    description: "Invenções, produtos ou processos inéditos",
    validity: "20 anos",
    color: "from-purple-500 to-purple-600",
    icon: Shield
  },
  modelo_utilidade: {
    name: "Modelo de Utilidade",
    description: "Melhorias funcionais em algo já existente",
    validity: "15 anos",
    color: "from-indigo-500 to-indigo-600",
    icon: Shield
  },
  software: {
    name: "Software",
    description: "Programas de computador, apps e sistemas",
    validity: "50 anos",
    color: "from-emerald-500 to-emerald-600",
    icon: Shield
  },
  direito_autoral: {
    name: "Direito Autoral",
    description: "Textos, roteiros, músicas, jogos narrativos",
    validity: "Vitalício + 70 anos",
    color: "from-yellow-500 to-yellow-600",
    icon: Shield
  }
};

const statusColors = {
  analise: "bg-blue-100 text-blue-800",
  em_registro: "bg-yellow-100 text-yellow-800",
  registrado: "bg-emerald-100 text-emerald-800",
  renovacao_necessaria: "bg-orange-100 text-orange-800",
  expirado: "bg-red-100 text-red-800"
};

const statusLabels = {
  analise: "Em Análise",
  em_registro: "Em Registro",
  registrado: "Registrado",
  renovacao_necessaria: "Renovação Necessária",
  expirado: "Expirado"
};

const ProtectionCard = ({ registration }) => {
  const protectionInfo = protectionTypeInfo[registration.protection_type];
  const Icon = protectionInfo.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
        <div className={`h-2 bg-gradient-to-r ${protectionInfo.color}`} />
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <CardTitle className="text-xl mb-2">{registration.project_name}</CardTitle>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Icon className="w-4 h-4" />
                <span>{protectionInfo.name}</span>
              </div>
            </div>
            <Badge className={statusColors[registration.status]}>
              {statusLabels[registration.status]}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-600 line-clamp-2">
            {registration.description}
          </p>

          {registration.inpi_protocol && (
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500 mb-1">Protocolo INPI</p>
              <p className="font-semibold text-gray-900">{registration.inpi_protocol}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            {registration.registration_date && (
              <div>
                <p className="text-xs text-gray-500 mb-1">Data de Registro</p>
                <p className="text-sm font-semibold text-gray-900">
                  {format(new Date(registration.registration_date), "dd/MM/yyyy")}
                </p>
              </div>
            )}
            {registration.expiration_date && (
              <div>
                <p className="text-xs text-gray-500 mb-1">Validade até</p>
                <p className="text-sm font-semibold text-gray-900">
                  {format(new Date(registration.expiration_date), "dd/MM/yyyy")}
                </p>
              </div>
            )}
          </div>

          {registration.needs_professional_help && (
            <div className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <AlertCircle className="w-4 h-4 text-yellow-600" />
              <span className="text-xs text-yellow-700 font-medium">
                Apoio profissional recomendado
              </span>
            </div>
          )}

          <Link to={createPageUrl(`IPRegistration?id=${registration.id}`)}>
            <Button variant="outline" size="sm" className="w-full">
              Ver Detalhes
            </Button>
          </Link>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const InfoCard = ({ title, description, icon: Icon, color, link }) => (
  <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 group">
    <div className={`h-2 bg-gradient-to-r ${color}`} />
    <CardContent className="p-6">
      <div className="flex items-start gap-4">
        <div className={`p-3 rounded-xl bg-gradient-to-br ${color} group-hover:scale-110 transition-transform`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="font-bold text-gray-900 mb-2">{title}</h3>
          <p className="text-sm text-gray-600 mb-4">{description}</p>
          {link && (
            <a href={link} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">
              Acessar <ExternalLink className="w-4 h-4" />
            </a>
          )}
        </div>
      </div>
    </CardContent>
  </Card>
);

export default function IntellectualProperty() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [hasActiveSubscription, setHasActiveSubscription] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const isAuthenticated = await base44.auth.isAuthenticated();
        
        if (!isAuthenticated) {
          base44.auth.redirectToLogin(window.location.pathname);
          return;
        }

        const userData = await base44.auth.me();
        setUser(userData);

        // ✅ VERIFICAR SE É ADMIN
        const adminStatus = isAdminUser(userData.email);
        setIsAdmin(adminStatus);

        // Verificar se tem assinatura ativa (ADMIN não precisa)
        if (adminStatus) {
          setHasActiveSubscription(true);
        } else {
          const subscriptions = await base44.entities.Subscription.filter({ 
            user_email: userData.email 
          });
          
          const activeSubscription = subscriptions.find(
            sub => sub.status === 'authorized' || sub.status === 'pending'
          );

          if (!activeSubscription) {
            navigate(createPageUrl("Subscriptions"));
            return;
          }

          setHasActiveSubscription(true);
        }

        setIsCheckingAuth(false);
      } catch (error) {
        console.error("Error loading user:", error);
        base44.auth.redirectToLogin(window.location.pathname);
      }
    };
    loadUser();
  }, [navigate]);

  const { data: registrations = [], isLoading } = useQuery({
    queryKey: ['ip-registrations', user?.email],
    queryFn: () => base44.entities.IntellectualProperty.filter({ owner_email: user?.email }, '-created_date'),
    enabled: !!user?.email,
  });

  const activeRegistrations = registrations.filter(r => r.status !== 'expirado');
  const needsRenewal = registrations.filter(r => r.status === 'renovacao_necessaria');
  const registered = registrations.filter(r => r.status === 'registrado');

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-6">
            <div>
              <div className="flex items-center gap-4 mb-3">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-xl">
                  <Shield className="w-10 h-10 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent">
                    Proteção Legal
                  </h1>
                  <p className="text-lg text-gray-600 mt-1">Sistema de Patentes e Registro de Marcas</p>
                </div>
              </div>
              <p className="text-gray-600 max-w-3xl">
                Proteja suas ideias e projetos com segurança jurídica. Registre marcas, patentes e direitos autorais de forma guiada e simplificada.
              </p>
            </div>
            <Link to={createPageUrl("IPRegistration")}>
              <Button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 shadow-lg px-8 py-6 text-lg">
                <Plus className="w-5 h-5 mr-2" />
                Novo Registro
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="border-none shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Total de Registros</p>
                    <p className="text-3xl font-bold text-gray-900">{activeRegistrations.length}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600">
                    <FileText className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Registrados</p>
                    <p className="text-3xl font-bold text-emerald-600">{registered.length}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Necessitam Renovação</p>
                    <p className="text-3xl font-bold text-orange-600">{needsRenewal.length}</p>
                  </div>
                  <div className="p-3 rounded-xl bg-gradient-to-br from-orange-500 to-orange-600">
                    <Clock className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>

        {/* Protection Types Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
            <BookOpen className="w-7 h-7 text-blue-600" />
            Tipos de Proteção Disponíveis
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Object.entries(protectionTypeInfo).map(([key, info]) => (
              <Card key={key} className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
                <div className={`h-2 bg-gradient-to-r ${info.color}`} />
                <CardContent className="p-6">
                  <div className="flex items-start gap-3 mb-4">
                    <div className={`p-2 rounded-lg bg-gradient-to-br ${info.color}`}>
                      <info.icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900 mb-1">{info.name}</h3>
                      <p className="text-xs text-gray-500">Validade: {info.validity}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">{info.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>

        {/* Quick Links */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
            <ExternalLink className="w-7 h-7 text-purple-600" />
            Links Úteis para Registro
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <InfoCard
              title="INPI - Marcas"
              description="Registro oficial de marcas e logotipos no Brasil"
              icon={Shield}
              color="from-blue-500 to-blue-600"
              link="https://www.gov.br/inpi/pt-br/servicos/marcas"
            />
            <InfoCard
              title="INPI - Patentes"
              description="Registro de patentes de invenção e modelos de utilidade"
              icon={Shield}
              color="from-purple-500 to-purple-600"
              link="https://www.gov.br/inpi/pt-br/servicos/patentes"
            />
            <InfoCard
              title="INPI - Programas de Computador"
              description="Proteção de software, apps e sistemas"
              icon={Shield}
              color="from-emerald-500 to-emerald-600"
              link="https://www.gov.br/inpi/pt-br/servicos/programas-de-computador"
            />
            <InfoCard
              title="Biblioteca Nacional - Direitos Autorais"
              description="Registro de obras artísticas, literárias e musicais"
              icon={BookOpen}
              color="from-yellow-500 to-yellow-600"
              link="https://www.bn.gov.br/servicos/direitos-autorais"
            />
          </div>
        </motion.div>

        {/* User Registrations */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
            <FileText className="w-7 h-7 text-emerald-600" />
            Meus Registros
          </h2>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="h-64 animate-pulse bg-gray-100" />
              ))}
            </div>
          ) : registrations.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {registrations.map((registration) => (
                <ProtectionCard key={registration.id} registration={registration} />
              ))}
            </div>
          ) : (
            <Card className="border-2 border-dashed border-gray-300 p-12 text-center">
              <Shield className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Nenhum registro ainda
              </h3>
              <p className="text-gray-600 mb-6">
                Proteja suas ideias e projetos iniciando seu primeiro registro
              </p>
              <Link to={createPageUrl("IPRegistration")}>
                <Button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Iniciar Primeiro Registro
                </Button>
              </Link>
            </Card>
          )}
        </motion.div>

        {/* Support Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-12"
        >
          <Card className="border-none shadow-xl bg-gradient-to-r from-blue-50 to-purple-50">
            <CardContent className="p-8">
              <div className="flex items-start gap-6">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">
                    Precisa de Ajuda Profissional?
                  </h3>
                  <p className="text-gray-700 mb-6">
                    Não conseguiu registrar sozinho? Tudo bem. O importante é não desistir.
                    Um contador ou consultor de propriedade intelectual pode te ajudar a proteger sua ideia e abrir sua empresa com segurança.
                  </p>
                  <div className="flex flex-wrap gap-4">
                    <Button variant="outline" className="border-blue-600 text-blue-600 hover:bg-blue-50">
                      Buscar Contador
                    </Button>
                    <Button variant="outline" className="border-purple-600 text-purple-600 hover:bg-purple-50">
                      Consultor de PI
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}