import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  MessageCircle,
  Send,
  Sparkles,
  Globe,
  Zap,
  HelpCircle,
  Rocket,
  DollarSign,
  Crown,
  BookOpen,
  Phone,
  Mail,
  MessageSquare,
  Loader2,
  Trash2,
  Plus
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import MessageBubble from "../components/support/MessageBubble";

const QuickQuestion = ({ question, onClick }) => (
  <motion.button
    whileHover={{ scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
    onClick={onClick}
    className="p-4 text-left bg-gradient-to-br from-white to-gray-50 border-2 border-gray-200 rounded-xl hover:border-emerald-400 hover:shadow-lg transition-all"
  >
    <div className="flex items-start gap-3">
      <HelpCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
      <p className="text-sm font-medium text-gray-900">{question}</p>
    </div>
  </motion.button>
);

export default function Support() {
  const [user, setUser] = useState(null);
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [isLoadingConversation, setIsLoadingConversation] = useState(true);
  const messagesEndRef = useRef(null);

  const quickQuestions = [
    "Como criar um projeto na plataforma?",
    "Como funciona o investimento?",
    "Quais os benefícios do plano Premium?",
    "Como investidores internacionais podem participar?",
    "Qual a taxa da plataforma?",
    "Como funciona a proteção legal de ideias?"
  ];

  useEffect(() => {
    const loadUser = async () => {
      try {
        const isAuth = await base44.auth.isAuthenticated();
        if (isAuth) {
          const userData = await base44.auth.me();
          setUser(userData);
        }
      } catch (error) {
        console.log("User not authenticated");
      }
    };
    loadUser();
  }, []);

  useEffect(() => {
    const initConversation = async () => {
      try {
        // Buscar conversa existente
        const conversations = await base44.agents.listConversations({
          agent_name: "support"
        });

        if (conversations.length > 0) {
          const existingConv = conversations[0];
          setConversation(existingConv);
          setMessages(existingConv.messages || []);
        } else {
          // Criar nova conversa
          const newConv = await base44.agents.createConversation({
            agent_name: "support",
            metadata: {
              name: "Suporte - " + (user?.full_name || "Visitante"),
              description: "Conversa de suporte"
            }
          });
          setConversation(newConv);
          setMessages(newConv.messages || []);
        }
      } catch (error) {
        console.error("Error loading conversation:", error);
      } finally {
        setIsLoadingConversation(false);
      }
    };

    initConversation();
  }, [user]);

  useEffect(() => {
    if (!conversation) return;

    const unsubscribe = base44.agents.subscribeToConversation(conversation.id, (data) => {
      setMessages(data.messages || []);
      setIsSending(false);
    });

    return () => unsubscribe();
  }, [conversation]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async (text) => {
    if (!text.trim() || !conversation) return;

    setIsSending(true);
    setInputMessage("");

    try {
      await base44.agents.addMessage(conversation, {
        role: "user",
        content: text
      });
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("Erro ao enviar mensagem");
      setIsSending(false);
    }
  };

  const handleQuickQuestion = (question) => {
    handleSendMessage(question);
  };

  const handleNewConversation = async () => {
    try {
      const newConv = await base44.agents.createConversation({
        agent_name: "support",
        metadata: {
          name: "Suporte - " + (user?.full_name || "Visitante"),
          description: "Nova conversa de suporte"
        }
      });
      setConversation(newConv);
      setMessages([]);
    } catch (error) {
      console.error("Error creating new conversation:", error);
      toast.error("Erro ao criar nova conversa");
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/30 via-blue-50/30 to-purple-50/30">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500 via-blue-500 to-purple-500 shadow-xl">
              <MessageCircle className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-emerald-600 via-blue-600 to-purple-600 bg-clip-text text-transparent">
                Central de Suporte
              </h1>
              <p className="text-lg text-gray-600 mt-1">
                Atendimento IA 24/7 em Português e Inglês
              </p>
            </div>
          </div>
        </motion.div>

        {/* Quick Access Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-none shadow-lg bg-gradient-to-br from-emerald-50 to-white hover:shadow-xl transition-all cursor-pointer">
            <CardContent className="p-6 text-center">
              <Rocket className="w-10 h-10 text-emerald-600 mx-auto mb-3" />
              <p className="font-semibold text-gray-900">Criar Projeto</p>
              <p className="text-xs text-gray-600 mt-1">Guia completo</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-white hover:shadow-xl transition-all cursor-pointer">
            <CardContent className="p-6 text-center">
              <DollarSign className="w-10 h-10 text-blue-600 mx-auto mb-3" />
              <p className="font-semibold text-gray-900">Como Investir</p>
              <p className="text-xs text-gray-600 mt-1">Passo a passo</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-white hover:shadow-xl transition-all cursor-pointer">
            <CardContent className="p-6 text-center">
              <Crown className="w-10 h-10 text-purple-600 mx-auto mb-3" />
              <p className="font-semibold text-gray-900">Premium</p>
              <p className="text-xs text-gray-600 mt-1">Benefícios</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-white hover:shadow-xl transition-all cursor-pointer">
            <CardContent className="p-6 text-center">
              <Globe className="w-10 h-10 text-orange-600 mx-auto mb-3" />
              <p className="font-semibold text-gray-900">Internacional</p>
              <p className="text-xs text-gray-600 mt-1">Investidores</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Chat Area */}
          <div className="lg:col-span-2">
            <Card className="border-none shadow-2xl h-[600px] flex flex-col">
              <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50 border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="w-6 h-6 text-emerald-600" />
                    Assistente IA
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-emerald-500 text-white">
                      <Zap className="w-3 h-3 mr-1" />
                      Online
                    </Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleNewConversation}
                      className="gap-2"
                    >
                      <Plus className="w-4 h-4" />
                      Nova Conversa
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="flex-1 overflow-y-auto p-6 space-y-4">
                {isLoadingConversation ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
                  </div>
                ) : messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <div className="p-6 rounded-full bg-gradient-to-br from-emerald-500 to-blue-500 mb-4">
                      <MessageCircle className="w-12 h-12 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      Olá! Como posso ajudar?
                    </h3>
                    <p className="text-gray-600 mb-6 max-w-md">
                      Estou aqui para responder suas dúvidas sobre projetos, investimentos, assinaturas e tudo sobre a plataforma Brasil Superávit!
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-2xl">
                      {quickQuestions.slice(0, 4).map((q, idx) => (
                        <QuickQuestion key={idx} question={q} onClick={() => handleQuickQuestion(q)} />
                      ))}
                    </div>
                  </div>
                ) : (
                  <AnimatePresence>
                    {messages.map((msg, idx) => (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <MessageBubble message={msg} />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                )}
                <div ref={messagesEndRef} />
              </CardContent>

              {/* Input Area */}
              <div className="p-4 border-t bg-gray-50">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage(inputMessage);
                  }}
                  className="flex gap-3"
                >
                  <Input
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder="Digite sua dúvida..."
                    disabled={isSending}
                    className="flex-1 h-12 text-base"
                  />
                  <Button
                    type="submit"
                    disabled={!inputMessage.trim() || isSending}
                    className="h-12 px-6 bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600"
                  >
                    {isSending ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <Send className="w-5 h-5" />
                    )}
                  </Button>
                </form>
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Questions */}
            {messages.length > 0 && (
              <Card className="border-none shadow-xl">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Zap className="w-5 h-5 text-purple-600" />
                    Perguntas Rápidas
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 space-y-2">
                  {quickQuestions.map((q, idx) => (
                    <Button
                      key={idx}
                      variant="outline"
                      size="sm"
                      onClick={() => handleQuickQuestion(q)}
                      className="w-full justify-start text-left h-auto py-3 px-4 hover:bg-purple-50 hover:border-purple-300"
                    >
                      <HelpCircle className="w-4 h-4 mr-2 flex-shrink-0 text-purple-600" />
                      <span className="text-xs">{q}</span>
                    </Button>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* WhatsApp Integration */}
            <Card className="border-none shadow-xl bg-gradient-to-br from-green-50 to-emerald-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Phone className="w-5 h-5 text-green-600" />
                  WhatsApp
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 space-y-3">
                <p className="text-sm text-gray-700">
                  Prefere falar pelo WhatsApp? Conecte-se agora!
                </p>
                <a 
                  href={base44.agents.getWhatsAppConnectURL('support')} 
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button className="w-full bg-green-600 hover:bg-green-700 gap-2">
                    <MessageSquare className="w-4 h-4" />
                    Abrir no WhatsApp
                  </Button>
                </a>
              </CardContent>
            </Card>

            {/* Help Topics */}
            <Card className="border-none shadow-xl">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                  Tópicos de Ajuda
                </CardTitle>
              </CardHeader>
              <CardContent className="p-4 space-y-2">
                {[
                  { icon: Rocket, label: "Projetos", color: "text-blue-600" },
                  { icon: DollarSign, label: "Investimentos", color: "text-emerald-600" },
                  { icon: Crown, label: "Assinaturas", color: "text-purple-600" },
                  { icon: Globe, label: "Internacional", color: "text-orange-600" }
                ].map((topic, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer">
                    <topic.icon className={`w-5 h-5 ${topic.color}`} />
                    <span className="text-sm font-medium text-gray-900">{topic.label}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card className="border-none shadow-xl bg-gradient-to-br from-gray-50 to-white">
              <CardContent className="p-6 space-y-3">
                <h3 className="font-bold text-gray-900 flex items-center gap-2">
                  <Mail className="w-5 h-5 text-gray-600" />
                  Outros Canais
                </h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <p className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    suporte@brasilsuperavit.com
                  </p>
                  <p className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Atendimento 24/7 via IA
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}