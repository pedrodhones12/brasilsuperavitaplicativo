import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Video,
  Calendar,
  Globe,
  Users,
  Clock,
  Brain,
  FileText,
  MessageCircle,
  Settings,
  Plus,
  CheckCircle,
  AlertCircle,
  PlayCircle,
  Sparkles,
  Lock
} from "lucide-react";
import { motion } from "framer-motion";
import { format, formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

// ✅ FUNÇÃO PARA VERIFICAR SE É ADMIN
const isAdminUser = (email) => {
  const adminEmails = ['pedrodhones15@gmail.com', 'pedrodhones15.com'];
  return adminEmails.some(adminEmail => email?.toLowerCase().includes(adminEmail.toLowerCase()));
};

const meetingTypeInfo = {
  projeto: { label: "Reunião de Projeto", color: "from-blue-500 to-blue-600", icon: FileText },
  parceria: { label: "Parceria e Investimento", color: "from-purple-500 to-purple-600", icon: Users },
  mentoria: { label: "Mentoria", color: "from-emerald-500 to-emerald-600", icon: Brain },
  consultoria: { label: "Consultoria", color: "from-orange-500 to-orange-600", icon: MessageCircle },
  outro: { label: "Outro", color: "from-gray-500 to-gray-600", icon: Calendar }
};

const statusInfo = {
  agendada: { label: "Agendada", color: "bg-blue-100 text-blue-800", icon: Clock },
  em_andamento: { label: "Em Andamento", color: "bg-emerald-100 text-emerald-800", icon: PlayCircle },
  concluida: { label: "Concluída", color: "bg-gray-100 text-gray-800", icon: CheckCircle },
  cancelada: { label: "Cancelada", color: "bg-red-100 text-red-800", icon: AlertCircle }
};

const MeetingCard = ({ meeting, user }) => {
  const typeInfo = meetingTypeInfo[meeting.meeting_type];
  const TypeIcon = typeInfo.icon;
  const statusData = statusInfo[meeting.status];
  const StatusIcon = statusData.icon;

  const isOrganizer = meeting.organizer_email === user?.email;
  const meetingDate = new Date(meeting.meeting_date);
  const isPast = meetingDate < new Date();
  const isUpcoming = !isPast && meeting.status === 'agendada';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
        <div className={`h-2 bg-gradient-to-r ${typeInfo.color}`} />
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <TypeIcon className="w-5 h-5 text-gray-600" />
                <CardTitle className="text-xl">{meeting.title}</CardTitle>
              </div>
              {isOrganizer && (
                <Badge variant="outline" className="mb-2">
                  Você é o organizador
                </Badge>
              )}
            </div>
            <Badge className={statusData.color}>
              <StatusIcon className="w-3 h-3 mr-1" />
              {statusData.label}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Calendar className="w-4 h-4" />
              <span>{format(meetingDate, "dd MMM yyyy", { locale: ptBR })}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Clock className="w-4 h-4" />
              <span>{format(meetingDate, "HH:mm")}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Users className="w-4 h-4" />
              <span>{meeting.participants?.length || 0} participantes</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Globe className="w-4 h-4" />
              <span>{meeting.primary_language?.toUpperCase()}</span>
            </div>
          </div>

          {meeting.description && (
            <p className="text-sm text-gray-700 line-clamp-2">{meeting.description}</p>
          )}

          {meeting.ai_summary && (
            <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
              <div className="flex items-center gap-2 mb-2">
                <Brain className="w-4 h-4 text-purple-600" />
                <span className="text-xs font-semibold text-purple-900">Resumo IA</span>
              </div>
              <p className="text-sm text-purple-900 line-clamp-2">{meeting.ai_summary}</p>
            </div>
          )}

          <div className="flex flex-wrap gap-2">
            {meeting.translation_enabled && (
              <Badge variant="outline" className="text-xs">
                <Globe className="w-3 h-3 mr-1" />
                Tradução
              </Badge>
            )}
            {meeting.ai_notes_enabled && (
              <Badge variant="outline" className="text-xs">
                <Brain className="w-3 h-3 mr-1" />
                Notas IA
              </Badge>
            )}
            {meeting.recording_enabled && (
              <Badge variant="outline" className="text-xs">
                <Video className="w-3 h-3 mr-1" />
                Gravação
              </Badge>
            )}
          </div>

          <div className="flex gap-2 pt-2">
            {isUpcoming && (
              <Button className="flex-1 bg-gradient-to-r from-emerald-500 to-blue-500">
                <Video className="w-4 h-4 mr-2" />
                Entrar na Reunião
              </Button>
            )}
            {meeting.status === 'concluida' && (
              <Button variant="outline" className="flex-1">
                <FileText className="w-4 h-4 mr-2" />
                Ver Relatório
              </Button>
            )}
            {isOrganizer && meeting.status === 'agendada' && (
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Configurar
              </Button>
            )}
          </div>

          {isUpcoming && (
            <p className="text-xs text-center text-gray-500">
              Começa em {formatDistanceToNow(meetingDate, { locale: ptBR })}
            </p>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function Meetings() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("upcoming");
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [hasActiveSubscription, setHasActiveSubscription] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const checkAuthAndLoadUser = async () => {
      try {
        const isAuthenticated = await base44.auth.isAuthenticated();
        
        if (!isAuthenticated) {
          base44.auth.redirectToLogin(window.location.pathname);
          return;
        }

        const userData = await base44.auth.me();
        setUser(userData);

        // ✅ VERIFICAR SE É ADMIN
        const adminStatus = isAdminUser(userData.email);
        setIsAdmin(adminStatus);

        // Verificar se tem assinatura ativa (ADMIN não precisa)
        if (adminStatus) {
          setHasActiveSubscription(true);
          setIsCheckingAuth(false);
        } else {
          const subscriptions = await base44.entities.Subscription.filter({ 
            user_email: userData.email 
          });
          
          const activeSubscription = subscriptions.find(
            sub => sub.status === 'authorized' || sub.status === 'pending'
          );

          if (!activeSubscription) {
            navigate(createPageUrl("Subscriptions"));
            return;
          }

          setHasActiveSubscription(true);
          setIsCheckingAuth(false);
        }
      } catch (error) {
        console.error("Auth error:", error);
        base44.auth.redirectToLogin(window.location.pathname);
      }
    };

    checkAuthAndLoadUser();
  }, [navigate]);

  const { data: meetings = [], isLoading } = useQuery({
    queryKey: ['meetings', user?.email],
    queryFn: async () => {
      const allMeetings = await base44.entities.Meeting.list('-meeting_date');
      return allMeetings.filter(meeting => 
        meeting.organizer_email === user?.email || 
        meeting.participants?.some(p => p.email === user?.email)
      );
    },
    enabled: !!user?.email && hasActiveSubscription,
  });

  if (isCheckingAuth || !hasActiveSubscription) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 animate-pulse">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Verificando acesso Premium...</h2>
            <p className="text-gray-600">Redirecionando para ativação...</p>
          </div>
        </Card>
      </div>
    );
  }

  const now = new Date();
  const upcomingMeetings = meetings.filter(m => 
    new Date(m.meeting_date) > now && m.status === 'agendada'
  );
  const pastMeetings = meetings.filter(m => 
    new Date(m.meeting_date) < now || m.status === 'concluida'
  );
  const activeMeetings = meetings.filter(m => m.status === 'em_andamento');

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
              <div className="flex items-center gap-4 mb-3">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-500 shadow-xl">
                  <Video className="w-10 h-10 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent">
                    Reuniões Inteligentes
                  </h1>
                  <p className="text-xl text-gray-600 mt-1">
                    Conecte-se globalmente com IA assistiva
                  </p>
                </div>
              </div>
            </div>
            <Link to={createPageUrl("ScheduleMeeting")}>
              <Button size="lg" className="bg-gradient-to-r from-blue-500 to-purple-600 shadow-lg px-8 py-6 text-lg">
                <Plus className="w-5 h-5 mr-2" />
                Agendar Reunião
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="border-none shadow-lg">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Próximas</p>
                    <p className="text-2xl font-bold text-gray-900">{upcomingMeetings.length}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600">
                    <Calendar className="w-5 h-5 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Ativas</p>
                    <p className="text-2xl font-bold text-gray-900">{activeMeetings.length}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-600">
                    <PlayCircle className="w-5 h-5 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Realizadas</p>
                    <p className="text-2xl font-bold text-gray-900">{pastMeetings.length}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-gradient-to-br from-gray-500 to-gray-600">
                    <CheckCircle className="w-5 h-5 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Total</p>
                    <p className="text-2xl font-bold text-gray-900">{meetings.length}</p>
                  </div>
                  <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-purple-600">
                    <Users className="w-5 h-5 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>

        {/* Meetings List */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <Card className="border-none shadow-xl mb-6">
            <CardContent className="p-4">
              <TabsList className="bg-gray-100 w-full">
                <TabsTrigger value="upcoming" className="flex-1">
                  <Clock className="w-4 h-4 mr-2" />
                  Próximas ({upcomingMeetings.length})
                </TabsTrigger>
                <TabsTrigger value="active" className="flex-1">
                  <PlayCircle className="w-4 h-4 mr-2" />
                  Ativas ({activeMeetings.length})
                </TabsTrigger>
                <TabsTrigger value="past" className="flex-1">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Passadas ({pastMeetings.length})
                </TabsTrigger>
              </TabsList>
            </CardContent>
          </Card>

          <TabsContent value="upcoming" className="mt-6">
            {upcomingMeetings.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-6">
                {upcomingMeetings.map(meeting => (
                  <MeetingCard key={meeting.id} meeting={meeting} user={user} />
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center border-2 border-dashed">
                <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 text-lg mb-4">Nenhuma reunião agendada</p>
                <Link to={createPageUrl("ScheduleMeeting")}>
                  <Button className="bg-gradient-to-r from-blue-500 to-purple-600">
                    Agendar Primeira Reunião
                  </Button>
                </Link>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="active" className="mt-6">
            {activeMeetings.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-6">
                {activeMeetings.map(meeting => (
                  <MeetingCard key={meeting.id} meeting={meeting} user={user} />
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center border-2 border-dashed">
                <PlayCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Nenhuma reunião ativa no momento</p>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="past" className="mt-6">
            {pastMeetings.length > 0 ? (
              <div className="grid md:grid-cols-2 gap-6">
                {pastMeetings.map(meeting => (
                  <MeetingCard key={meeting.id} meeting={meeting} user={user} />
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center border-2 border-dashed">
                <CheckCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Nenhuma reunião realizada ainda</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        {/* AI Features Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12"
        >
          <Card className="border-none shadow-2xl overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-purple-500 via-blue-500 to-emerald-500" />
            <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
              <CardTitle className="flex items-center gap-3 text-2xl">
                <Sparkles className="w-7 h-7 text-purple-600" />
                Recursos Inteligentes Disponíveis
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <div className="grid md:grid-cols-3 gap-6">
                <div className="p-6 rounded-xl bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200">
                  <Brain className="w-10 h-10 text-purple-600 mb-3" />
                  <h3 className="font-bold text-gray-900 mb-2">Notas Automáticas</h3>
                  <p className="text-sm text-gray-700">A IA transcreve e resume tudo automaticamente</p>
                </div>
                <div className="p-6 rounded-xl bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200">
                  <Globe className="w-10 h-10 text-blue-600 mb-3" />
                  <h3 className="font-bold text-gray-900 mb-2">Tradução Simultânea</h3>
                  <p className="text-sm text-gray-700">Comunique-se em qualquer idioma em tempo real</p>
                </div>
                <div className="p-6 rounded-xl bg-gradient-to-br from-emerald-50 to-emerald-100 border border-emerald-200">
                  <FileText className="w-10 h-10 text-emerald-600 mb-3" />
                  <h3 className="font-bold text-gray-900 mb-2">Relatórios Inteligentes</h3>
                  <p className="text-sm text-gray-700">Gere relatórios completos após cada reunião</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}