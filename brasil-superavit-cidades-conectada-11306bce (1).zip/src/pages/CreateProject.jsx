
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useNavigate, Link } from "react-router-dom"; // Added Link
import { createPageUrl } from "@/utils";
import { 
  Rocket, 
  Upload, 
  CheckCircle,
  AlertCircle,
  Sparkles,
  Lightbulb,
  Wand2,
  RefreshCw,
  Copy,
  Brain,
  TrendingUp,
  Building2,
  GraduationCap,
  Heart,
  Palmtree,
  ShoppingBag,
  Leaf,
  Lock,
  UserPlus,
  Crown // Added Crown icon
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// ✅ FUNÇÃO PARA VERIFICAR SE É ADMIN
const isAdminUser = (email) => {
  const adminEmails = ['pedrodhones15@gmail.com', 'pedrodhones15.com'];
  return adminEmails.some(adminEmail => email?.toLowerCase().includes(adminEmail.toLowerCase()));
};

const brazilianStates = [
  "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA",
  "MT", "MS", "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN",
  "RS", "RO", "RR", "SC", "SP", "SE", "TO"
];

const sectorInfo = {
  tecnologico: {
    name: "Tecnológico",
    color: "from-blue-500 to-blue-600",
    icon: Rocket,
    examples: "Smart cities, apps urbanos, iluminação solar",
    description: "Inovação digital e tecnologia aplicada ao urbano"
  },
  cultural: {
    name: "Cultural",
    color: "from-purple-500 to-purple-600",
    icon: Sparkles,
    examples: "Arte, música, cinema, produtos personalizados",
    description: "Arte, música, cinema e identidade local"
  },
  sustentabilidade: {
    name: "Sustentabilidade",
    color: "from-emerald-500 to-emerald-600",
    icon: Leaf,
    examples: "Energia solar, reciclagem, agricultura urbana",
    description: "Energia limpa, reciclagem e economia verde"
  },
  infraestrutura: {
    name: "Infraestrutura e Mobilidade",
    color: "from-orange-500 to-orange-600",
    icon: Building2,
    examples: "Transporte público, estradas, conectividade",
    description: "Mobilidade urbana e conectividade regional"
  },
  educacao: {
    name: "Educação e Capacitação",
    color: "from-indigo-500 to-indigo-600",
    icon: GraduationCap,
    examples: "Plataformas de ensino, escolas técnicas, cursos online",
    description: "Fortalece capital humano e aprendizado"
  },
  saude: {
    name: "Saúde e Bem-Estar",
    color: "from-red-500 to-pink-600",
    icon: Heart,
    examples: "Clínicas populares, telemedicina, terapias",
    description: "Qualidade de vida e acesso à saúde"
  },
  turismo: {
    name: "Turismo e Economia Local",
    color: "from-cyan-500 to-teal-600",
    icon: Palmtree,
    examples: "Ecoturismo, pousadas, produtos regionais",
    description: "Potencial turístico e cultural local"
  },
  comercio: {
    name: "Comércio e Serviços",
    color: "from-amber-500 to-yellow-600",
    icon: ShoppingBag,
    examples: "Marketplaces, delivery local, serviços autônomos",
    description: "Estimula empreendedorismo e comércio digital"
  },
  inovacao: {
    name: "Inovação e Startups",
    color: "from-violet-500 to-fuchsia-600",
    icon: Lightbulb,
    examples: "Startups, tecnologia disruptiva, hubs",
    description: "Tecnologia de ponta e inovação radical"
  }
};

const AIProjectCard = ({ project, onSelect }) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (field, value) => {
    navigator.clipboard.writeText(value);
    setCopied(field);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.2 }}
    >
      <Card className="border-2 border-purple-200 hover:border-purple-400 transition-all duration-300 cursor-pointer overflow-hidden group">
        <div className="h-1 bg-gradient-to-r from-purple-500 via-blue-500 to-emerald-500" />
        <CardContent className="p-6 space-y-4">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Lightbulb className="w-5 h-5 text-yellow-500" />
                <h3 className="font-bold text-lg text-gray-900">{project.name}</h3>
              </div>
              <p className="text-sm text-gray-600 mb-3">{project.description}</p>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <span className="text-xs text-gray-500">Nome sugerido:</span>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm">{project.name}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCopy('name', project.name);
                      }}
                    >
                      {copied === 'name' ? (
                        <CheckCircle className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </div>

                {project.tagline && (
                  <div className="p-2 bg-blue-50 rounded">
                    <span className="text-xs text-blue-600 font-medium">"{project.tagline}"</span>
                  </div>
                )}

                {project.impact && (
                  <div className="p-2 bg-emerald-50 rounded">
                    <span className="text-xs text-emerald-700">
                      <strong>Impacto:</strong> {project.impact}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <Button
            onClick={() => onSelect(project)}
            className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
          >
            Usar Esta Ideia
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function CreateProject() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("brainstorm");
  const [uploadingImage, setUploadingImage] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [user, setUser] = useState(null);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [hasActiveSubscription, setHasActiveSubscription] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  
  const [formData, setFormData] = useState({
    title: "",
    city: "",
    state: "",
    description: "",
    sector: "",
    funding_goal: "",
    minimum_investment: "5000",
    start_date: "",
    end_date: "",
    image_url: "",
    budget_details: "",
    expected_impact: "",
    status: "ativa",
  });

  React.useEffect(() => {
    const checkAuthAndLoadUser = async () => {
      try {
        const isAuthenticated = await base44.auth.isAuthenticated();
        
        if (!isAuthenticated) {
          base44.auth.redirectToLogin(window.location.pathname);
          return;
        }

        const userData = await base44.auth.me();
        setUser(userData);

        // ✅ VERIFICAR SE É ADMIN
        const adminStatus = isAdminUser(userData.email);
        setIsAdmin(adminStatus);

        // Verificar se tem assinatura ativa (ADMIN não precisa)
        if (adminStatus) {
          setHasActiveSubscription(true);
        } else {
          const subscriptions = await base44.entities.Subscription.filter({ 
            user_email: userData.email 
          });
          
          const activeSubscription = subscriptions.find(
            sub => sub.status === 'authorized' || sub.status === 'pending'
          );

          setHasActiveSubscription(!!activeSubscription);
        }
        
        setIsCheckingAuth(false);
      } catch (error) {
        console.error("Auth error:", error);
        base44.auth.redirectToLogin(window.location.pathname);
      }
    };

    checkAuthAndLoadUser();
  }, [navigate]);

  const createProjectMutation = useMutation({
    mutationFn: (projectData) => base44.entities.Project.create(projectData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      navigate(createPageUrl("Projects"));
    },
  });

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingImage(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    handleInputChange('image_url', file_url);
    setUploadingImage(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // ✅ VERIFICAR ASSINATURA NO MOMENTO DE PUBLICAR (ADMIN NÃO PRECISA)
    if (!hasActiveSubscription && !isAdmin) {
      navigate(createPageUrl("Subscriptions"));
      return;
    }
    
    const projectData = {
      ...formData,
      funding_goal: parseFloat(formData.funding_goal),
      minimum_investment: parseFloat(formData.minimum_investment),
      current_funding: 0,
      investors_count: 0,
    };

    createProjectMutation.mutate(projectData);
  };

  const generateAIIdeas = async () => {
    if (!formData.sector) {
      alert("Por favor, selecione um setor primeiro");
      return;
    }

    setIsGenerating(true);
    
    try {
      const sector = sectorInfo[formData.sector];
      const userInterests = user?.interests?.join(", ") || "desenvolvimento local";
      const userProblems = user?.problems_to_solve?.join(", ") || "melhorar a cidade";

      const prompt = `Você é um especialista em inovação e empreendedorismo social no Brasil.

Contexto do usuário:
- Setor escolhido: ${sector.name}
- Descrição do setor: ${sector.description}
- Exemplos do setor: ${sector.examples}
- Interesses: ${userInterests}
- Problemas que quer resolver: ${userProblems}
- Cidade: ${formData.city || "cidades brasileiras"}

Tarefa: Gere 3 ideias criativas e inovadoras de projetos para o setor ${sector.name}, considerando:
1. Os interesses e problemas do usuário
2. O contexto de cidades brasileiras
3. Viabilidade de implementação
4. Impacto social e econômico

Para cada projeto, forneça:
- Nome criativo e memorável (em português)
- Descrição clara e inspiradora (2-3 frases)
- Slogan/tagline impactante
- Impacto esperado na comunidade

Seja criativo, inovador e realista. Foque em projetos que possam realmente transformar cidades brasileiras.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            projects: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  description: { type: "string" },
                  tagline: { type: "string" },
                  impact: { type: "string" }
                }
              }
            }
          }
        }
      });

      if (result.projects && result.projects.length > 0) {
        setAiSuggestions(result.projects);
      }
    } catch (error) {
      console.error("Error generating AI ideas:", error);
      alert("Erro ao gerar ideias. Tente novamente.");
    }
    
    setIsGenerating(false);
  };

  const handleSelectAIProject = (project) => {
    setFormData(prev => ({
      ...prev,
      title: project.name,
      description: project.description,
      expected_impact: project.impact || ""
    }));
    setActiveTab("manual");
  };

  const isFormValid = formData.title && formData.city && formData.state && 
                      formData.description && formData.sector && formData.funding_goal &&
                      formData.start_date && formData.end_date;

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-emerald-50/50 to-blue-50/50">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-blue-500 animate-pulse">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Carregando...</h2>
            <p className="text-gray-600">Por favor, aguarde.</p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/50 to-blue-50/50">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-3">
            <Sparkles className="w-10 h-10 text-yellow-500" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
              Criar Novo Projeto
            </h1>
          </div>
          <p className="text-lg text-gray-600">
            Transforme sua cidade através de projetos inovadores e colaborativos
          </p>
        </motion.div>

        {/* Banner informativo para não-assinantes (NÃO para admin) */}
        {!hasActiveSubscription && !isAdmin && (
          <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="mb-6">
            <Alert className="border-2 border-amber-300 bg-gradient-to-r from-amber-50 via-yellow-50 to-amber-50 shadow-xl">
              <Crown className="h-6 w-6 text-amber-600" />
              <AlertDescription className="text-amber-900">
                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
                  <div className="flex-1">
                    <strong className="block text-xl mb-2">📝 Crie Seu Projeto Livremente!</strong>
                    <p className="text-base mb-2">Você pode preencher todos os dados do seu projeto. Para <strong>publicar</strong> e receber investimentos, você precisará de uma assinatura Premium.</p>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <Badge className="bg-emerald-600 text-white text-xs px-2 py-1">✅ Criação Gratuita</Badge>
                      <Badge className="bg-blue-600 text-white text-xs px-2 py-1">🚀 Publicação Premium</Badge>
                      <Badge className="bg-purple-600 text-white text-xs px-2 py-1">💰 Receba Investimentos</Badge>
                    </div>
                  </div>
                  <Link to={createPageUrl("Subscriptions")} className="w-full lg:w-auto">
                    <Button size="lg" className="bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-white shadow-xl h-12 px-6 text-base w-full lg:w-auto whitespace-nowrap">
                      <Crown className="w-5 h-5 mr-2" />
                      Ver Planos
                    </Button>
                  </Link>
                </div>
              </AlertDescription>
            </Alert>
          </motion.div>
        )}

        <Alert className="mb-6 border-blue-200 bg-blue-50">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-900">
            <strong>Taxa da plataforma:</strong> 6,5% sobre o valor arrecadado
          </AlertDescription>
        </Alert>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="border-none shadow-2xl overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-purple-500 via-blue-500 to-emerald-500" />
            <CardHeader className="bg-gradient-to-r from-purple-50 via-blue-50 to-emerald-50">
              <CardTitle className="flex items-center gap-3">
                <Brain className="w-7 h-7 text-purple-600" />
                Assistente IA: Brainstorm de Ideias
              </CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Não sabe por onde começar? Nossa IA pode gerar ideias personalizadas baseadas em seus interesses!
              </p>
            </CardHeader>
            <CardContent className="p-6">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="brainstorm" className="gap-2">
                    <Wand2 className="w-4 h-4" />
                    IA Brainstorm
                  </TabsTrigger>
                  <TabsTrigger value="manual" className="gap-2">
                    <Rocket className="w-4 h-4" />
                    Criação Manual
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="brainstorm" className="space-y-6">
                  <div className="space-y-4">
                    <Label className="text-base font-semibold">
                      Escolha o setor para gerar ideias
                    </Label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {Object.entries(sectorInfo).map(([key, info]) => {
                        const Icon = info.icon;
                        return (
                          <div
                            key={key}
                            onClick={() => handleInputChange('sector', key)}
                            className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                              formData.sector === key
                                ? 'border-purple-500 bg-purple-50 shadow-lg'
                                : 'border-gray-200 hover:border-purple-300'
                            }`}
                          >
                            <div className={`p-3 rounded-lg bg-gradient-to-br ${info.color} w-fit mb-3`}>
                              <Icon className="w-6 h-6 text-white" />
                            </div>
                            <h4 className="font-bold text-gray-900 mb-1">{info.name}</h4>
                            <p className="text-xs text-gray-600">{info.description}</p>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {user && (user.interests?.length > 0 || user.problems_to_solve?.length > 0) && (
                    <Alert className="border-emerald-200 bg-emerald-50">
                      <Lightbulb className="h-4 w-4 text-emerald-600" />
                      <AlertDescription className="text-emerald-900">
                        <strong className="block mb-2">Seus interesses cadastrados:</strong>
                        {user.interests?.length > 0 && (
                          <p className="text-sm mb-1">
                            <strong>Habilidades:</strong> {user.interests.join(", ")}
                          </p>
                        )}
                        {user.problems_to_solve?.length > 0 && (
                          <p className="text-sm">
                            <strong>Problemas a resolver:</strong> {user.problems_to_solve.join(", ")}
                          </p>
                        )}
                      </AlertDescription>
                    </Alert>
                  )}

                  <Button
                    onClick={generateAIIdeas}
                    disabled={!formData.sector || isGenerating}
                    className="w-full h-14 text-lg bg-gradient-to-r from-purple-500 via-blue-500 to-emerald-500 hover:from-purple-600 hover:via-blue-600 hover:to-emerald-600 shadow-lg"
                  >
                    {isGenerating ? (
                      <>
                        <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                        Gerando Ideias Inovadoras...
                      </>
                    ) : (
                      <>
                        <Wand2 className="w-5 h-5 mr-2" />
                        Gerar Ideias com IA
                      </>
                    )}
                  </Button>

                  <AnimatePresence>
                    {aiSuggestions.length > 0 && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="space-y-4"
                      >
                        <div className="flex items-center justify-between">
                          <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                            <Sparkles className="w-6 h-6 text-yellow-500" />
                            Ideias Geradas pela IA
                          </h3>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={generateAIIdeas}
                            disabled={isGenerating}
                          >
                            <RefreshCw className="w-4 h-4 mr-2" />
                            Gerar Novas
                          </Button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {aiSuggestions.map((project, index) => (
                            <AIProjectCard
                              key={index}
                              project={project}
                              onSelect={handleSelectAIProject}
                            />
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </TabsContent>

                <TabsContent value="manual">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="title" className="text-base font-semibold">
                            Título do Projeto *
                          </Label>
                          <Input
                            id="title"
                            value={formData.title}
                            onChange={(e) => handleInputChange('title', e.target.value)}
                            placeholder="Ex: Estrada do Progresso Verde"
                            className="h-12"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="sector" className="text-base font-semibold">
                            Setor de Atuação *
                          </Label>
                          <Select value={formData.sector} onValueChange={(value) => handleInputChange('sector', value)}>
                            <SelectTrigger className="h-12">
                              <SelectValue placeholder="Selecione o setor" />
                            </SelectTrigger>
                            <SelectContent 
                              position="popper" 
                              className="max-h-[300px] overflow-y-auto z-50"
                              sideOffset={5}
                            >
                              {Object.entries(sectorInfo).map(([key, info]) => {
                                const Icon = info.icon;
                                return (
                                  <SelectItem key={key} value={key} className="cursor-pointer">
                                    <div className="flex items-center gap-3 py-1">
                                      <Icon className="w-5 h-5 flex-shrink-0" />
                                      <div className="flex-1 min-w-0">
                                        <p className="font-semibold text-sm">{info.name}</p>
                                        <p className="text-xs text-gray-500 truncate">{info.description}</p>
                                      </div>
                                    </div>
                                  </SelectItem>
                                );
                              })}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="city" className="text-base font-semibold">
                            Cidade *
                          </Label>
                          <Input
                            id="city"
                            value={formData.city}
                            onChange={(e) => handleInputChange('city', e.target.value)}
                            placeholder="Ex: Canavieiras"
                            className="h-12"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="state" className="text-base font-semibold">
                            Estado *
                          </Label>
                          <Select value={formData.state} onValueChange={(value) => handleInputChange('state', value)}>
                            <SelectTrigger className="h-12">
                              <SelectValue placeholder="Selecione o estado" />
                            </SelectTrigger>
                            <SelectContent position="popper" className="max-h-[300px] overflow-y-auto z-50">
                              {brazilianStates.map(state => (
                                <SelectItem key={state} value={state}>{state}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="description" className="text-base font-semibold">
                          Descrição do Projeto *
                        </Label>
                        <Textarea
                          id="description"
                          value={formData.description}
                          onChange={(e) => handleInputChange('description', e.target.value)}
                          placeholder="Descreva detalhadamente o impacto e objetivos do seu projeto..."
                          className="min-h-32"
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="expected_impact" className="text-base font-semibold">
                          Impactos Esperados
                        </Label>
                        <Textarea
                          id="expected_impact"
                          value={formData.expected_impact}
                          onChange={(e) => handleInputChange('expected_impact', e.target.value)}
                          placeholder="Quais os benefícios para a comunidade?"
                          className="min-h-24"
                        />
                      </div>
                    </div>

                    <div className="pt-6 border-t border-gray-200">
                      <h3 className="text-xl font-bold text-gray-900 mb-6">Informações Financeiras</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="funding_goal" className="text-base font-semibold">
                            Meta de Investimento (R$) *
                          </Label>
                          <Input
                            id="funding_goal"
                            type="number"
                            min="0"
                            step="0.01"
                            value={formData.funding_goal}
                            onChange={(e) => handleInputChange('funding_goal', e.target.value)}
                            placeholder="Ex: 100000"
                            className="h-12"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="minimum_investment" className="text-base font-semibold">
                            Investimento Mínimo (R$)
                          </Label>
                          <Input
                            id="minimum_investment"
                            type="number"
                            min="5000"
                            step="1000"
                            value={formData.minimum_investment}
                            onChange={(e) => handleInputChange('minimum_investment', e.target.value)}
                            className="h-12"
                          />
                          <p className="text-sm text-gray-500">Mínimo recomendado: R$ 5.000</p>
                        </div>
                      </div>

                      <div className="space-y-2 mt-6">
                        <Label htmlFor="budget_details" className="text-base font-semibold">
                          Detalhamento do Orçamento
                        </Label>
                        <Textarea
                          id="budget_details"
                          value={formData.budget_details}
                          onChange={(e) => handleInputChange('budget_details', e.target.value)}
                          placeholder="Como o investimento será utilizado?"
                          className="min-h-24"
                        />
                      </div>
                    </div>

                    <div className="pt-6 border-t border-gray-200">
                      <h3 className="text-xl font-bold text-gray-900 mb-6">Cronograma da Campanha</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="start_date" className="text-base font-semibold">
                            Data de Início *
                          </Label>
                          <Input
                            id="start_date"
                            type="date"
                            value={formData.start_date}
                            onChange={(e) => handleInputChange('start_date', e.target.value)}
                            className="h-12"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="end_date" className="text-base font-semibold">
                            Data de Término *
                          </Label>
                          <Input
                            id="end_date"
                            type="date"
                            value={formData.end_date}
                            onChange={(e) => handleInputChange('end_date', e.target.value)}
                            className="h-12"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    <div className="pt-6 border-t border-gray-200">
                      <h3 className="text-xl font-bold text-gray-900 mb-6">Imagem do Projeto</h3>
                      <div className="space-y-4">
                        <Label htmlFor="image" className="text-base font-semibold">
                          Upload de Imagem
                        </Label>
                        <div className="flex items-center gap-4">
                          <Input
                            id="image"
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            disabled={uploadingImage}
                            className="h-12"
                          />
                          {uploadingImage && (
                            <div className="text-sm text-gray-500">Enviando...</div>
                          )}
                        </div>
                        {formData.image_url && (
                          <div className="mt-4">
                            <img 
                              src={formData.image_url} 
                              alt="Preview" 
                              className="w-full h-64 object-cover rounded-xl shadow-lg"
                            />
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="pt-8 flex gap-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => navigate(createPageUrl("Projects"))}
                        className="flex-1 h-14 text-base"
                      >
                        Cancelar
                      </Button>
                      <Button
                        type="submit"
                        disabled={!isFormValid || createProjectMutation.isPending}
                        className="flex-1 h-14 text-base bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 shadow-lg"
                      >
                        {createProjectMutation.isPending ? (
                          "Publicando..."
                        ) : (
                          <>
                            <CheckCircle className="w-5 h-5 mr-2" />
                            Publicar Projeto
                          </>
                        )}
                      </Button>
                    </div>
                  </form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
