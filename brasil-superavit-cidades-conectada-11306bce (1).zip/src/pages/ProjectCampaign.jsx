import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  TrendingUp,
  Users,
  DollarSign,
  Calendar,
  Target,
  CheckCircle,
  Share2,
  BarChart3,
  Award,
  Rocket,
  Clock,
  Globe,
  Eye,
  MapPin,
  Sparkles,
  Lightbulb,
  TrendingDown,
  RefreshCw,
  Zap,
  PieChart as PieChartIcon,
  Activity
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format, formatDistanceToNow, subDays, startOfDay, endOfDay } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { PieChart, Pie, Cell, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from "recharts";

const COLORS = ['#059669', '#0284c7', '#8b5cf6', '#f59e0b', '#ef4444', '#06b6d4'];

const categoryColors = {
  bronze: "from-amber-600 to-amber-700",
  prata: "from-gray-400 to-gray-500",
  ouro: "from-yellow-400 to-yellow-600",
};

export default function ProjectCampaign() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [aiInsights, setAiInsights] = useState(null);
  const [isGeneratingInsights, setIsGeneratingInsights] = useState(false);
  const queryClient = useQueryClient();
  
  const urlParams = new URLSearchParams(window.location.search);
  const projectId = urlParams.get('id');

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: project } = useQuery({
    queryKey: ['project', projectId],
    queryFn: async () => {
      const projects = await base44.entities.Project.list();
      return projects.find(p => p.id === projectId);
    },
    enabled: !!projectId,
  });

  const { data: investments = [] } = useQuery({
    queryKey: ['project-investments', projectId],
    queryFn: () => base44.entities.Investment.filter({ 
      project_id: projectId,
      status: 'confirmado'
    }, '-created_date'),
    enabled: !!projectId,
  });

  const { data: allInvestors = [] } = useQuery({
    queryKey: ['project-investors', projectId],
    queryFn: async () => {
      const investorEmails = [...new Set(investments.map(inv => inv.investor_email))];
      const users = await base44.entities.User.list();
      return users.filter(u => investorEmails.includes(u.email));
    },
    enabled: !!projectId && investments.length > 0,
  });

  // Analytics calculations
  const analytics = useMemo(() => {
    if (!project || !investments.length) return null;

    // Category distribution
    const categoryDist = investments.reduce((acc, inv) => {
      acc[inv.category] = (acc[inv.category] || 0) + 1;
      return acc;
    }, {});

    const categoryData = Object.entries(categoryDist).map(([name, count]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value: count,
      amount: investments.filter(i => i.category === name).reduce((sum, i) => sum + i.amount, 0)
    }));

    // Geographic distribution
    const geoDist = allInvestors.reduce((acc, investor) => {
      const location = investor.location || investor.nationality || 'Não informado';
      acc[location] = (acc[location] || 0) + 1;
      return acc;
    }, {});

    const geoData = Object.entries(geoDist)
      .map(([name, count]) => ({ name, value: count }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);

    // Investment trend (last 30 days)
    const last30Days = Array.from({ length: 30 }, (_, i) => {
      const date = subDays(new Date(), 29 - i);
      return {
        date: format(date, 'dd/MM'),
        amount: 0,
        count: 0
      };
    });

    investments.forEach(inv => {
      const invDate = new Date(inv.created_date);
      const dayIndex = Math.floor((invDate - subDays(new Date(), 29)) / (1000 * 60 * 60 * 24));
      if (dayIndex >= 0 && dayIndex < 30) {
        last30Days[dayIndex].amount += inv.amount;
        last30Days[dayIndex].count += 1;
      }
    });

    // Cumulative trend
    let cumulative = 0;
    const cumulativeTrend = last30Days.map(day => {
      cumulative += day.amount;
      return { ...day, cumulative };
    });

    // Average investment
    const avgInvestment = investments.reduce((sum, i) => sum + i.amount, 0) / investments.length;

    // Conversion metrics
    const views = project.views_count || 0;
    const conversionRate = views > 0 ? (investments.length / views) * 100 : 0;

    return {
      categoryData,
      geoData,
      trendData: cumulativeTrend,
      avgInvestment,
      conversionRate,
      views
    };
  }, [project, investments, allInvestors]);

  // Generate AI insights
  const generateAIInsights = async () => {
    if (!project || !analytics) return;

    setIsGeneratingInsights(true);
    
    try {
      const progress = (project.current_funding / project.funding_goal) * 100;
      
      const prompt = `You are an expert investment advisor and marketing strategist for crowdfunding campaigns in Brazil.

Analyze this project and provide actionable recommendations:

**Project Details:**
- Title: ${project.title}
- Sector: ${project.sector}
- Location: ${project.city}, ${project.state}
- Description: ${project.description}

**Current Performance:**
- Funding Goal: R$ ${project.funding_goal?.toLocaleString('pt-BR')}
- Current Funding: R$ ${project.current_funding?.toLocaleString('pt-BR')}
- Progress: ${progress.toFixed(1)}%
- Total Investors: ${project.investors_count}
- Views: ${analytics.views}
- Conversion Rate: ${analytics.conversionRate.toFixed(2)}%
- Average Investment: R$ ${analytics.avgInvestment?.toLocaleString('pt-BR')}

**Investor Demographics:**
- Top locations: ${analytics.geoData.map(g => g.name).join(', ')}
- Category distribution: ${analytics.categoryData.map(c => `${c.name} (${c.value})`).join(', ')}

**Task:**
Provide 5-7 specific, actionable recommendations to:
1. Improve visibility and reach more potential investors
2. Increase conversion rate
3. Target specific investor segments based on demographics
4. Optimize funding strategy
5. Create compelling marketing messages

Be specific, practical, and data-driven. Focus on the Brazilian market context.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            visibility_strategies: {
              type: "array",
              items: { type: "string" },
              description: "Strategies to improve visibility"
            },
            conversion_strategies: {
              type: "array",
              items: { type: "string" },
              description: "Strategies to improve conversion"
            },
            targeting_recommendations: {
              type: "array",
              items: { type: "string" },
              description: "How to target specific investor segments"
            },
            funding_optimization: {
              type: "array",
              items: { type: "string" },
              description: "Ways to optimize funding strategy"
            },
            key_insights: {
              type: "array",
              items: { type: "string" },
              description: "Key insights from the data"
            }
          }
        }
      });

      setAiInsights(response);
    } catch (error) {
      console.error("Error generating insights:", error);
    } finally {
      setIsGeneratingInsights(false);
    }
  };

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600" />
      </div>
    );
  }

  const progress = (project.current_funding / project.funding_goal) * 100;
  const maxTarget = project.funding_goal * 1.25;
  const daysLeft = project.end_date 
    ? Math.max(0, Math.ceil((new Date(project.end_date) - new Date()) / (1000 * 60 * 60 * 24)))
    : 0;

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/30 to-blue-50/30">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <Badge className="mb-3 bg-gradient-to-r from-emerald-500 to-blue-500 text-white">
                Campanha {project.status === 'ativa' ? 'Ativa' : project.status}
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
                {project.title}
              </h1>
              <p className="text-lg text-gray-600">
                {project.city}/{project.state} • {project.sector}
              </p>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" size="lg">
                <Share2 className="w-4 h-4 mr-2" />
                Compartilhar
              </Button>
              <Link to={createPageUrl(`Invest?project=${project.id}`)}>
                <Button size="lg" className="bg-gradient-to-r from-emerald-500 to-blue-500 shadow-lg">
                  <DollarSign className="w-5 h-5 mr-2" />
                  Ver Página de Investimento
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <TabsList className="bg-gray-100 w-full justify-start">
                <TabsTrigger value="overview">📊 Visão Geral</TabsTrigger>
                <TabsTrigger value="analytics">📈 Análises</TabsTrigger>
                <TabsTrigger value="investors">👥 Investidores</TabsTrigger>
                <TabsTrigger value="ai-insights">🤖 Insights de IA</TabsTrigger>
              </TabsList>
            </CardContent>
          </Card>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Stats Cards */}
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <Card className="border-none shadow-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600">
                        <Eye className="w-6 h-6 text-white" />
                      </div>
                    </div>
                    <p className="text-sm text-gray-500 mb-1">Visualizações</p>
                    <p className="text-3xl font-bold text-gray-900">{project.views_count || 0}</p>
                    <p className="text-xs text-gray-500 mt-2">
                      {analytics ? `${analytics.conversionRate.toFixed(2)}% conversão` : 'Carregando...'}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                <Card className="border-none shadow-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600">
                        <Users className="w-6 h-6 text-white" />
                      </div>
                    </div>
                    <p className="text-sm text-gray-500 mb-1">Investidores</p>
                    <p className="text-3xl font-bold text-gray-900">{project.investors_count}</p>
                    <p className="text-xs text-gray-500 mt-2">
                      {analytics ? `Ticket médio: R$ ${analytics.avgInvestment?.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}` : 'Carregando...'}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                <Card className="border-none shadow-xl">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600">
                        <Clock className="w-6 h-6 text-white" />
                      </div>
                    </div>
                    <p className="text-sm text-gray-500 mb-1">Dias Restantes</p>
                    <p className="text-3xl font-bold text-gray-900">{daysLeft}</p>
                    <p className="text-xs text-gray-500 mt-2">
                      até {format(new Date(project.end_date), "dd/MM/yyyy")}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            </div>

            {/* Campaign Progress */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
              <Card className="border-none shadow-2xl overflow-hidden">
                <div className="h-2 bg-gradient-to-r from-emerald-500 to-blue-500" />
                <CardContent className="p-8">
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-sm font-semibold text-gray-600">Progresso do Financiamento</h3>
                      <span className="text-3xl font-bold text-emerald-600">
                        {progress.toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={progress} className="h-4 mb-2" />
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>R$ 0</span>
                      <span>R$ {project.funding_goal.toLocaleString('pt-BR')}</span>
                      <span>R$ {maxTarget.toLocaleString('pt-BR')}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-6">
                    <div className="text-center p-4 bg-emerald-50 rounded-xl">
                      <p className="text-xs text-emerald-700 mb-1">Arrecadado</p>
                      <p className="text-2xl font-bold text-emerald-900">
                        R$ {project.current_funding.toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-xl">
                      <p className="text-xs text-blue-700 mb-1">Objetivo</p>
                      <p className="text-2xl font-bold text-blue-900">
                        R$ {project.funding_goal.toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-xl">
                      <p className="text-xs text-purple-700 mb-1">Potencial Máximo</p>
                      <p className="text-2xl font-bold text-purple-900">
                        R$ {maxTarget.toLocaleString('pt-BR')}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            {analytics ? (
              <>
                <div className="grid lg:grid-cols-2 gap-6">
                  {/* Investment Trend */}
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                    <Card className="border-none shadow-xl">
                      <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                        <CardTitle className="flex items-center gap-2">
                          <Activity className="w-6 h-6 text-emerald-600" />
                          Tendência de Investimentos (30 dias)
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-6">
                        <ResponsiveContainer width="100%" height={300}>
                          <AreaChart data={analytics.trendData}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="date" />
                            <YAxis />
                            <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
                            <Area
                              type="monotone"
                              dataKey="cumulative"
                              stroke="#059669"
                              fill="#059669"
                              fillOpacity={0.6}
                              name="Acumulado"
                            />
                          </AreaChart>
                        </ResponsiveContainer>
                      </CardContent>
                    </Card>
                  </motion.div>

                  {/* Category Distribution */}
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                    <Card className="border-none shadow-xl">
                      <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                        <CardTitle className="flex items-center gap-2">
                          <PieChartIcon className="w-6 h-6 text-blue-600" />
                          Distribuição por Categoria
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-6">
                        <ResponsiveContainer width="100%" height={300}>
                          <PieChart>
                            <Pie
                              data={analytics.categoryData}
                              cx="50%"
                              cy="50%"
                              labelLine={false}
                              label={({ name, value }) => `${name}: ${value}`}
                              outerRadius={100}
                              fill="#8884d8"
                              dataKey="value"
                            >
                              {analytics.categoryData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                              ))}
                            </Pie>
                            <Tooltip />
                          </PieChart>
                        </ResponsiveContainer>
                        <div className="mt-4 space-y-2">
                          {analytics.categoryData.map((cat, index) => (
                            <div key={cat.name} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                              <div className="flex items-center gap-2">
                                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index] }} />
                                <span className="text-sm font-medium">{cat.name}</span>
                              </div>
                              <div className="text-right">
                                <p className="text-sm font-bold text-gray-900">{cat.value} investidores</p>
                                <p className="text-xs text-gray-500">R$ {cat.amount.toLocaleString('pt-BR')}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </div>

                {/* Geographic Distribution */}
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                  <Card className="border-none shadow-xl">
                    <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                      <CardTitle className="flex items-center gap-2">
                        <MapPin className="w-6 h-6 text-purple-600" />
                        Distribuição Geográfica de Investidores
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-6">
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={analytics.geoData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="value" fill="#8b5cf6" name="Investidores" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                </motion.div>
              </>
            ) : (
              <Card className="p-12 text-center">
                <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Nenhum investimento ainda para analisar</p>
              </Card>
            )}
          </TabsContent>

          {/* Investors Tab */}
          <TabsContent value="investors" className="space-y-6">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <Card className="border-none shadow-xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-6 h-6 text-blue-600" />
                    Lista de Investidores ({investments.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  {investments.length > 0 ? (
                    <div className="space-y-3">
                      {investments.map((investment, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-emerald-500 to-blue-500 flex items-center justify-center text-white font-bold text-lg">
                              {investment.investor_name?.substring(0, 2).toUpperCase()}
                            </div>
                            <div>
                              <p className="font-semibold text-gray-900">{investment.investor_name}</p>
                              <p className="text-xs text-gray-500">
                                {format(new Date(investment.created_date), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-emerald-600">
                              R$ {investment.amount.toLocaleString('pt-BR')}
                            </p>
                            <Badge className={`bg-gradient-to-r ${categoryColors[investment.category]} text-white border-none`}>
                              {investment.category.charAt(0).toUpperCase() + investment.category.slice(1)}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 text-lg">Nenhum investidor ainda</p>
                      <p className="text-gray-500 text-sm mt-2">Compartilhe seu projeto para atrair investidores!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* AI Insights Tab */}
          <TabsContent value="ai-insights" className="space-y-6">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
              <Card className="border-2 border-purple-200 shadow-2xl overflow-hidden">
                <div className="h-2 bg-gradient-to-r from-purple-500 via-blue-500 to-emerald-500" />
                <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500">
                        <Sparkles className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-2xl">Insights Impulsionados por IA</CardTitle>
                        <p className="text-sm text-gray-600 mt-1">
                          Recomendações personalizadas para otimizar seu projeto
                        </p>
                      </div>
                    </div>
                    <Button
                      onClick={generateAIInsights}
                      disabled={isGeneratingInsights || !analytics}
                      className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                    >
                      {isGeneratingInsights ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Gerando...
                        </>
                      ) : (
                        <>
                          <Zap className="w-4 h-4 mr-2" />
                          Gerar Insights
                        </>
                      )}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="p-8">
                  {!aiInsights && !isGeneratingInsights && (
                    <div className="text-center py-12">
                      <Lightbulb className="w-20 h-20 text-purple-400 mx-auto mb-4" />
                      <h3 className="text-xl font-bold text-gray-900 mb-2">
                        Descubra Como Melhorar Sua Campanha
                      </h3>
                      <p className="text-gray-600 mb-6">
                        Nossa IA analisará seu projeto e fornecerá recomendações acionáveis para aumentar visibilidade e investimentos
                      </p>
                      <Button
                        onClick={generateAIInsights}
                        disabled={!analytics}
                        size="lg"
                        className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                      >
                        <Sparkles className="w-5 h-5 mr-2" />
                        Gerar Insights com IA
                      </Button>
                    </div>
                  )}

                  {isGeneratingInsights && (
                    <div className="text-center py-12">
                      <RefreshCw className="w-16 h-16 text-purple-600 mx-auto mb-4 animate-spin" />
                      <h3 className="text-xl font-bold text-gray-900 mb-2">
                        Analisando Seu Projeto...
                      </h3>
                      <p className="text-gray-600">
                        Nossa IA está processando seus dados para gerar recomendações personalizadas
                      </p>
                    </div>
                  )}

                  <AnimatePresence>
                    {aiInsights && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                      >
                        {/* Key Insights */}
                        {aiInsights.key_insights?.length > 0 && (
                          <Alert className="border-2 border-emerald-200 bg-emerald-50">
                            <Sparkles className="h-5 w-5 text-emerald-600" />
                            <AlertDescription>
                              <strong className="text-emerald-900 block mb-3 text-lg">💡 Principais Insights:</strong>
                              <ul className="space-y-2">
                                {aiInsights.key_insights.map((insight, index) => (
                                  <li key={index} className="text-emerald-800 flex items-start gap-2">
                                    <CheckCircle className="w-4 h-4 mt-1 flex-shrink-0" />
                                    <span>{insight}</span>
                                  </li>
                                ))}
                              </ul>
                            </AlertDescription>
                          </Alert>
                        )}

                        {/* Visibility Strategies */}
                        {aiInsights.visibility_strategies?.length > 0 && (
                          <Card className="border-2 border-blue-200 bg-blue-50/50">
                            <CardHeader className="bg-gradient-to-r from-blue-100 to-cyan-100">
                              <CardTitle className="flex items-center gap-2 text-blue-900">
                                <Eye className="w-6 h-6" />
                                Estratégias de Visibilidade
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                              <ul className="space-y-3">
                                {aiInsights.visibility_strategies.map((strategy, index) => (
                                  <li key={index} className="flex items-start gap-3 p-3 bg-white rounded-lg">
                                    <Badge className="bg-blue-600 text-white">{index + 1}</Badge>
                                    <span className="text-gray-800 leading-relaxed">{strategy}</span>
                                  </li>
                                ))}
                              </ul>
                            </CardContent>
                          </Card>
                        )}

                        {/* Conversion Strategies */}
                        {aiInsights.conversion_strategies?.length > 0 && (
                          <Card className="border-2 border-purple-200 bg-purple-50/50">
                            <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100">
                              <CardTitle className="flex items-center gap-2 text-purple-900">
                                <TrendingUp className="w-6 h-6" />
                                Otimização de Conversão
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                              <ul className="space-y-3">
                                {aiInsights.conversion_strategies.map((strategy, index) => (
                                  <li key={index} className="flex items-start gap-3 p-3 bg-white rounded-lg">
                                    <Badge className="bg-purple-600 text-white">{index + 1}</Badge>
                                    <span className="text-gray-800 leading-relaxed">{strategy}</span>
                                  </li>
                                ))}
                              </ul>
                            </CardContent>
                          </Card>
                        )}

                        {/* Targeting Recommendations */}
                        {aiInsights.targeting_recommendations?.length > 0 && (
                          <Card className="border-2 border-orange-200 bg-orange-50/50">
                            <CardHeader className="bg-gradient-to-r from-orange-100 to-amber-100">
                              <CardTitle className="flex items-center gap-2 text-orange-900">
                                <Target className="w-6 h-6" />
                                Segmentação de Investidores
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                              <ul className="space-y-3">
                                {aiInsights.targeting_recommendations.map((rec, index) => (
                                  <li key={index} className="flex items-start gap-3 p-3 bg-white rounded-lg">
                                    <Badge className="bg-orange-600 text-white">{index + 1}</Badge>
                                    <span className="text-gray-800 leading-relaxed">{rec}</span>
                                  </li>
                                ))}
                              </ul>
                            </CardContent>
                          </Card>
                        )}

                        {/* Funding Optimization */}
                        {aiInsights.funding_optimization?.length > 0 && (
                          <Card className="border-2 border-emerald-200 bg-emerald-50/50">
                            <CardHeader className="bg-gradient-to-r from-emerald-100 to-green-100">
                              <CardTitle className="flex items-center gap-2 text-emerald-900">
                                <DollarSign className="w-6 h-6" />
                                Otimização de Financiamento
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                              <ul className="space-y-3">
                                {aiInsights.funding_optimization.map((opt, index) => (
                                  <li key={index} className="flex items-start gap-3 p-3 bg-white rounded-lg">
                                    <Badge className="bg-emerald-600 text-white">{index + 1}</Badge>
                                    <span className="text-gray-800 leading-relaxed">{opt}</span>
                                  </li>
                                ))}
                              </ul>
                            </CardContent>
                          </Card>
                        )}

                        <div className="text-center pt-6">
                          <Button
                            onClick={generateAIInsights}
                            variant="outline"
                            className="border-2 border-purple-300 hover:bg-purple-50"
                          >
                            <RefreshCw className="w-4 h-4 mr-2" />
                            Gerar Novos Insights
                          </Button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}