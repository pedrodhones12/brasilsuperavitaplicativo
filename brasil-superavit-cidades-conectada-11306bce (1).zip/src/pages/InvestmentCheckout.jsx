
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  CheckCircle, 
  AlertTriangle, 
  Shield, 
  FileText, 
  Download,
  TrendingUp,
  Users,
  Target,
  DollarSign,
  Percent,
  Clock,
  ArrowLeft,
  Lock,
  CreditCard,
  Building2,
  Info,
  Calculator,
  Sparkles
} from "lucide-react";
import { motion } from "framer-motion";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

const PREDEFINED_AMOUNTS = [5000, 10000, 25000, 50000, 100000, 200000];

const INVESTMENT_CATEGORIES = {
  bronze: { name: "Bronze", color: "from-amber-600 to-amber-700", minAmount: 5000 },
  prata: { name: "Prata", color: "from-gray-400 to-gray-500", minAmount: 10000 },
  ouro: { name: "Ouro", color: "from-yellow-400 to-yellow-600", minAmount: 15000 }
};

export default function InvestmentCheckout() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const queryClient = useQueryClient();
  
  const projectId = searchParams.get("project") || searchParams.get("projectId");
  const category = searchParams.get("category") || "bronze";
  const urlAmount = parseFloat(searchParams.get("amount")) || INVESTMENT_CATEGORIES[category].minAmount;

  const [user, setUser] = useState(null);
  const [selectedAmount, setSelectedAmount] = useState(urlAmount);
  const [customAmount, setCustomAmount] = useState("");
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [riskAccepted, setRiskAccepted] = useState(false);
  const [contractAccepted, setContractAccepted] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const isAuth = await base44.auth.isAuthenticated();
        if (!isAuth) {
          base44.auth.redirectToLogin(window.location.pathname);
          return;
        }
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        base44.auth.redirectToLogin(window.location.pathname);
      }
    };
    loadUser();
  }, []);

  const { data: project, isLoading } = useQuery({
    queryKey: ['project', projectId],
    queryFn: async () => {
      const projects = await base44.entities.Project.filter({ id: projectId });
      return projects[0];
    },
    enabled: !!projectId
  });

  const createInvestmentMutation = useMutation({
    mutationFn: async (investmentData) => {
      // ✅ CRIAR INVESTIMENTO COM EQUITY CORRETO
      const investment = await base44.entities.Investment.create(investmentData);
      
      const platformFee = investmentData.amount * 0.065;
      const transaction = await base44.entities.Transaction.create({
        project_id: project.id,
        type: "investimento",
        amount: investmentData.amount,
        fee_amount: platformFee,
        net_amount: investmentData.amount - platformFee,
        description: `Investimento ${category.toUpperCase()} - ${project.title}`,
        status: "processando",
        user_email: user?.email
      });

      return { investment, transaction };
    },
    onSuccess: async ({ investment }) => {
      try {
        toast.success("✅ Investimento registrado! Redirecionando para assinatura do contrato...");
        
        // Atualizar investimento com dados adicionais
        await base44.entities.Investment.update(investment.id, {
          status: "processando",
          payment_method: "Mercado Pago - Checkout Pro",
          payment_status: "aguardando",
          transaction_id: `inv_${investment.id}_${Date.now()}`
        });

        setTimeout(() => {
          navigate(createPageUrl(`InvestmentContract?investment_id=${investment.id}`));
        }, 1500);

      } catch (error) {
        console.error("Error creating checkout:", error);
        toast.error("Erro ao processar. Tente novamente.");
        setTimeout(() => {
          navigate(createPageUrl("MyInvestments"));
        }, 2000);
      }
    }
  });

  const handleConfirmInvestment = async () => {
    if (!termsAccepted || !riskAccepted || !contractAccepted) {
      toast.error("Por favor, aceite todos os termos antes de continuar.");
      return;
    }

    const finalAmount = customAmount ? parseFloat(customAmount) : selectedAmount;

    if (finalAmount < 5000) {
      toast.error("O valor mínimo de investimento é R$ 5.000,00");
      return;
    }

    if (!finalAmount || isNaN(finalAmount)) {
      toast.error("Por favor, selecione um valor de investimento válido.");
      return;
    }

    setIsProcessing(true);

    try {
      // ✅ CALCULAR EQUITY PERCENTAGE CORRETAMENTE
      const equityPercentage = project.equity_offered 
        ? (finalAmount / project.funding_goal) * project.equity_offered 
        : 0;

      toast.loading("Criando seu investimento...", { id: "creating-investment" });

      const investmentData = {
        project_id: project.id,
        project_title: project.title,
        investor_email: user?.email,
        investor_name: user?.full_name,
        amount: finalAmount,
        equity_percentage: equityPercentage, // ✅ GARANTIR QUE SEJA SALVO
        category: category,
        status: "pendente",
        payment_method: "Mercado Pago - Checkout Pro",
        payment_status: "aguardando",
        investment_date: new Date().toISOString().split('T')[0],
        terms_accepted: termsAccepted,
        risk_acknowledgement: riskAccepted
      };

      console.log("📊 Criando investimento:", {
        amount: finalAmount,
        fundingGoal: project.funding_goal,
        equityOffered: project.equity_offered,
        equityPercentage: equityPercentage
      });

      await createInvestmentMutation.mutateAsync(investmentData);
      
      toast.dismiss("creating-investment");

    } catch (error) {
      console.error("Error creating investment:", error);
      toast.dismiss("creating-investment");
      toast.error("Erro ao processar investimento. Tente novamente.");
      setIsProcessing(false);
    }
  };

  if (isLoading || !project || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando informações do investimento...</p>
        </div>
      </div>
    );
  }

  const finalAmount = customAmount ? parseFloat(customAmount) : selectedAmount;
  const equityPercentage = project.equity_offered 
    ? (finalAmount / project.funding_goal) * project.equity_offered 
    : 0;

  const platformFee = finalAmount * 0.065;
  const totalInvested = (project.current_funding || 0);
  const progressPercentage = (totalInvested / project.funding_goal) * 100;

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            variant="ghost"
            onClick={() => navigate(createPageUrl("Invest"))}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar para Projetos
          </Button>
          
          <div className="flex items-center gap-3 mb-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-blue-500 shadow-lg">
              <CreditCard className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900">
                Confirmação de Investimento
              </h1>
              <p className="text-gray-600 mt-1">Selecione o valor e revise os detalhes</p>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Investment Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Project Overview */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="border-none shadow-xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                  <CardTitle className="flex items-center gap-2">
                    <Building2 className="w-6 h-6 text-emerald-600" />
                    {project.title}
                  </CardTitle>
                  <p className="text-sm text-gray-600 mt-2">{project.description}</p>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-3 bg-gray-50 rounded-lg">
                      <Target className="w-5 h-5 text-gray-600 mx-auto mb-1" />
                      <p className="text-xs text-gray-500">Meta</p>
                      <p className="text-sm font-bold text-gray-900">
                        R$ {project.funding_goal?.toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <div className="text-center p-3 bg-emerald-50 rounded-lg">
                      <DollarSign className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
                      <p className="text-xs text-emerald-700">Arrecadado</p>
                      <p className="text-sm font-bold text-emerald-900">
                        R$ {totalInvested?.toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <Users className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                      <p className="text-xs text-blue-700">Investidores</p>
                      <p className="text-sm font-bold text-blue-900">
                        {project.investors_count || 0}
                      </p>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <Percent className="w-5 h-5 text-purple-600 mx-auto mb-1" />
                      <p className="text-xs text-purple-700">Progresso</p>
                      <p className="text-sm font-bold text-purple-900">
                        {progressPercentage.toFixed(0)}%
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Value Selection */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
            >
              <Card className="border-2 border-emerald-200 shadow-xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                  <CardTitle className="flex items-center gap-2">
                    <Calculator className="w-6 h-6 text-emerald-600" />
                    Selecione o Valor do Investimento
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-6">
                    {PREDEFINED_AMOUNTS.map((amount) => {
                      const percentage = project.equity_offered 
                        ? ((amount / project.funding_goal) * project.equity_offered).toFixed(4)
                        : 0;
                      
                      return (
                        <button
                          key={amount}
                          onClick={() => {
                            setSelectedAmount(amount);
                            setCustomAmount("");
                          }}
                          className={`p-4 rounded-xl border-2 transition-all ${
                            selectedAmount === amount && !customAmount
                              ? 'border-emerald-500 bg-emerald-50 shadow-lg scale-105'
                              : 'border-gray-200 hover:border-emerald-300 hover:bg-gray-50'
                          }`}
                        >
                          <p className="text-xs text-gray-500 mb-1">Investir</p>
                          <p className="text-lg font-bold text-gray-900">
                            R$ {amount.toLocaleString('pt-BR')}
                          </p>
                          {project.equity_offered && percentage > 0 && (
                            <div className="mt-2 p-2 bg-purple-100 rounded-lg">
                              <p className="text-xs text-purple-600 font-semibold">
                                🎯 Participação:
                              </p>
                              <p className="text-lg font-bold text-purple-900">
                                {percentage}%
                              </p>
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-base font-semibold">Ou outro valor:</Label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 font-semibold">
                        R$
                      </span>
                      <Input
                        type="number"
                        min="5000"
                        step="1000"
                        value={customAmount}
                        onChange={(e) => {
                          setCustomAmount(e.target.value);
                          if (e.target.value) {
                            setSelectedAmount(null);
                          }
                        }}
                        placeholder="150.000"
                        className="pl-12 h-14 text-lg font-semibold"
                      />
                    </div>
                    {customAmount && parseFloat(customAmount) >= 5000 && project.equity_offered && (
                      <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-4 bg-gradient-to-r from-purple-100 to-blue-100 rounded-xl border-2 border-purple-300"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-purple-700 font-semibold mb-1">
                              🎯 Sua Participação Calculada:
                            </p>
                            <p className="text-xs text-purple-600">
                              (R$ {parseFloat(customAmount).toLocaleString('pt-BR')} ÷ R$ {project.funding_goal.toLocaleString('pt-BR')}) × {project.equity_offered}%
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-4xl font-bold text-purple-900">
                              {((parseFloat(customAmount) / project.funding_goal) * project.equity_offered).toFixed(4)}%
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    )}
                    {customAmount && parseFloat(customAmount) < 5000 && (
                      <Alert className="border-red-200 bg-red-50">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <AlertDescription className="text-red-900">
                          Valor mínimo: R$ 5.000,00
                        </AlertDescription>
                      </Alert>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Investment Terms */}
            {project.investment_type === "equity" && project.equity_offered && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-purple-900">
                      <TrendingUp className="w-6 h-6" />
                      Detalhes da Participação Societária
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-white rounded-lg">
                        <p className="text-sm text-gray-600 mb-1">Equity Total Oferecido</p>
                        <p className="text-3xl font-bold text-purple-600">
                          {project.equity_offered}%
                        </p>
                      </div>
                      <div className="p-4 bg-white rounded-lg">
                        <p className="text-sm text-gray-600 mb-1">Sua Participação</p>
                        <p className="text-3xl font-bold text-emerald-600">
                          {equityPercentage.toFixed(4)}%
                        </p>
                      </div>
                    </div>
                    
                    {project.company_valuation && (
                      <div className="p-4 bg-white rounded-lg">
                        <p className="text-sm text-gray-600 mb-1">Valuation da Empresa</p>
                        <p className="text-2xl font-bold text-gray-900">
                          R$ {project.company_valuation.toLocaleString('pt-BR')}
                        </p>
                      </div>
                    )}

                    {project.expected_return && (
                      <Alert className="border-blue-200 bg-blue-50">
                        <Info className="h-4 w-4 text-blue-600" />
                        <AlertDescription className="text-blue-900">
                          <strong>Retorno Esperado:</strong> {project.expected_return}
                        </AlertDescription>
                      </Alert>
                    )}

                    <Alert className="border-indigo-200 bg-indigo-50">
                      <Sparkles className="h-4 w-4 text-indigo-600" />
                      <AlertDescription className="text-indigo-900">
                        <strong>Cálculo:</strong> (R$ {finalAmount.toLocaleString('pt-BR')} ÷ R$ {project.funding_goal.toLocaleString('pt-BR')}) × {project.equity_offered}% = <strong className="text-xl">{equityPercentage.toFixed(4)}%</strong> de participação
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Risk Factors */}
            {project.risk_factors && project.risk_factors.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <Card className="border-2 border-red-200">
                  <CardHeader className="bg-red-50">
                    <CardTitle className="flex items-center gap-2 text-red-900">
                      <AlertTriangle className="w-6 h-6" />
                      Fatores de Risco
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <ul className="space-y-3">
                      {project.risk_factors.map((risk, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <AlertTriangle className="w-4 h-4 text-red-500 mt-1 flex-shrink-0" />
                          <span className="text-sm text-gray-700">{risk}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Documents */}
            {project.documents && project.documents.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-gray-50 to-blue-50">
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-6 h-6 text-blue-600" />
                      Documentos Essenciais
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      {project.documents.map((doc, idx) => (
                        <a
                          key={idx}
                          href={doc.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-between p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <FileText className="w-5 h-5 text-gray-600" />
                            <div>
                              <p className="font-semibold text-gray-900">{doc.name}</p>
                              {doc.description && (
                                <p className="text-xs text-gray-500">{doc.description}</p>
                              )}
                            </div>
                          </div>
                          <Download className="w-5 h-5 text-gray-400" />
                        </a>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Terms and Conditions */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              <Card className="border-2 border-emerald-200">
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-start gap-3">
                    <Checkbox
                      id="terms"
                      checked={termsAccepted}
                      onCheckedChange={setTermsAccepted}
                      className="mt-1"
                    />
                    <label htmlFor="terms" className="text-sm text-gray-700 cursor-pointer">
                      Li e aceito os <strong>termos de investimento</strong>, incluindo as condições de 
                      participação societária, prazos de retorno e obrigações contratuais.
                    </label>
                  </div>

                  <Separator />

                  <div className="flex items-start gap-3">
                    <Checkbox
                      id="risk"
                      checked={riskAccepted}
                      onCheckedChange={setRiskAccepted}
                      className="mt-1"
                    />
                    <label htmlFor="risk" className="text-sm text-gray-700 cursor-pointer">
                      Declaro que estou ciente dos <strong>riscos do investimento</strong>, incluindo 
                      possibilidade de perda parcial ou total do capital investido, conforme Resolução CVM 88/2022.
                    </label>
                  </div>

                  <Separator />

                  <div className="flex items-start gap-3">
                    <Checkbox
                      id="contract"
                      checked={contractAccepted}
                      onCheckedChange={setContractAccepted}
                      className="mt-1"
                    />
                    <label htmlFor="contract" className="text-sm text-gray-700 cursor-pointer">
                      Concordo em assinar o <strong>Contrato de Investimento e Acordo de Acionistas</strong> que 
                      será gerado automaticamente com meus dados e a participação societária de <strong>{equityPercentage.toFixed(4)}%</strong>.
                    </label>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Right Column - Investment Summary */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="sticky top-8"
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-emerald-500 to-blue-500 text-white">
                  <CardTitle>Resumo do Investimento</CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">Categoria</p>
                    <Badge className={`bg-gradient-to-r ${INVESTMENT_CATEGORIES[category].color} text-white text-lg px-4 py-2`}>
                      {INVESTMENT_CATEGORIES[category].name}
                    </Badge>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Valor do investimento</span>
                      <span className="font-bold text-lg">
                        R$ {finalAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    {project.investment_type === "equity" && equityPercentage > 0 && (
                      <div className="p-4 bg-gradient-to-r from-purple-100 to-blue-100 rounded-xl border-2 border-purple-300">
                        <p className="text-sm text-purple-700 font-semibold mb-2 text-center">
                          🎯 Você será proprietário de:
                        </p>
                        <p className="text-5xl font-bold text-purple-900 text-center">
                          {equityPercentage.toFixed(4)}%
                        </p>
                        <p className="text-xs text-center text-purple-600 mt-2">
                          do capital social do projeto
                        </p>
                      </div>
                    )}

                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Taxa da plataforma (6,5%)</span>
                      <span className="text-gray-700">
                        R$ {platformFee.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>

                    <Separator />

                    <div className="flex justify-between text-lg pt-2">
                      <span className="font-bold text-gray-900">Total a Pagar</span>
                      <span className="font-bold text-emerald-600">
                        R$ {finalAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>

                  <Alert className="border-blue-200 bg-blue-50">
                    <Shield className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-sm text-blue-900">
                      Pagamento 100% seguro via Mercado Pago
                    </AlertDescription>
                  </Alert>

                  <Button
                    onClick={handleConfirmInvestment}
                    disabled={!termsAccepted || !riskAccepted || !contractAccepted || isProcessing || finalAmount < 5000}
                    className="w-full h-14 text-lg bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isProcessing ? (
                      <>
                        <Clock className="w-5 h-5 mr-2 animate-spin" />
                        Processando...
                      </>
                    ) : (
                      <>
                        <FileText className="w-5 h-5 mr-2" />
                        Gerar Contrato e Pagar
                      </>
                    )}
                  </Button>

                  <div className="space-y-2 text-xs text-gray-500 text-center">
                    <p className="flex items-center justify-center gap-1">
                      <Lock className="w-3 h-3" />
                      Transação 100% segura com Mercado Pago
                    </p>
                    <p>
                      Você receberá o contrato para assinatura digital
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
