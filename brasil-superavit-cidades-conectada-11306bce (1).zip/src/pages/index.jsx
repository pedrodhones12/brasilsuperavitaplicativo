import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Projects from "./Projects";

import CreateProject from "./CreateProject";

import Invest from "./Invest";

import MyInvestments from "./MyInvestments";

import Transparency from "./Transparency";

import Education from "./Education";

import TutorialView from "./TutorialView";

import InvestorDashboard from "./InvestorDashboard";

import IntellectualProperty from "./IntellectualProperty";

import IPRegistration from "./IPRegistration";

import Subscriptions from "./Subscriptions";

import SocialFeed from "./SocialFeed";

import InternationalInvestor from "./InternationalInvestor";

import Partnerships from "./Partnerships";

import PartnershipsInfo from "./PartnershipsInfo";

import Meetings from "./Meetings";

import ScheduleMeeting from "./ScheduleMeeting";

import FundingOptions from "./FundingOptions";

import ProjectCampaign from "./ProjectCampaign";

import UserProfile from "./UserProfile";

import InvestorProfile from "./InvestorProfile";

import Notifications from "./Notifications";

import GlobalFeed from "./GlobalFeed";

import InvestmentCheckout from "./InvestmentCheckout";

import PaymentCallback from "./PaymentCallback";

import InvestmentContract from "./InvestmentContract";

import AdminSubscriptions from "./AdminSubscriptions";

import Support from "./Support";

import WebsiteBuilder from "./WebsiteBuilder";

import PrivacyPolicy from "./PrivacyPolicy";

import TermsOfService from "./TermsOfService";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Projects: Projects,
    
    CreateProject: CreateProject,
    
    Invest: Invest,
    
    MyInvestments: MyInvestments,
    
    Transparency: Transparency,
    
    Education: Education,
    
    TutorialView: TutorialView,
    
    InvestorDashboard: InvestorDashboard,
    
    IntellectualProperty: IntellectualProperty,
    
    IPRegistration: IPRegistration,
    
    Subscriptions: Subscriptions,
    
    SocialFeed: SocialFeed,
    
    InternationalInvestor: InternationalInvestor,
    
    Partnerships: Partnerships,
    
    PartnershipsInfo: PartnershipsInfo,
    
    Meetings: Meetings,
    
    ScheduleMeeting: ScheduleMeeting,
    
    FundingOptions: FundingOptions,
    
    ProjectCampaign: ProjectCampaign,
    
    UserProfile: UserProfile,
    
    InvestorProfile: InvestorProfile,
    
    Notifications: Notifications,
    
    GlobalFeed: GlobalFeed,
    
    InvestmentCheckout: InvestmentCheckout,
    
    PaymentCallback: PaymentCallback,
    
    InvestmentContract: InvestmentContract,
    
    AdminSubscriptions: AdminSubscriptions,
    
    Support: Support,
    
    WebsiteBuilder: WebsiteBuilder,
    
    PrivacyPolicy: PrivacyPolicy,
    
    TermsOfService: TermsOfService,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Projects" element={<Projects />} />
                
                <Route path="/CreateProject" element={<CreateProject />} />
                
                <Route path="/Invest" element={<Invest />} />
                
                <Route path="/MyInvestments" element={<MyInvestments />} />
                
                <Route path="/Transparency" element={<Transparency />} />
                
                <Route path="/Education" element={<Education />} />
                
                <Route path="/TutorialView" element={<TutorialView />} />
                
                <Route path="/InvestorDashboard" element={<InvestorDashboard />} />
                
                <Route path="/IntellectualProperty" element={<IntellectualProperty />} />
                
                <Route path="/IPRegistration" element={<IPRegistration />} />
                
                <Route path="/Subscriptions" element={<Subscriptions />} />
                
                <Route path="/SocialFeed" element={<SocialFeed />} />
                
                <Route path="/InternationalInvestor" element={<InternationalInvestor />} />
                
                <Route path="/Partnerships" element={<Partnerships />} />
                
                <Route path="/PartnershipsInfo" element={<PartnershipsInfo />} />
                
                <Route path="/Meetings" element={<Meetings />} />
                
                <Route path="/ScheduleMeeting" element={<ScheduleMeeting />} />
                
                <Route path="/FundingOptions" element={<FundingOptions />} />
                
                <Route path="/ProjectCampaign" element={<ProjectCampaign />} />
                
                <Route path="/UserProfile" element={<UserProfile />} />
                
                <Route path="/InvestorProfile" element={<InvestorProfile />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/GlobalFeed" element={<GlobalFeed />} />
                
                <Route path="/InvestmentCheckout" element={<InvestmentCheckout />} />
                
                <Route path="/PaymentCallback" element={<PaymentCallback />} />
                
                <Route path="/InvestmentContract" element={<InvestmentContract />} />
                
                <Route path="/AdminSubscriptions" element={<AdminSubscriptions />} />
                
                <Route path="/Support" element={<Support />} />
                
                <Route path="/WebsiteBuilder" element={<WebsiteBuilder />} />
                
                <Route path="/PrivacyPolicy" element={<PrivacyPolicy />} />
                
                <Route path="/TermsOfService" element={<TermsOfService />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}