
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Briefcase,
  TrendingUp,
  Award,
  Calendar,
  DollarSign,
  MapPin,
  FileText,
  BarChart3,
  Loader2,
  AlertCircle,
  CreditCard // Added CreditCard import
} from "lucide-react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const categoryColors = {
  bronze: "from-amber-600 to-amber-700",
  prata: "from-gray-400 to-gray-500",
  ouro: "from-yellow-400 to-yellow-600",
};

const categoryBackgrounds = {
  bronze: "from-amber-50 to-orange-50",
  prata: "from-gray-50 to-slate-50",
  ouro: "from-yellow-50 to-amber-50",
};

const categoryLabels = {
  bronze: "Bronze",
  prata: "Prata",
  ouro: "Ouro",
};

const StatCard = ({ title, value, icon: Icon, gradient }) => (
  <Card className="border-none shadow-lg overflow-hidden">
    <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-5`} />
    <CardContent className="p-6 relative">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm text-gray-500 mb-2">{title}</p>
          <p className="text-3xl font-bold text-gray-900">{value}</p>
        </div>
        <div className={`p-3 rounded-xl bg-gradient-to-br ${gradient}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </CardContent>
  </Card>
);

const InvestmentCard = ({ investment, project }) => {
  if (!project) {
    return (
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 text-gray-500">
            <AlertCircle className="w-5 h-5" />
            <div>
              <p className="text-sm font-semibold">{investment.project_title || 'Projeto não encontrado'}</p>
              <p className="text-xs">ID: {investment.project_id}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusBadge = (status, paymentStatus) => {
    if (status === 'confirmado' && paymentStatus === 'aprovado') {
      return <Badge className="bg-emerald-500 text-white">✅ Confirmado</Badge>;
    }
    if (status === 'processando' || paymentStatus === 'processando') {
      return <Badge className="bg-blue-500 text-white">⏳ Processando</Badge>;
    }
    if (status === 'pendente' || paymentStatus === 'aguardando') {
      return <Badge className="bg-yellow-500 text-white">⏳ Aguardando Pagamento</Badge>;
    }
    if (status === 'cancelado' || paymentStatus === 'rejeitado') {
      return <Badge className="bg-red-500 text-white">❌ Cancelado</Badge>;
    }
    return <Badge className="bg-gray-500 text-white">{status}</Badge>;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="pb-3 bg-gradient-to-r from-emerald-50 to-blue-50">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <CardTitle className="text-xl mb-2">{investment.project_title || project.title || 'Sem título'}</CardTitle>
              <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                <MapPin className="w-4 h-4" />
                <span>{project.city}/{project.state}</span>
              </div>
              <div className="flex gap-2">
                <Badge className={`bg-gradient-to-r ${categoryColors[investment.category] || categoryColors.bronze} text-white border-none`}>
                  {categoryLabels[investment.category] || investment.category}
                </Badge>
                {getStatusBadge(investment.status, investment.payment_status)}
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500 mb-1">Valor Investido</p>
              <p className="text-2xl font-bold text-emerald-600">
                R$ {(investment.amount || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Data</p>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-gray-400" />
                <p className="font-semibold text-gray-900">
                  {investment.investment_date ? format(new Date(investment.investment_date), "dd MMM yyyy", { locale: ptBR }) : 'N/A'}
                </p>
              </div>
            </div>
          </div>

          {investment.equity_percentage > 0 && (
            <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
              <p className="text-sm text-purple-700 mb-1">Participação Societária</p>
              <p className="text-2xl font-bold text-purple-900">
                {investment.equity_percentage.toFixed(3)}%
              </p>
            </div>
          )}

          {investment.payment_method && (
            <div className="flex items-center gap-2 text-sm text-gray-600 pt-2 border-t border-gray-200">
              <CreditCard className="w-4 h-4" />
              <span>{investment.payment_method}</span>
            </div>
          )}

          {project && project.funding_goal && (
            <div className="pt-4 border-t border-gray-200">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">Progresso do projeto</span>
                <span className="text-sm font-semibold text-emerald-600">
                  {((project.current_funding / project.funding_goal) * 100).toFixed(0)}%
                </span>
              </div>
              <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  style={{ width: `${Math.min((project.current_funding / project.funding_goal) * 100, 100)}%` }}
                  className="h-full bg-gradient-to-r from-emerald-500 to-blue-500"
                />
              </div>
              <div className="flex justify-between mt-2 text-xs text-gray-500">
                <span>R$ {(project.current_funding || 0).toLocaleString('pt-BR')}</span>
                <span>R$ {(project.funding_goal || 0).toLocaleString('pt-BR')}</span>
              </div>
            </div>
          )}

          <div className="flex items-center gap-2 pt-2 text-sm">
            <FileText className="w-4 h-4 text-gray-400" />
            <span className="text-gray-600">ID: {investment.transaction_id || investment.id}</span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function MyInvestments() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const [isLoadingUser, setIsLoadingUser] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const isAuth = await base44.auth.isAuthenticated();
        if (!isAuth) {
          base44.auth.redirectToLogin(window.location.pathname);
          return;
        }
        const userData = await base44.auth.me();
        setUser(userData);
      } catch (error) {
        console.error("Erro ao carregar usuário:", error);
        base44.auth.redirectToLogin(window.location.pathname);
      } finally {
        setIsLoadingUser(false);
      }
    };
    loadUser();
  }, []);

  const { data: investments = [], isLoading: loadingInvestments, error: errorInvestments } = useQuery({
    queryKey: ['my-investments', user?.email],
    queryFn: async () => {
      const result = await base44.entities.Investment.filter({ investor_email: user?.email }, '-created_date');
      return result;
    },
    enabled: !!user?.email,
    retry: 2
  });

  const { data: allProjects = [], isLoading: loadingProjects } = useQuery({
    queryKey: ['projects-for-investments'],
    queryFn: async () => {
      const result = await base44.entities.Project.list();
      return result;
    },
    enabled: !!user?.email,
    retry: 2
  });

  // Usar TODOS os investimentos, não apenas confirmados
  const confirmedInvestments = investments.filter(inv => inv.status === 'confirmado' || inv.status === 'pendente' || inv.status === 'processando'); // Also include 'processando' for stats
  const totalInvested = confirmedInvestments.reduce((sum, inv) => sum + (inv.amount || 0), 0);
  const projectsSupported = new Set(confirmedInvestments.map(inv => inv.project_id)).size;

  const filteredInvestments = activeTab === 'all'
    ? confirmedInvestments
    : confirmedInvestments.filter(inv => inv.category === activeTab);

  const investmentsByCategory = {
    bronze: confirmedInvestments.filter(inv => inv.category === 'bronze').length,
    prata: confirmedInvestments.filter(inv => inv.category === 'prata').length,
    ouro: confirmedInvestments.filter(inv => inv.category === 'ouro').length,
  };

  if (isLoadingUser) {
    return (
      <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/50 to-blue-50/50 flex items-center justify-center">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <Loader2 className="w-16 h-16 text-emerald-600 mx-auto animate-spin" />
            <h2 className="text-2xl font-bold text-gray-900">Carregando...</h2>
            <p className="text-gray-600">Aguarde um momento</p>
          </div>
        </Card>
      </div>
    );
  }

  if (errorInvestments) {
    return (
      <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/50 to-blue-50/50">
        <div className="max-w-7xl mx-auto">
          <Card className="p-12 max-w-md mx-auto border-red-200">
            <div className="text-center space-y-4">
              <AlertCircle className="w-16 h-16 text-red-600 mx-auto" />
              <h2 className="text-2xl font-bold text-gray-900">Erro ao carregar</h2>
              <p className="text-gray-600">{errorInvestments.message || 'Não foi possível carregar seus investimentos'}</p>
              <Button onClick={() => window.location.reload()} className="mt-4">
                Tentar Novamente
              </Button>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/50 to-blue-50/50">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-3">
            <Briefcase className="w-10 h-10 text-blue-600" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
              Meus Investimentos
            </h1>
          </div>
          <p className="text-lg text-gray-600">
            Acompanhe seu portfólio e o impacto dos seus investimentos
          </p>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Investido"
            value={`R$ ${totalInvested.toLocaleString('pt-BR')}`}
            icon={DollarSign}
            gradient="from-emerald-500 to-emerald-600"
          />
          <StatCard
            title="Projetos Apoiados"
            value={projectsSupported}
            icon={TrendingUp}
            gradient="from-blue-500 to-blue-600"
          />
          <StatCard
            title="Investimentos Ativos"
            value={confirmedInvestments.length}
            icon={Briefcase}
            gradient="from-purple-500 to-purple-600"
          />
          <StatCard
            title="Impacto Social"
            value="Alto"
            icon={Award}
            gradient="from-yellow-500 to-yellow-600"
          />
        </div>

        {/* Debug Info - Remover depois */}
        {process.env.NODE_ENV === 'development' && (
          <Card className="mb-8 border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <p className="text-xs text-blue-900 font-mono">
                Debug: {investments.length} investimentos totais | {confirmedInvestments.length} confirmados/pendentes | {allProjects.length} projetos carregados
              </p>
            </CardContent>
          </Card>
        )}

        {/* Category Distribution */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <Card className="border-none shadow-xl">
            <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-6 h-6 text-emerald-600" />
                Distribuição por Categoria
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(investmentsByCategory).map(([category, count]) => (
                  <div
                    key={category}
                    className={`p-6 rounded-xl bg-gradient-to-br ${categoryBackgrounds[category]} border-2 border-${category === 'bronze' ? 'amber' : category === 'prata' ? 'gray' : 'yellow'}-200`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <h3 className={`text-xl font-bold bg-gradient-to-r ${categoryColors[category]} bg-clip-text text-transparent`}>
                        {categoryLabels[category]}
                      </h3>
                      <Award className={`w-6 h-6 ${category === 'bronze' ? 'text-amber-600' : category === 'prata' ? 'text-gray-600' : 'text-yellow-600'}`} />
                    </div>
                    <p className="text-3xl font-bold text-gray-900">{count}</p>
                    <p className="text-sm text-gray-600 mt-1">
                      {count === 1 ? 'investimento' : 'investimentos'}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Investments List */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="border-none shadow-xl">
            <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
              <CardTitle>Histórico de Investimentos</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="mb-6 bg-gray-100">
                  <TabsTrigger value="all" className="px-6">Todos</TabsTrigger>
                  <TabsTrigger value="bronze" className="px-6">Bronze</TabsTrigger>
                  <TabsTrigger value="prata" className="px-6">Prata</TabsTrigger>
                  <TabsTrigger value="ouro" className="px-6">Ouro</TabsTrigger>
                </TabsList>

                {loadingInvestments || loadingProjects ? (
                  <div className="text-center py-12">
                    <Loader2 className="w-12 h-12 text-emerald-600 mx-auto mb-4 animate-spin" />
                    <p className="text-gray-600">Carregando investimentos...</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {filteredInvestments.length > 0 ? (
                      filteredInvestments.map((investment) => {
                        const project = allProjects.find(p => p.id === investment.project_id);
                        return (
                          <InvestmentCard
                            key={investment.id}
                            investment={investment}
                            project={project}
                          />
                        );
                      })
                    ) : (
                      <div className="col-span-2 text-center py-12">
                        <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600 text-lg mb-4">
                          {activeTab === 'all'
                            ? 'Você ainda não fez nenhum investimento'
                            : `Nenhum investimento ${categoryLabels[activeTab]} encontrado`
                          }
                        </p>
                        <Link to={createPageUrl("Invest")}>
                          <Button className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600">
                            Fazer Primeiro Investimento
                          </Button>
                        </Link>
                      </div>
                    )}
                  </div>
                )}
              </Tabs>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
