import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Globe,MapPin,TrendingUp,Users,Palmtree,Leaf,Building2,Factory,Camera,
  Mountain,Waves,UtensilsCrossed,Church,Award,Star,ExternalLink,Info,
  ChevronRight,Search,Newspaper,Activity,Zap
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const a1=[
  {name:"Valor Econômico",category:"Economia Geral",url:"https://valor.globo.com/",description:"Principal jornal de economia e negócios do Brasil",icon:"📊",color:"from-blue-600 to-blue-700",topics:["Mercado","Empresas","Finanças","Política Econômica"]},
  {name:"InfoMoney",category:"Investimentos",url:"https://www.infomoney.com.br/",description:"Notícias sobre mercado financeiro e investimentos",icon:"💰",color:"from-emerald-600 to-green-700",topics:["Bolsa","Fundos","Renda Fixa","Criptomoedas"]},
  {name:"Exame",category:"Negócios",url:"https://exame.com/",description:"Notícias de negócios, economia e tecnologia",icon:"🚀",color:"from-purple-600 to-indigo-700",topics:["Startups","Tecnologia","Inovação","Mercado"]},
  {name:"Brazil Journal",category:"Mercado Financeiro",url:"https://braziljournal.com/",description:"Análises profundas do mercado brasileiro",icon:"📈",color:"from-orange-600 to-red-700",topics:["Análises","Mercado","Private Equity","M&A"]},
  {name:"Seu Dinheiro",category:"Finanças Pessoais",url:"https://www.seudinheiro.com/",description:"Educação financeira e investimentos",icon:"💵",color:"from-green-600 to-teal-700",topics:["Investimentos","Educação","Finanças","Economia"]},
  {name:"Money Times",category:"Mercado Financeiro",url:"https://www.moneytimes.com.br/",description:"Notícias em tempo real do mercado financeiro",icon:"⚡",color:"from-yellow-600 to-orange-700",topics:["Tempo Real","Bolsa","Câmbio","Commodities"]},
  {name:"Bloomberg Brasil",category:"Internacional",url:"https://www.bloomberg.com.br/",description:"Notícias globais com foco no Brasil",icon:"🌎",color:"from-gray-700 to-gray-800",topics:["Global","Mercados","Empresas","Tecnologia"]},
  {name:"NeoFeed",category:"Tecnologia e Startups",url:"https://neofeed.com.br/",description:"Notícias sobre startups e venture capital",icon:"🦄",color:"from-pink-600 to-purple-700",topics:["Startups","VC","Inovação","Empreendedorismo"]},
  {name:"Estadão Economia",category:"Economia",url:"https://www.estadao.com.br/economia/",description:"Cobertura econômica do Estadão",icon:"📰",color:"from-blue-700 to-indigo-800",topics:["Economia","Política","Mercado","Empresas"]},
  {name:"Folha Mercado",category:"Mercado",url:"https://www1.folha.uol.com.br/mercado/",description:"Seção de economia e mercado da Folha",icon:"📑",color:"from-red-600 to-red-700",topics:["Economia","Negócios","Consumo","Empresas"]},
  {name:"Agência Brasil",category:"Notícias Oficiais",url:"https://agenciabrasil.ebc.com.br/economia",description:"Notícias econômicas oficiais do governo",icon:"🏛️",color:"from-blue-600 to-blue-800",topics:["Governo","Políticas","Dados Oficiais","Economia"]},
  {name:"Época Negócios",category:"Negócios",url:"https://epocanegocios.globo.com/",description:"Revista de negócios e carreira",icon:"💼",color:"from-teal-600 to-cyan-700",topics:["Negócios","Carreira","Inovação","Lifestyle"]}
];

const b2=[
  {name:"Banco Central do Brasil",url:"https://www.bcb.gov.br/",description:"Dados oficiais de câmbio, Selic, inflação",icon:"🏦",color:"from-green-600 to-emerald-700"},
  {name:"B3 - Bolsa de Valores",url:"https://www.b3.com.br/",description:"Cotações em tempo real da bolsa brasileira",icon:"📊",color:"from-blue-600 to-indigo-700"},
  {name:"IBGE",url:"https://www.ibge.gov.br/",description:"Estatísticas oficiais do Brasil",icon:"📈",color:"from-purple-600 to-violet-700"},
  {name:"Portal da Transparência",url:"https://portaldatransparencia.gov.br/",description:"Gastos públicos e transparência",icon:"🔍",color:"from-orange-600 to-amber-700"}
];

const c3={
  "São Paulo":[{name:"São Paulo",highlights:["Gastronomia","Cultura","Negócios","Museus"],emoji:"🏙️",visitors:"15M+/ano"},{name:"Campos do Jordão",highlights:["Inverno","Montanhas","Chocolates"],emoji:"🏔️",visitors:"2M+/ano"},{name:"Ilhabela",highlights:["Praias","Cachoeiras","Esportes Náuticos"],emoji:"🏝️",visitors:"1M+/ano"}],
  "Rio de Janeiro":[{name:"Rio de Janeiro",highlights:["Cristo Redentor","Praias","Carnaval"],emoji:"🏖️",visitors:"12M+/ano"},{name:"Búzios",highlights:["Praias","Vida Noturna","Luxo"],emoji:"🌊",visitors:"800K+/ano"},{name:"Paraty",highlights:["História","Cultura","Natureza"],emoji:"⛵",visitors:"500K+/ano"}],
  "Bahia":[{name:"Salvador",highlights:["Carnaval","Cultura Afro","Praias"],emoji:"🎭",visitors:"8M+/ano"},{name:"Porto Seguro",highlights:["Praias","História","Festas"],emoji:"🏖️",visitors:"3M+/ano"},{name:"Morro de São Paulo",highlights:["Praias Paradisíacas","Vida Simples"],emoji:"🌴",visitors:"1M+/ano"}],
  "Minas Gerais":[{name:"Ouro Preto",highlights:["Patrimônio UNESCO","Barroco","História"],emoji:"⛪",visitors:"1.5M+/ano"},{name:"Tiradentes",highlights:["Arquitetura Colonial","Gastronomia"],emoji:"🏛️",visitors:"600K+/ano"},{name:"Belo Horizonte",highlights:["Pampulha","Gastronomia","Negócios"],emoji:"🏙️",visitors:"4M+/ano"}],
  "Paraná":[{name:"Curitiba",highlights:["Qualidade de Vida","Parques","Cultura"],emoji:"🌳",visitors:"3M+/ano"},{name:"Foz do Iguaçu",highlights:["Cataratas","Usina Itaipu","Três Fronteiras"],emoji:"💧",visitors:"2M+/ano"},{name:"Morretes",highlights:["Trem da Serra","Barreado","Natureza"],emoji:"🚂",visitors:"400K+/ano"}],
  "Santa Catarina":[{name:"Florianópolis",highlights:["42 Praias","Lagoa","Qualidade de Vida"],emoji:"🏄",visitors:"5M+/ano"},{name:"Balneário Camboriú",highlights:["Prédios Altos","Praias","Vida Noturna"],emoji:"🌆",visitors:"4M+/ano"},{name:"Blumenau",highlights:["Oktoberfest","Cultura Alemã","Cervejarias"],emoji:"🍺",visitors:"1.5M+/ano"}],
  "Pernambuco":[{name:"Recife",highlights:["Cultura","Carnaval","Frevo"],emoji:"🎉",visitors:"3M+/ano"},{name:"Porto de Galinhas",highlights:["Piscinas Naturais","Praias","Luxo"],emoji:"🐔",visitors:"1M+/ano"},{name:"Fernando de Noronha",highlights:["Paraíso Ecológico","Mergulho"],emoji:"🐠",visitors:"100K+/ano"}],
  "Ceará":[{name:"Fortaleza",highlights:["Praias Urbanas","Vida Noturna","Dunas"],emoji:"🌊",visitors:"3.5M+/ano"},{name:"Jericoacoara",highlights:["Kitesurf","Pôr do Sol","Dunas"],emoji:"🪁",visitors:"400K+/ano"},{name:"Canoa Quebrada",highlights:["Falésias","Praias","Buggy"],emoji:"🏜️",visitors:"300K+/ano"}],
  "Amazonas":[{name:"Manaus",highlights:["Teatro Amazonas","Encontro das Águas","Selva"],emoji:"🌳",visitors:"1.5M+/ano"},{name:"Parintins",highlights:["Festival do Boi","Cultura Amazônica"],emoji:"🎭",visitors:"200K+/ano"}],
  "Rio Grande do Sul":[{name:"Gramado",highlights:["Natal","Chocolate","Arquitetura Europeia"],emoji:"🎄",visitors:"7M+/ano"},{name:"Canela",highlights:["Parques","Natureza","Gastronomia"],emoji:"🌲",visitors:"2M+/ano"},{name:"Bento Gonçalves",highlights:["Vinhos","Serra Gaúcha","Vale dos Vinhedos"],emoji:"🍷",visitors:"1.5M+/ano"}]
};

const d4=[
  {name:"Turismo",icon:Palmtree,color:"from-cyan-500 to-blue-600",description:"Brasil recebe 6+ milhões de turistas internacionais/ano",opportunities:[{title:"Hotéis e Pousadas",growth:"15% a.a.",investment:"R$ 500k - 5M"},{title:"Ecoturismo",growth:"20% a.a.",investment:"R$ 200k - 2M"},{title:"Turismo de Aventura",growth:"18% a.a.",investment:"R$ 300k - 1.5M"},{title:"Gastronomia Turística",growth:"12% a.a.",investment:"R$ 150k - 800k"}],stats:{revenue:"R$ 238 bilhões/ano",growth:"+12% a.a.",jobs:"8 milhões de empregos"}},
  {name:"Agronegócio",icon:Leaf,color:"from-green-500 to-emerald-600",description:"Maior produtor e exportador mundial de café, açúcar, soja",opportunities:[{title:"Agricultura Orgânica",growth:"25% a.a.",investment:"R$ 1M - 10M"},{title:"Tecnologia Agrícola",growth:"30% a.a.",investment:"R$ 500k - 5M"},{title:"Processamento de Alimentos",growth:"15% a.a.",investment:"R$ 2M - 20M"},{title:"Exportação",growth:"18% a.a.",investment:"R$ 1M - 15M"}],stats:{revenue:"R$ 2.5 trilhões/ano",growth:"+15% a.a.",exports:"50% das exportações BR"}},
  {name:"Imóveis e Construção",icon:Building2,color:"from-orange-500 to-amber-600",description:"Mercado imobiliário em expansão nas principais cidades",opportunities:[{title:"Imóveis Turísticos",growth:"20% a.a.",investment:"R$ 500k - 10M"},{title:"Condomínios Sustentáveis",growth:"22% a.a.",investment:"R$ 2M - 50M"},{title:"Hotéis Boutique",growth:"18% a.a.",investment:"R$ 1M - 20M"},{title:"Resorts",growth:"15% a.a.",investment:"R$ 10M - 100M"}],stats:{revenue:"R$ 189 bilhões/ano",growth:"+8% a.a.",market:"3º maior das Américas"}},
  {name:"Indústria",icon:Factory,color:"from-gray-600 to-slate-700",description:"8º maior parque industrial do mundo",opportunities:[{title:"Manufatura",growth:"10% a.a.",investment:"R$ 5M - 50M"},{title:"Indústria 4.0",growth:"25% a.a.",investment:"R$ 2M - 30M"},{title:"Automotivo",growth:"12% a.a.",investment:"R$ 10M - 100M"},{title:"Aeroespacial",growth:"15% a.a.",investment:"R$ 20M - 200M"}],stats:{revenue:"R$ 1.2 trilhão/ano",growth:"+10% a.a.",rank:"8º do mundo"}}
];

const e5=React.memo(({f6})=>(
  <motion.a href={f6.url}target="_blank"rel="noopener noreferrer"initial={{opacity:0,scale:0.95}}animate={{opacity:1,scale:1}}whileHover={{y:-4,scale:1.02}}transition={{duration:0.2}}className="block">
    <Card className="border-none shadow-lg hover:shadow-2xl transition-all duration-300 h-full cursor-pointer overflow-hidden">
      <div className={`h-2 bg-gradient-to-r ${f6.color}`}/>
      <CardContent className="p-4 md:p-6">
        <div className="flex items-start gap-3 md:gap-4 mb-4">
          <div className="text-3xl md:text-4xl">{f6.icon}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-base md:text-lg font-bold text-gray-900 truncate">{f6.name}</h3>
              <ExternalLink className="w-4 h-4 md:w-5 md:h-5 text-gray-400 flex-shrink-0"/>
            </div>
            <Badge variant="outline"className="mb-2 md:mb-3 text-xs">{f6.category}</Badge>
            <p className="text-xs md:text-sm text-gray-600 mb-3 md:mb-4">{f6.description}</p>
            <div className="flex flex-wrap gap-2">{f6.topics.map((g7,h8)=>(<Badge key={h8}className="bg-gray-100 text-gray-700 text-xs">{g7}</Badge>))}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  </motion.a>
));
e5.displayName='NewsPortalCard';

const i9=React.memo(({j10})=>(
  <motion.a href={j10.url}target="_blank"rel="noopener noreferrer"whileHover={{scale:1.03}}transition={{duration:0.2}}className="block">
    <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer">
      <CardContent className="p-4 md:p-6">
        <div className="flex items-center gap-3 md:gap-4">
          <div className={`p-3 md:p-4 rounded-xl bg-gradient-to-br ${j10.color} text-3xl md:text-4xl`}>{j10.icon}</div>
          <div className="flex-1 min-w-0">
            <h4 className="font-bold text-gray-900 mb-1 flex items-center gap-2 text-sm md:text-base truncate">{j10.name}<ExternalLink className="w-3 h-3 md:w-4 md:h-4 text-gray-400 flex-shrink-0"/></h4>
            <p className="text-xs md:text-sm text-gray-600">{j10.description}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  </motion.a>
));
i9.displayName='IndicatorCard';

const k11=React.memo(({l12,m13})=>(
  <motion.div initial={{opacity:0,scale:0.95}}animate={{opacity:1,scale:1}}whileHover={{y:-4}}transition={{duration:0.3}}>
    <Card className="border-none shadow-lg hover:shadow-2xl transition-all duration-300 h-full">
      <CardContent className="p-4 md:p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-3xl md:text-4xl">{l12.emoji}</span>
              <div>
                <h3 className="text-lg md:text-xl font-bold text-gray-900">{l12.name}</h3>
                <p className="text-xs md:text-sm text-gray-500">{m13}</p>
              </div>
            </div>
            <Badge className="bg-gradient-to-r from-emerald-500 to-blue-500 text-white border-none text-xs"><Users className="w-3 h-3 mr-1"/>{l12.visitors}</Badge>
          </div>
        </div>
        <div className="space-y-2">
          <p className="text-xs font-semibold text-gray-600 uppercase">Destaques:</p>
          <div className="flex flex-wrap gap-2">{l12.highlights.map((n14,o15)=>(<Badge key={o15}variant="outline"className="text-xs">{n14}</Badge>))}</div>
        </div>
      </CardContent>
    </Card>
  </motion.div>
));
k11.displayName='CityCard';

const p16=React.memo(({q17})=>{
  const[r18,s19]=useState(false);
  const t20=q17.icon;
  return(<Card className="border-none shadow-xl hover:shadow-2xl transition-all duration-300">
    <CardHeader className={`bg-gradient-to-r ${q17.color} text-white`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 md:gap-3">
          <div className="p-2 md:p-3 bg-white/20 rounded-xl backdrop-blur-sm"><t20 className="w-6 h-6 md:w-8 md:h-8"/></div>
          <div>
            <CardTitle className="text-xl md:text-2xl">{q17.name}</CardTitle>
            <p className="text-xs md:text-sm text-white/90 mt-1">{q17.description}</p>
          </div>
        </div>
        <Button variant="ghost"size="icon"onClick={()=>s19(!r18)}className="text-white hover:bg-white/20"><ChevronRight className={`w-5 h-5 md:w-6 md:h-6 transition-transform ${r18?'rotate-90':''}`}/></Button>
      </div>
    </CardHeader>
    <CardContent className="p-4 md:p-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4 mb-4 md:mb-6">
        <div className="p-3 md:p-4 bg-gradient-to-br from-emerald-50 to-white rounded-xl"><p className="text-xs text-gray-500 mb-1">Receita Anual</p><p className="text-base md:text-lg font-bold text-gray-900">{q17.stats.revenue}</p></div>
        <div className="p-3 md:p-4 bg-gradient-to-br from-blue-50 to-white rounded-xl"><p className="text-xs text-gray-500 mb-1">Crescimento</p><p className="text-base md:text-lg font-bold text-emerald-600">{q17.stats.growth}</p></div>
        <div className="p-3 md:p-4 bg-gradient-to-br from-purple-50 to-white rounded-xl"><p className="text-xs text-gray-500 mb-1">Destaque</p><p className="text-base md:text-lg font-bold text-gray-900">{q17.stats.jobs||q17.stats.exports||q17.stats.market||q17.stats.rank}</p></div>
      </div>
      <AnimatePresence>{r18&&(<motion.div initial={{opacity:0,height:0}}animate={{opacity:1,height:"auto"}}exit={{opacity:0,height:0}}className="space-y-4">
        <div className="border-t border-gray-200 pt-4">
          <h4 className="font-bold text-gray-900 mb-3 md:mb-4 flex items-center gap-2 text-sm md:text-base"><Award className="w-4 h-4 md:w-5 md:h-5 text-emerald-600"/>Oportunidades de Investimento</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">{q17.opportunities.map((u21,v22)=>(<div key={v22}className="p-3 md:p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"><h5 className="font-semibold text-gray-900 mb-2 text-sm md:text-base">{u21.title}</h5><div className="space-y-1 text-xs md:text-sm"><div className="flex items-center justify-between"><span className="text-gray-600">Crescimento:</span><Badge className="bg-emerald-100 text-emerald-700 text-xs">{u21.growth}</Badge></div><div className="flex items-center justify-between"><span className="text-gray-600">Investimento:</span><span className="font-semibold text-gray-900 text-xs">{u21.investment}</span></div></div></div>))}</div>
        </div>
      </motion.div>)}</AnimatePresence>
    </CardContent>
  </Card>);
});
p16.displayName='SectorCard';

export default function InternationalInvestor(){
  const[w23,x24]=useState(null);
  const[y25,z26]=useState("overview");
  const[aa27,ab28]=useState("");
  const[ac29,ad30]=useState("all");

  useEffect(()=>{const ae31=async()=>{const af32=await base44.auth.me();x24(af32);};ae31();},[]);

  const ag33=useMemo(()=>Object.keys(c3).filter(ah34=>ah34.toLowerCase().includes(aa27.toLowerCase())),[aa27]);
  const ai35=useMemo(()=>ac29==="all"?a1:a1.filter(aj36=>aj36.category===ac29),[ac29]);
  const ak37=[...new Set(a1.map(al38=>al38.category))];

  return(<div className="min-h-screen p-2 md:p-4 lg:p-8 bg-gradient-to-br from-blue-50/30 via-purple-50/30 to-emerald-50/30"><div className="max-w-7xl mx-auto">
    <motion.div initial={{opacity:0,y:-20}}animate={{opacity:1,y:0}}className="mb-6 md:mb-8">
      <div className="flex flex-col md:flex-row items-start md:items-center gap-3 md:gap-4 mb-4 md:mb-6">
        <div className="p-3 md:p-4 rounded-2xl bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-500 shadow-xl flex-shrink-0"><Globe className="w-8 h-8 md:w-10 md:h-10 text-white"/></div>
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl md:text-4xl lg:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent leading-tight">Portal de Investimentos - Brasil</h1>
          <p className="text-sm md:text-xl text-gray-600 mt-1">Descubra oportunidades em turismo, agronegócio e principais destinos</p>
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-emerald-50 to-white"><CardContent className="p-3 md:p-4"><div className="flex items-center gap-2 md:gap-3"><Palmtree className="w-6 h-6 md:w-8 md:h-8 text-emerald-600 flex-shrink-0"/><div className="min-w-0"><p className="text-xs text-gray-500 truncate">Turismo</p><p className="text-lg md:text-xl font-bold text-gray-900">R$ 238B</p></div></div></CardContent></Card>
        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-white"><CardContent className="p-3 md:p-4"><div className="flex items-center gap-2 md:gap-3"><Leaf className="w-6 h-6 md:w-8 md:h-8 text-green-600 flex-shrink-0"/><div className="min-w-0"><p className="text-xs text-gray-500 truncate">Agronegócio</p><p className="text-lg md:text-xl font-bold text-gray-900">R$ 2.5T</p></div></div></CardContent></Card>
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-white"><CardContent className="p-3 md:p-4"><div className="flex items-center gap-2 md:gap-3"><Users className="w-6 h-6 md:w-8 md:h-8 text-blue-600 flex-shrink-0"/><div className="min-w-0"><p className="text-xs text-gray-500 truncate">Turistas/Ano</p><p className="text-lg md:text-xl font-bold text-gray-900">6M+</p></div></div></CardContent></Card>
        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-white"><CardContent className="p-3 md:p-4"><div className="flex items-center gap-2 md:gap-3"><TrendingUp className="w-6 h-6 md:w-8 md:h-8 text-purple-600 flex-shrink-0"/><div className="min-w-0"><p className="text-xs text-gray-500 truncate">Crescimento</p><p className="text-lg md:text-xl font-bold text-emerald-600">+12%</p></div></div></CardContent></Card>
      </div>
    </motion.div>

    <Tabs value={y25}onValueChange={z26}className="space-y-4 md:space-y-6">
      <Card className="border-none shadow-lg"><CardContent className="p-3 md:p-6">
        <TabsList className="bg-gray-100 w-full grid grid-cols-3 md:grid-cols-6 gap-1 h-auto">
          <TabsTrigger value="overview"className="text-xs md:text-sm py-2">🌍 Visão</TabsTrigger>
          <TabsTrigger value="news"className="text-xs md:text-sm py-2">📰 Notícias</TabsTrigger>
          <TabsTrigger value="tourism"className="text-xs md:text-sm py-2">🏖️ Turismo</TabsTrigger>
          <TabsTrigger value="agro"className="text-xs md:text-sm py-2">🌾 Agro</TabsTrigger>
          <TabsTrigger value="cities"className="text-xs md:text-sm py-2">🏙️ Cidades</TabsTrigger>
          <TabsTrigger value="sectors"className="text-xs md:text-sm py-2">🏭 Setores</TabsTrigger>
        </TabsList>
      </CardContent></Card>

      <TabsContent value="news"className="space-y-4 md:space-y-6">
        <Card className="border-none shadow-xl bg-gradient-to-br from-blue-50 via-purple-50 to-emerald-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 md:gap-3">
              <div className="p-2 md:p-3 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg flex-shrink-0"><Newspaper className="w-5 h-5 md:w-6 md:h-6 text-white"/></div>
              <div className="min-w-0"><h2 className="text-xl md:text-2xl truncate">Notícias de Investimentos</h2><p className="text-xs md:text-sm text-gray-600 mt-1 font-normal">Principais portais de economia e mercado financeiro do Brasil</p></div>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-3 md:p-6">
            <div className="mb-4 md:mb-6"><div className="flex flex-wrap gap-2">
              <Button variant={ac29==="all"?"default":"outline"}size="sm"onClick={()=>ad30("all")}className={ac29==="all"?"bg-gradient-to-r from-blue-500 to-purple-500 text-xs":"text-xs"}>Todos</Button>
              {ak37.map(am39=>(<Button key={am39}variant={ac29===am39?"default":"outline"}size="sm"onClick={()=>ad30(am39)}className={ac29===am39?"bg-gradient-to-r from-emerald-500 to-blue-500 text-xs":"text-xs"}>{am39}</Button>))}
            </div></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-8">{ai35.map((an40)=>(<e5 key={an40.name}f6={an40}/>))}</div>
            <div className="border-t border-gray-200 pt-6 md:pt-8">
              <h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-4 md:mb-6 flex items-center gap-2 md:gap-3"><Activity className="w-6 h-6 md:w-7 md:h-7 text-emerald-600"/>Indicadores Econômicos Oficiais</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">{b2.map((ao41)=>(<i9 key={ao41.name}j10={ao41}/>))}</div>
            </div>
            <Alert className="mt-6 md:mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200"><Zap className="w-4 h-4 md:w-5 md:h-5 text-blue-600"/><AlertDescription className="text-gray-700 text-xs md:text-sm"><strong>Mantenha-se Atualizado:</strong> Todos os links abrem em nova aba para você acompanhar as notícias mais recentes do mercado brasileiro em tempo real.</AlertDescription></Alert>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="overview"className="space-y-4 md:space-y-6">
        <Card className="border-none shadow-xl"><CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50"><CardTitle className="flex items-center gap-2 text-base md:text-lg"><Info className="w-5 h-5 md:w-6 md:h-6 text-blue-600"/>Por Que Investir no Brasil?</CardTitle></CardHeader><CardContent className="p-4 md:p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            <div className="space-y-3 md:space-y-4">
              <div className="flex items-start gap-2 md:gap-3"><div className="p-1.5 md:p-2 rounded-lg bg-emerald-100 flex-shrink-0"><TrendingUp className="w-4 h-4 md:w-5 md:h-5 text-emerald-600"/></div><div className="min-w-0"><h4 className="font-bold text-gray-900 mb-1 text-sm md:text-base">Economia em Crescimento</h4><p className="text-xs md:text-sm text-gray-600">9ª maior economia do mundo, PIB de US$ 2 trilhões</p></div></div>
              <div className="flex items-start gap-2 md:gap-3"><div className="p-1.5 md:p-2 rounded-lg bg-blue-100 flex-shrink-0"><Users className="w-4 h-4 md:w-5 md:h-5 text-blue-600"/></div><div className="min-w-0"><h4 className="font-bold text-gray-900 mb-1 text-sm md:text-base">Mercado Interno Massivo</h4><p className="text-xs md:text-sm text-gray-600">214 milhões de habitantes, 5º maior população mundial</p></div></div>
              <div className="flex items-start gap-2 md:gap-3"><div className="p-1.5 md:p-2 rounded-lg bg-purple-100 flex-shrink-0"><Leaf className="w-4 h-4 md:w-5 md:h-5 text-purple-600"/></div><div className="min-w-0"><h4 className="font-bold text-gray-900 mb-1 text-sm md:text-base">Recursos Naturais Abundantes</h4><p className="text-xs md:text-sm text-gray-600">Líder em biodiversidade, agricultura e recursos minerais</p></div></div>
            </div>
            <div className="space-y-3 md:space-y-4">
              <div className="flex items-start gap-2 md:gap-3"><div className="p-1.5 md:p-2 rounded-lg bg-orange-100 flex-shrink-0"><Palmtree className="w-4 h-4 md:w-5 md:h-5 text-orange-600"/></div><div className="min-w-0"><h4 className="font-bold text-gray-900 mb-1 text-sm md:text-base">Destino Turístico de Classe Mundial</h4><p className="text-xs md:text-sm text-gray-600">Praias paradisíacas, Amazônia, cultura rica</p></div></div>
              <div className="flex items-start gap-2 md:gap-3"><div className="p-1.5 md:p-2 rounded-lg bg-yellow-100 flex-shrink-0"><Factory className="w-4 h-4 md:w-5 md:h-5 text-yellow-600"/></div><div className="min-w-0"><h4 className="font-bold text-gray-900 mb-1 text-sm md:text-base">Parque Industrial Desenvolvido</h4><p className="text-xs md:text-sm text-gray-600">8º maior do mundo, setores diversificados</p></div></div>
              <div className="flex items-start gap-2 md:gap-3"><div className="p-1.5 md:p-2 rounded-lg bg-red-100 flex-shrink-0"><Award className="w-4 h-4 md:w-5 md:h-5 text-red-600"/></div><div className="min-w-0"><h4 className="font-bold text-gray-900 mb-1 text-sm md:text-base">Incentivos Governamentais</h4><p className="text-xs md:text-sm text-gray-600">Zonas francas, benefícios fiscais, programas de apoio</p></div></div>
            </div>
          </div>
        </CardContent></Card>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          <Card className="border-none shadow-xl bg-gradient-to-br from-cyan-50 to-blue-50"><CardContent className="p-4 md:p-6">
            <div className="flex items-center gap-3 md:gap-4 mb-3 md:mb-4"><div className="p-3 md:p-4 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 shadow-lg flex-shrink-0"><Palmtree className="w-6 h-6 md:w-8 md:h-8 text-white"/></div><div className="min-w-0"><h3 className="text-xl md:text-2xl font-bold text-gray-900">Turismo</h3><p className="text-emerald-600 font-semibold text-sm md:text-base">+12% crescimento/ano</p></div></div>
            <p className="text-gray-700 mb-3 md:mb-4 text-xs md:text-sm">Brasil é o destino #1 da América do Sul, com praias tropicais, Amazônia, Pantanal, e rica cultura.</p>
            <div className="space-y-2"><div className="flex items-center justify-between"><span className="text-xs md:text-sm text-gray-600">Receita Anual</span><span className="font-bold text-gray-900 text-xs md:text-sm">R$ 238 bilhões</span></div><div className="flex items-center justify-between"><span className="text-xs md:text-sm text-gray-600">Empregos</span><span className="font-bold text-gray-900 text-xs md:text-sm">8 milhões</span></div><div className="flex items-center justify-between"><span className="text-xs md:text-sm text-gray-600">Turistas Internacionais</span><span className="font-bold text-gray-900 text-xs md:text-sm">6+ milhões/ano</span></div></div>
          </CardContent></Card>
          <Card className="border-none shadow-xl bg-gradient-to-br from-green-50 to-emerald-50"><CardContent className="p-4 md:p-6">
            <div className="flex items-center gap-3 md:gap-4 mb-3 md:mb-4"><div className="p-3 md:p-4 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 shadow-lg flex-shrink-0"><Leaf className="w-6 h-6 md:w-8 md:h-8 text-white"/></div><div className="min-w-0"><h3 className="text-xl md:text-2xl font-bold text-gray-900">Agronegócio</h3><p className="text-emerald-600 font-semibold text-sm md:text-base">+15% crescimento/ano</p></div></div>
            <p className="text-gray-700 mb-3 md:mb-4 text-xs md:text-sm">Líder mundial em café, açúcar, soja, suco de laranja, carne bovina e frango.</p>
            <div className="space-y-2"><div className="flex items-center justify-between"><span className="text-xs md:text-sm text-gray-600">Receita Anual</span><span className="font-bold text-gray-900 text-xs md:text-sm">R$ 2.5 trilhões</span></div><div className="flex items-center justify-between"><span className="text-xs md:text-sm text-gray-600">Exportações</span><span className="font-bold text-gray-900 text-xs md:text-sm">50% do total BR</span></div><div className="flex items-center justify-between"><span className="text-xs md:text-sm text-gray-600">Terras Aráveis</span><span className="font-bold text-gray-900 text-xs md:text-sm">388 milhões ha</span></div></div>
          </CardContent></Card>
        </div>
      </TabsContent>

      <TabsContent value="tourism"className="space-y-4 md:space-y-6">
        <Card className="border-none shadow-xl"><CardHeader className="bg-gradient-to-r from-cyan-50 to-blue-50"><CardTitle className="flex items-center gap-2 text-base md:text-lg"><Palmtree className="w-5 h-5 md:w-6 md:h-6 text-cyan-600"/>Oportunidades em Turismo</CardTitle></CardHeader><CardContent className="p-4 md:p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            <div className="p-4 md:p-6 rounded-xl border-2 border-cyan-200 bg-gradient-to-br from-cyan-50 to-white"><Camera className="w-8 h-8 md:w-10 md:h-10 text-cyan-600 mb-3 md:mb-4"/><h4 className="font-bold text-gray-900 mb-2 text-sm md:text-base">Ecoturismo</h4><p className="text-xs md:text-sm text-gray-600 mb-3 md:mb-4">Amazônia, Pantanal, Mata Atlântica</p><Badge className="bg-emerald-100 text-emerald-700 text-xs">Crescimento: 20%/ano</Badge><p className="text-xs text-gray-500 mt-2">Investimento: R$ 200k - 2M</p></div>
            <div className="p-4 md:p-6 rounded-xl border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white"><Waves className="w-8 h-8 md:w-10 md:h-10 text-blue-600 mb-3 md:mb-4"/><h4 className="font-bold text-gray-900 mb-2 text-sm md:text-base">Turismo de Praia</h4><p className="text-xs md:text-sm text-gray-600 mb-3 md:mb-4">7.400km de litoral, praias paradisíacas</p><Badge className="bg-emerald-100 text-emerald-700 text-xs">Crescimento: 15%/ano</Badge><p className="text-xs text-gray-500 mt-2">Investimento: R$ 500k - 5M</p></div>
            <div className="p-4 md:p-6 rounded-xl border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white"><Church className="w-8 h-8 md:w-10 md:h-10 text-purple-600 mb-3 md:mb-4"/><h4 className="font-bold text-gray-900 mb-2 text-sm md:text-base">Turismo Cultural</h4><p className="text-xs md:text-sm text-gray-600 mb-3 md:mb-4">Cidades históricas, festivais, gastronomia</p><Badge className="bg-emerald-100 text-emerald-700 text-xs">Crescimento: 18%/ano</Badge><p className="text-xs text-gray-500 mt-2">Investimento: R$ 300k - 3M</p></div>
            <div className="p-4 md:p-6 rounded-xl border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-white"><Mountain className="w-8 h-8 md:w-10 md:h-10 text-orange-600 mb-3 md:mb-4"/><h4 className="font-bold text-gray-900 mb-2 text-sm md:text-base">Turismo de Aventura</h4><p className="text-xs md:text-sm text-gray-600 mb-3 md:mb-4">Trilhas, rapel, rafting, escalada</p><Badge className="bg-emerald-100 text-emerald-700 text-xs">Crescimento: 22%/ano</Badge><p className="text-xs text-gray-500 mt-2">Investimento: R$ 150k - 1.5M</p></div>
            <div className="p-4 md:p-6 rounded-xl border-2 border-red-200 bg-gradient-to-br from-red-50 to-white"><UtensilsCrossed className="w-8 h-8 md:w-10 md:h-10 text-red-600 mb-3 md:mb-4"/><h4 className="font-bold text-gray-900 mb-2 text-sm md:text-base">Gastronomia</h4><p className="text-xs md:text-sm text-gray-600 mb-3 md:mb-4">Restaurantes, food tours, eventos culinários</p><Badge className="bg-emerald-100 text-emerald-700 text-xs">Crescimento: 12%/ano</Badge><p className="text-xs text-gray-500 mt-2">Investimento: R$ 100k - 800k</p></div>
            <div className="p-4 md:p-6 rounded-xl border-2 border-green-200 bg-gradient-to-br from-green-50 to-white"><Building2 className="w-8 h-8 md:w-10 md:h-10 text-green-600 mb-3 md:mb-4"/><h4 className="font-bold text-gray-900 mb-2 text-sm md:text-base">Hotelaria</h4><p className="text-xs md:text-sm text-gray-600 mb-3 md:mb-4">Hotéis, pousadas, resorts, Airbnb</p><Badge className="bg-emerald-100 text-emerald-700 text-xs">Crescimento: 16%/ano</Badge><p className="text-xs text-gray-500 mt-2">Investimento: R$ 1M - 20M</p></div>
          </div>
        </CardContent></Card>
      </TabsContent>

      <TabsContent value="agro"className="space-y-4 md:space-y-6">
        <Card className="border-none shadow-xl"><CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50"><CardTitle className="flex items-center gap-2 text-base md:text-lg"><Leaf className="w-5 h-5 md:w-6 md:h-6 text-green-600"/>Oportunidades em Agronegócio</CardTitle></CardHeader><CardContent className="p-4 md:p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 mb-4 md:mb-6">
            <div className="p-4 md:p-6 rounded-xl bg-gradient-to-br from-green-50 to-white border-2 border-green-200"><h4 className="font-bold text-gray-900 mb-3 md:mb-4 flex items-center gap-2 text-sm md:text-base"><Star className="w-4 h-4 md:w-5 md:h-5 text-yellow-500"/>Brasil é Líder Mundial em:</h4><div className="space-y-2">{[{p:"☕ Café",b:"#1 Produtor"},{p:"🥩 Carne Bovina",b:"#1 Exportador"},{p:"🌱 Soja",b:"#1 Exportador"},{p:"🍊 Suco de Laranja",b:"#1 Produtor"},{p:"🍬 Açúcar",b:"#1 Produtor"},{p:"🐔 Frango",b:"#1 Exportador"}].map((ap42,aq43)=>(<div key={aq43}className="flex items-center justify-between"><span className="text-xs md:text-sm text-gray-700">{ap42.p}</span><Badge className="bg-yellow-100 text-yellow-800 text-xs">{ap42.b}</Badge></div>))}</div></div>
            <div className="p-4 md:p-6 rounded-xl bg-gradient-to-br from-emerald-50 to-white border-2 border-emerald-200"><h4 className="font-bold text-gray-900 mb-3 md:mb-4 flex items-center gap-2 text-sm md:text-base"><TrendingUp className="w-4 h-4 md:w-5 md:h-5 text-emerald-600"/>Setores em Crescimento:</h4><div className="space-y-2 md:space-y-3">{[{t:"Agricultura Orgânica",g:"+25%/ano",c:"emerald",i:"R$ 1M - 10M"},{t:"AgTech",g:"+30%/ano",c:"blue",i:"R$ 500k - 5M"},{t:"Processamento",g:"+15%/ano",c:"orange",i:"R$ 2M - 20M"},{t:"Exportação",g:"+18%/ano",c:"purple",i:"R$ 1M - 15M"}].map((ar44,as45)=>(<div key={as45}className="p-2 md:p-3 bg-white rounded-lg"><div className="flex items-center justify-between mb-1"><span className="text-xs md:text-sm font-semibold text-gray-900 truncate">{ar44.t}</span><Badge className={`bg-${ar44.c}-500 text-white text-xs flex-shrink-0 ml-2`}>{ar44.g}</Badge></div><p className="text-xs text-gray-600">{ar44.i}</p></div>))}</div></div>
          </div>
          <Alert className="bg-emerald-50 border-emerald-200"><Info className="w-4 h-4 text-emerald-600"/><AlertDescription className="text-gray-700 text-xs md:text-sm"><strong>Incentivo Especial:</strong> Brasil oferece linhas de crédito subsidiadas para investimentos agrícolas através do BNDES e programas estaduais.</AlertDescription></Alert>
        </CardContent></Card>
      </TabsContent>

      <TabsContent value="cities"className="space-y-4 md:space-y-6">
        <Card className="border-none shadow-xl"><CardHeader>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 md:gap-0">
            <CardTitle className="flex items-center gap-2 text-base md:text-lg"><MapPin className="w-5 h-5 md:w-6 md:h-6 text-emerald-600"/>Principais Cidades Turísticas por Estado</CardTitle>
            <div className="relative w-full md:w-64"><Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-3 h-3 md:w-4 md:h-4"/><Input placeholder="Buscar estado..."value={aa27}onChange={(at46)=>ab28(at46.target.value)}className="pl-8 md:pl-10 h-9 md:h-10 text-sm"/></div>
          </div>
        </CardHeader><CardContent className="p-4 md:p-6">
          <div className="space-y-6 md:space-y-8">{ag33.map((au47)=>(<div key={au47}><h3 className="text-xl md:text-2xl font-bold text-gray-900 mb-3 md:mb-4 flex items-center gap-2"><MapPin className="w-5 h-5 md:w-6 md:h-6 text-emerald-600"/>{au47}</h3><div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">{c3[au47].map((av48)=>(<k11 key={av48.name}l12={av48}m13={au47}/>))}</div></div>))}</div>
        </CardContent></Card>
      </TabsContent>

      <TabsContent value="sectors"className="space-y-4 md:space-y-6">{d4.map((aw49)=>(<p16 key={aw49.name}q17={aw49}/>))}</TabsContent>
    </Tabs>
  </div></div>);
}