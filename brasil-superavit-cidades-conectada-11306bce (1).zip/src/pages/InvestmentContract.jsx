
import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  FileText,
  Download,
  CheckCircle,
  Loader2,
  AlertTriangle,
  Shield,
  Pen,
  Send,
  ArrowLeft,
  FileSignature,
  Percent,
  Info
} from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function InvestmentContract() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const canvasRef = useRef(null);

  const investmentId = searchParams.get("investment_id");

  const [user, setUser] = useState(null);
  const [investment, setInvestment] = useState(null);
  const [project, setProject] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSigning, setIsSigning] = useState(false);
  const [signatureName, setSignatureName] = useState("");
  const [signatureDate, setSignatureDate] = useState(format(new Date(), "dd/MM/yyyy"));
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasSignature, setHasSignature] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      try {
        const isAuth = await base44.auth.isAuthenticated();
        if (!isAuth) {
          base44.auth.redirectToLogin(window.location.pathname);
          return;
        }

        const userData = await base44.auth.me();
        setUser(userData);
        setSignatureName(userData.full_name || "");

        const investments = await base44.entities.Investment.filter({ id: investmentId });
        if (investments.length > 0) {
          const inv = investments[0];
          setInvestment(inv); // Set investment early to display details

          const projects = await base44.entities.Project.filter({ id: inv.project_id });
          if (projects.length > 0) {
            const proj = projects[0];
            setProject(proj);

            // Auto-generate contract if not exists
            if (!inv.contract_html && !inv.contract_url) {
              toast.info("📄 Gerando seu contrato personalizado...");
              await generateContract(inv, proj, userData);
            } else {
              setInvestment(inv); // Ensure state is updated even if contract exists
            }
          }
        }
      } catch (error) {
        console.error("Error loading data:", error);
        toast.error("Erro ao carregar dados");
      } finally {
        setIsLoading(false);
      }
    };

    if (investmentId) {
      loadData();
    }
  }, [investmentId]);

  // Canvas signature handling
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    ctx.strokeStyle = '#1e40af';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';

    let drawing = false;
    let lastX = 0;
    let lastY = 0;

    const startDrawing = (e) => {
      drawing = true;
      const rect = canvas.getBoundingClientRect();
      lastX = (e.clientX || e.touches[0].clientX) - rect.left;
      lastY = (e.clientY || e.touches[0].clientY) - rect.top;
      setHasSignature(true);
    };

    const draw = (e) => {
      if (!drawing) return;
      e.preventDefault();

      const rect = canvas.getBoundingClientRect();
      const x = (e.clientX || e.touches[0].clientX) - rect.left;
      const y = (e.clientY || e.touches[0].clientY) - rect.top;

      ctx.beginPath();
      ctx.moveTo(lastX, lastY);
      ctx.lineTo(x, y);
      ctx.stroke();

      lastX = x;
      lastY = y;
    };

    const stopDrawing = () => {
      drawing = false;
    };

    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('touchstart', startDrawing);
    canvas.addEventListener('touchmove', draw);
    canvas.addEventListener('touchend', stopDrawing);

    return () => {
      canvas.removeEventListener('mousedown', startDrawing);
      canvas.removeEventListener('mousemove', draw);
      canvas.removeEventListener('mouseup', stopDrawing);
      canvas.removeEventListener('touchstart', startDrawing);
      canvas.removeEventListener('touchmove', draw);
      canvas.removeEventListener('touchend', stopDrawing);
    };
  }, []);

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      setHasSignature(false);
    }
  };

  const downloadContractPDF = () => {
    if (!investment?.contract_html) {
      toast.error("Contrato não disponível para download");
      return;
    }

    // Create a printable HTML version
    const printWindow = window.open('', '_blank');
    const contractContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Contrato de Investimento - ${investment.contract_id || `BSA-${investment.id.substring(0, 8)}`}</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 40px auto;
            padding: 20px;
            line-height: 1.6;
            color: #333;
          }
          h1, h2, h3, h4, h5, h6 { color: #1f2937; margin-top: 1.5em; margin-bottom: 0.5em; }
          h1 { font-size: 2em; }
          h2 { font-size: 1.5em; }
          strong { font-weight: bold; }
          .header {
            text-align: center;
            border-bottom: 3px solid #059669;
            padding-bottom: 20px;
            margin-bottom: 30px;
          }
          .section {
            margin: 20px 0;
            padding: 15px;
            background: #f9fafb;
            border-left: 4px solid #059669;
          }
          .signature-block {
            margin-top: 60px;
            padding-top: 20px;
            border-top: 2px solid #000;
          }
          table { width: 100%; border-collapse: collapse; margin: 15px 0; }
          th, td { padding: 10px; text-align: left; border: 1px solid #ddd; }
          th { background: #059669; color: white; }
          img { max-width: 100%; height: auto; display: block; margin-top: 10px;} /* For signature image */
          .prose { /* mimic tailwind typography plugin's prose styles */
            line-height: 1.75;
            color: #374151;
          }
          .prose h1, .prose h2, .prose h3, .prose h4 {
            color: #111827;
            font-weight: 700;
          }
          .prose h1 { font-size: 2.25em; }
          .prose h2 { font-size: 1.875em; }
          .prose h3 { font-size: 1.5em; }
          .prose p {
            margin-top: 1em;
            margin-bottom: 1em;
          }
          .prose ul {
            list-style-type: disc;
            padding-left: 1.5em;
          }
          .prose ol {
            list-style-type: decimal;
            padding-left: 1.5em;
          }
          .prose li {
            margin-bottom: 0.5em;
          }
          @media print {
            body { margin: 0; }
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>CONTRATO DE INVESTIMENTO E PARTICIPAÇÃO SOCIETÁRIA</h1>
          <p><strong>ID:</strong> ${investment.contract_id || `BSA-${investment.id.substring(0, 8)}`}</p>
          <p><strong>Data:</strong> ${format(new Date(), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}</p>
        </div>

        <div class="prose">
          ${investment.contract_html}
        </div>

        <div class="signature-block">
          <p><strong>Assinatura Digital do Investidor:</strong> ${signatureName || user?.full_name || 'N/A'}</p>
          <p><strong>Data da Assinatura:</strong> ${signatureDate}</p>
          ${investment.digital_signature ? `<img src="${investment.digital_signature}" alt="Assinatura Digital" style="max-width: 300px; border: 1px solid #ddd; padding: 10px; background-color: #fff;">` : '<p>Assinatura pendente</p>'}
        </div>

        <div class="no-print" style="text-align: center; margin-top: 40px;">
          <button onclick="window.print()" style="background: #059669; color: white; border: none; padding: 12px 24px; font-size: 16px; cursor: pointer; border-radius: 8px;">
            🖨️ Imprimir / Salvar PDF
          </button>
          <button onclick="window.close()" style="background: #6b7280; color: white; border: none; padding: 12px 24px; font-size: 16px; cursor: pointer; border-radius: 8px; margin-left: 10px;">
            Fechar
          </button>
        </div>
      </body>
      </html>
    `;

    printWindow.document.write(contractContent);
    printWindow.document.close();

    toast.success("✅ Contrato aberto em nova janela. Use Ctrl+P ou Cmd+P para salvar em PDF!");
  };

  const generateContract = async (inv = investment, proj = project, userData = user) => {
    if (!inv || !proj || !userData) {
      toast.error("Dados incompletos para gerar contrato");
      return;
    }

    setIsGenerating(true);

    try {
      const contractId = `BRASIL-SUPERAVIT-${inv.id.substring(0, 8).toUpperCase()}`;

      const contractHtml = await base44.integrations.Core.InvokeLLM({
        prompt: `Gere um contrato de investimento profissional em HTML formatado com:

**CABEÇALHO**
CONTRATO DE INVESTIMENTO E PARTICIPAÇÃO SOCIETÁRIA
ID: ${contractId}

**1. QUALIFICAÇÃO DAS PARTES**

INVESTIDOR: ${userData.full_name}
CPF: ${userData.cpf || 'A informar'}
Email: ${userData.email}
Endereço: ${userData.location || 'A informar'}

PROJETO/EMPRESA: ${proj.title}
Localização: ${proj.city}, ${proj.state}

**2. OBJETO DO CONTRATO**

O INVESTIDOR realiza o investimento de R$ ${inv.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} (${new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(inv.amount)} por extenso) no projeto, adquirindo participação societária de ${inv.equity_percentage.toFixed(4)}% (${(inv.equity_percentage.toFixed(4))} por cento) do capital social.

**3. CARACTERÍSTICAS DA PARTICIPAÇÃO**

- Valuation da empresa: R$ ${(proj.company_valuation || proj.funding_goal * 10).toLocaleString('pt-BR')}
- Percentual total oferecido na rodada: ${proj.equity_offered}%
- Participação do investidor: ${inv.equity_percentage.toFixed(4)}%
- Cálculo: (R$ ${inv.amount.toLocaleString('pt-BR')} ÷ R$ ${proj.funding_goal.toLocaleString('pt-BR')}) × ${proj.equity_offered}% = ${inv.equity_percentage.toFixed(4)}%

**4. DIREITOS DO INVESTIDOR**

- Tag Along: Direito de venda conjunta em caso de venda do controle
- Drag Along: Obrigação de venda conjunta em certas condições
- Direito de preferência em novas rodadas
- Acesso a relatórios trimestrais
- Participação nos lucros proporcional

**5. TAXAS E COMISSÕES**

- Taxa da plataforma Brasil Superávit: 6,5%
- Taxa calculada: R$ ${(inv.amount * 0.065).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
- Valor líquido para o projeto: R$ ${(inv.amount * 0.935).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}

**6. RISCOS**

O investidor declara estar ciente dos riscos, incluindo perda total ou parcial do capital, conforme Resolução CVM 88/2022.

**7. VIGÊNCIA E FORO**

Este contrato entra em vigor na data: ${format(new Date(), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
Foro: Comarca de ${proj.city}, ${proj.state}

**8. ASSINATURAS**

___________________________________
${userData.full_name}
INVESTIDOR
CPF: ${userData.cpf || 'A informar'}

___________________________________
${proj.title}
PROJETO

Retorne HTML bem formatado com títulos em negrito, seções numeradas, tabelas para valores. Use classes do Tailwind: font-bold, text-lg, mt-4, mb-2, border, p-4, etc.`,
        response_json_schema: {
          type: "object",
          properties: {
            html: { type: "string" }
          }
        }
      });

      await base44.entities.Investment.update(inv.id, {
        contract_url: "generated",
        contract_html: contractHtml.html,
        contract_id: contractId
      });

      setInvestment({ ...inv, contract_html: contractHtml.html, contract_url: "generated", contract_id: contractId });
      toast.success("✅ Contrato gerado com sucesso!");

    } catch (error) {
      console.error("Error generating contract:", error);
      toast.error("Erro ao gerar contrato. Tente novamente.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSignContract = async () => {
    if (!hasSignature || !signatureName) {
      toast.error("Por favor, assine o contrato antes de continuar.");
      return;
    }

    setIsSigning(true);

    try {
      const canvas = canvasRef.current;
      const signatureData = canvas.toDataURL();

      await base44.entities.Investment.update(investmentId, {
        contract_signed: true,
        contract_signed_date: new Date().toISOString().split('T')[0],
        digital_signature: signatureData,
        status: "processando"
      });

      toast.success("✅ Contrato assinado! Redirecionando para pagamento...");

      setTimeout(() => {
        navigate(createPageUrl(`PaymentCallback?investment_id=${investmentId}&status=pending`));
      }, 1500);

    } catch (error) {
      console.error("Error signing contract:", error);
      toast.error("Erro ao assinar contrato.");
      setIsSigning(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <Loader2 className="w-16 h-16 text-blue-600 mx-auto animate-spin" />
            <h2 className="text-2xl font-bold text-gray-900">Carregando dados...</h2>
            <p className="text-gray-600">Aguarde enquanto carregamos os detalhes do seu investimento.</p>
          </div>
        </Card>
      </div>
    );
  }

  if (!investment || !project) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <AlertTriangle className="w-16 h-16 text-red-600 mx-auto" />
            <h2 className="text-2xl font-bold text-gray-900">Investimento não encontrado</h2>
            <Button onClick={() => navigate(createPageUrl("MyInvestments"))}>
              Ir para Meus Investimentos
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Button
            variant="ghost"
            onClick={() => navigate(createPageUrl("MyInvestments"))}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>

          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-500 shadow-lg">
              <FileSignature className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-gray-900">
                Contrato de Investimento
              </h1>
              <p className="text-gray-600 mt-1">Assine digitalmente para confirmar</p>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Main Contract Area */}
          <div className="md:col-span-2 space-y-6">
            {/* Investment Summary with Percentage Highlight */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="border-2 border-purple-200 shadow-xl">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50">
                  <CardTitle className="flex items-center gap-2">
                    <Percent className="w-6 h-6 text-purple-600" />
                    Sua Participação Societária
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="p-4 bg-white rounded-lg border-2 border-purple-200">
                      <p className="text-sm text-gray-600 mb-1">Investidor</p>
                      <p className="font-semibold text-gray-900">{investment.investor_name}</p>
                      <p className="text-xs text-gray-500">{investment.investor_email}</p>
                    </div>
                    <div className="p-4 bg-white rounded-lg border-2 border-blue-200">
                      <p className="text-sm text-gray-600 mb-1">Projeto</p>
                      <p className="font-semibold text-gray-900">{project.title}</p>
                      <p className="text-xs text-gray-500">{project.city}/{project.state}</p>
                    </div>
                  </div>

                  <Alert className="border-purple-300 bg-purple-50 mb-4">
                    <Info className="h-5 w-5 text-purple-600" />
                    <AlertDescription className="text-purple-900">
                      <div className="space-y-2">
                        <p className="font-bold text-lg">Cálculo da Participação:</p>
                        <div className="bg-white p-3 rounded-lg font-mono text-sm">
                          <p>Valor investido: R$ {investment.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                          <p>Meta total: R$ {project.funding_goal.toLocaleString('pt-BR')}</p>
                          <p>Equity oferecido: {project.equity_offered}%</p>
                          <Separator className="my-2" />
                          <p className="font-bold text-purple-700">
                            Sua participação = (R$ {investment.amount.toLocaleString('pt-BR')} ÷ R$ {project.funding_goal.toLocaleString('pt-BR')}) × {project.equity_offered}%
                          </p>
                          <p className="text-2xl font-bold text-purple-900 mt-2">
                            = {investment.equity_percentage?.toFixed(4)}%
                          </p>
                        </div>
                      </div>
                    </AlertDescription>
                  </Alert>

                  <div className="p-6 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-xl border-2 border-purple-300">
                    <p className="text-sm text-purple-700 mb-2 text-center">Você será proprietário de:</p>
                    <p className="text-5xl font-bold text-purple-900 text-center">
                      {investment.equity_percentage?.toFixed(4)}%
                    </p>
                    <p className="text-center text-purple-700 mt-2">do capital social do projeto</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Contract Document */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="border-none shadow-xl">
                <CardHeader className="bg-gradient-to-r from-gray-50 to-blue-50">
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-6 h-6 text-blue-600" />
                      Documento do Contrato
                    </CardTitle>
                    {investment.contract_html && (
                      <Button
                        onClick={downloadContractPDF}
                        variant="outline"
                        size="sm"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Baixar PDF
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  {isGenerating ? (
                    <div className="text-center py-12">
                      <Loader2 className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-spin" />
                      <p className="text-gray-600">Gerando seu contrato personalizado...</p>
                      <p className="text-sm text-gray-500 mt-2">Isso pode levar alguns segundos</p>
                    </div>
                  ) : investment.contract_html ? (
                    <div>
                      <Alert className="border-emerald-200 bg-emerald-50 mb-4">
                        <CheckCircle className="h-4 w-4 text-emerald-600" />
                        <AlertDescription className="text-emerald-900">
                          <strong>Contrato pronto!</strong> Revise os termos e assine abaixo.
                        </AlertDescription>
                      </Alert>

                      <div className="p-6 bg-white rounded-lg border-2 border-gray-200 max-h-96 overflow-y-auto mb-6">
                        <div
                          className="prose prose-sm max-w-none"
                          dangerouslySetInnerHTML={{ __html: investment.contract_html }}
                        />
                      </div>

                      {/* Electronic Signature */}
                      <div className="space-y-4 border-t-2 border-gray-200 pt-6">
                        <h3 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                          <Pen className="w-6 h-6 text-indigo-600" />
                          Assinatura Eletrônica
                        </h3>

                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <Label className="text-base font-semibold mb-2">Nome Completo</Label>
                            <Input
                              value={signatureName}
                              onChange={(e) => setSignatureName(e.target.value)}
                              placeholder="Digite seu nome completo"
                              className="h-12"
                            />
                          </div>
                          <div>
                            <Label className="text-base font-semibold mb-2">Data</Label>
                            <Input
                              value={signatureDate}
                              disabled
                              className="h-12 bg-gray-50"
                            />
                          </div>
                        </div>

                        <div>
                          <Label className="text-base font-semibold mb-2">Assine Aqui (use o mouse ou toque)</Label>
                          <div className="relative">
                            <canvas
                              ref={canvasRef}
                              width={600}
                              height={200}
                              className="border-2 border-dashed border-gray-300 rounded-lg w-full bg-white cursor-crosshair touch-none"
                              style={{ touchAction: 'none' }}
                            />
                            {!hasSignature && (
                              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                <p className="text-gray-400 text-lg">✍️ Desenhe sua assinatura aqui</p>
                              </div>
                            )}
                          </div>
                          <div className="flex justify-end mt-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={clearSignature}
                              disabled={!hasSignature}
                            >
                              Limpar Assinatura
                            </Button>
                          </div>
                        </div>

                        <Alert className="border-blue-200 bg-blue-50">
                          <Shield className="h-4 w-4 text-blue-600" />
                          <AlertDescription className="text-blue-900 text-sm">
                            <strong>Assinatura Eletrônica Válida:</strong> Ao assinar digitalmente, você concorda com todos os termos deste contrato.
                            A assinatura eletrônica tem validade jurídica conforme MP 2.200-2/2001 e Lei 14.063/2020.
                          </AlertDescription>
                        </Alert>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 mb-4">Gerando contrato automaticamente...</p>
                      <Button onClick={() => generateContract()} disabled={isGenerating}>
                        {isGenerating ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Gerando...
                          </>
                        ) : (
                          'Tentar Novamente'
                        )}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="sticky top-8"
            >
              <Card className="border-none shadow-2xl">
                <CardHeader className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
                  <CardTitle>Detalhes Finais</CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  <div className="space-y-3">
                    <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                      <p className="text-sm text-purple-700 mb-1">Sua Participação</p>
                      <p className="text-4xl font-bold text-purple-900">
                        {investment.equity_percentage?.toFixed(4)}%
                      </p>
                    </div>

                    <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                      <p className="text-sm text-emerald-700 mb-1">Valor Total</p>
                      <p className="text-3xl font-bold text-emerald-900">
                        R$ {investment.amount?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </p>
                    </div>

                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <p className="text-sm text-blue-700 mb-1">ID do Contrato</p>
                      <p className="text-sm font-mono font-bold text-blue-900">
                        {investment.contract_id || `BSA-${investmentId.substring(0, 8)}`}
                      </p>
                    </div>
                  </div>

                  <Alert className="border-amber-200 bg-amber-50">
                    <Shield className="h-4 w-4 text-amber-600" />
                    <AlertDescription className="text-amber-900 text-xs">
                      Contrato protegido com validade jurídica. Você receberá uma cópia por email.
                    </AlertDescription>
                  </Alert>

                  <Separator />

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <CheckCircle className={`w-4 h-4 ${investment.contract_html ? 'text-emerald-600' : 'text-gray-300'}`} />
                      <span className={investment.contract_html ? 'text-gray-900' : 'text-gray-400'}>
                        Contrato gerado
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className={`w-4 h-4 ${hasSignature && signatureName ? 'text-emerald-600' : 'text-gray-300'}`} />
                      <span className={hasSignature && signatureName ? 'text-gray-900' : 'text-gray-400'}>
                        Assinatura completa
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-gray-300" />
                      <span className="text-gray-400">Pagamento confirmado</span>
                    </div>
                  </div>

                  {investment.contract_html && (
                    <Button
                      onClick={downloadContractPDF}
                      variant="outline"
                      className="w-full"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Baixar Contrato em PDF
                    </Button>
                  )}

                  <Button
                    onClick={handleSignContract}
                    disabled={!hasSignature || !signatureName || isGenerating || isSigning}
                    className="w-full h-14 text-lg bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSigning ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Assinando...
                      </>
                    ) : (
                      <>
                        <Send className="w-5 h-5 mr-2" />
                        Assinar e Pagar Agora
                      </>
                    )}
                  </Button>

                  <p className="text-xs text-center text-gray-500">
                    Ao assinar, você será redirecionado para o pagamento via Mercado Pago
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
