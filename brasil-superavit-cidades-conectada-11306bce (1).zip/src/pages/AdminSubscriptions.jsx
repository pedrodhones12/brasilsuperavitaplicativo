import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Shield,
  Crown,
  CheckCircle,
  XCircle,
  Clock,
  DollarSign,
  Users,
  TrendingUp,
  Calendar,
  Search,
  RefreshCw,
  Edit,
  Trash2,
  FileText,
  Download,
  AlertTriangle,
  Mail,
  CreditCard,
  Activity,
  BarChart3,
  Loader2
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

// ✅ FUNÇÃO PARA VERIFICAR SE É ADMIN
const isAdminUser = (email) => {
  const adminEmails = ['pedrodhones15@gmail.com', 'pedrodhones15.com'];
  return adminEmails.some(adminEmail => email?.toLowerCase().includes(adminEmail.toLowerCase()));
};

const statusConfig = {
  authorized: {
    label: "✅ Ativa",
    color: "bg-emerald-100 text-emerald-800 border-emerald-300",
    icon: CheckCircle
  },
  pending: {
    label: "⏳ Pendente",
    color: "bg-yellow-100 text-yellow-800 border-yellow-300",
    icon: Clock
  },
  paused: {
    label: "⏸️ Pausada",
    color: "bg-blue-100 text-blue-800 border-blue-300",
    icon: Clock
  },
  cancelled: {
    label: "❌ Cancelada",
    color: "bg-red-100 text-red-800 border-red-300",
    icon: XCircle
  }
};

const SubscriptionCard = ({ subscription, onEdit, onCancel, events }) => {
  const status = statusConfig[subscription.status] || statusConfig.pending;
  const StatusIcon = status.icon;
  
  const userEvents = events.filter(e => e.user_email === subscription.user_email);
  const lastPayment = userEvents.find(e => e.event_type === 'payment_received');
  const nextBilling = subscription.next_billing_date 
    ? new Date(subscription.next_billing_date) 
    : null;
  const daysUntilBilling = nextBilling 
    ? Math.ceil((nextBilling - new Date()) / (1000 * 60 * 60 * 24))
    : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
        <div className={`h-2 bg-gradient-to-r ${
          subscription.status === 'authorized' ? 'from-emerald-500 to-green-500' :
          subscription.status === 'pending' ? 'from-yellow-500 to-orange-500' :
          'from-gray-500 to-gray-600'
        }`} />
        <CardHeader className="pb-3">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="font-bold text-lg text-gray-900">{subscription.user_name || 'Sem nome'}</h3>
                <Badge className={`${status.color} border`}>
                  <StatusIcon className="w-3 h-3 mr-1" />
                  {status.label}
                </Badge>
              </div>
              <p className="text-sm text-gray-600">{subscription.user_email}</p>
            </div>
            <Badge variant="outline" className="font-bold">
              {subscription.currency} {subscription.amount?.toLocaleString()}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500 mb-1">Plano</p>
              <p className="text-sm font-bold text-gray-900">
                {subscription.plan_id?.includes('monthly') ? '📅 Mensal' : '📆 Anual'}
              </p>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500 mb-1">Pagamento</p>
              <p className="text-sm font-bold text-gray-900">
                {subscription.payment_method === 'mercado_pago' ? '🇧🇷 Mercado Pago' : 
                 subscription.payment_method === 'stripe' ? '💳 Stripe' : 
                 subscription.payment_method || 'N/A'}
              </p>
            </div>
          </div>

          {subscription.start_date && (
            <div className="flex items-center gap-2 text-sm">
              <Calendar className="w-4 h-4 text-gray-500" />
              <span className="text-gray-600">
                Início: {format(new Date(subscription.start_date), "dd/MM/yyyy")}
              </span>
            </div>
          )}

          {lastPayment && (
            <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
              <p className="text-xs text-emerald-700 mb-1">Último Pagamento</p>
              <p className="text-sm font-semibold text-emerald-900">
                {format(new Date(lastPayment.created_date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
              </p>
            </div>
          )}

          {nextBilling && subscription.status === 'authorized' && (
            <div className={`p-3 rounded-lg border ${
              daysUntilBilling <= 3 ? 'bg-red-50 border-red-200' :
              daysUntilBilling <= 7 ? 'bg-yellow-50 border-yellow-200' :
              'bg-blue-50 border-blue-200'
            }`}>
              <p className="text-xs text-gray-600 mb-1">Próxima Cobrança</p>
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-gray-900">
                  {format(nextBilling, "dd/MM/yyyy")}
                </p>
                {daysUntilBilling <= 7 && (
                  <Badge className={`${daysUntilBilling <= 3 ? 'bg-red-500' : 'bg-yellow-500'} text-white`}>
                    {daysUntilBilling}d
                  </Badge>
                )}
              </div>
            </div>
          )}

          <div className="flex gap-2 pt-3 border-t border-gray-200">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onEdit(subscription)}
              className="flex-1"
            >
              <Edit className="w-4 h-4 mr-2" />
              Editar
            </Button>
            {subscription.status !== 'cancelled' && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onCancel(subscription)}
                className="flex-1 text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Cancelar
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const StatCard = ({ title, value, icon: Icon, gradient, description }) => (
  <Card className="border-none shadow-lg">
    <CardContent className="p-6">
      <div className="flex items-center justify-between mb-3">
        <div className={`p-3 rounded-xl bg-gradient-to-br ${gradient}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
      <p className="text-sm text-gray-500 mb-1">{title}</p>
      <p className="text-3xl font-bold text-gray-900 mb-1">{value}</p>
      {description && <p className="text-xs text-gray-600">{description}</p>}
    </CardContent>
  </Card>
);

export default function AdminSubscriptions() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const isAuthenticated = await base44.auth.isAuthenticated();
        
        if (!isAuthenticated) {
          base44.auth.redirectToLogin(window.location.pathname);
          return;
        }

        const userData = await base44.auth.me();
        setUser(userData);

        // ✅ VERIFICAR SE É ADMIN
        if (!isAdminUser(userData.email)) {
          window.location.href = "/dashboard";
          return;
        }

        setIsCheckingAuth(false);
      } catch (error) {
        console.error("Auth error:", error);
        base44.auth.redirectToLogin(window.location.pathname);
      }
    };

    checkAuth();
  }, []);

  const { data: subscriptions = [], isLoading, refetch } = useQuery({
    queryKey: ['admin-subscriptions'],
    queryFn: () => base44.entities.Subscription.list('-created_date'),
    enabled: !!user && !isCheckingAuth,
    refetchInterval: 30000 // Atualizar a cada 30 segundos
  });

  const { data: events = [] } = useQuery({
    queryKey: ['subscription-events'],
    queryFn: () => base44.entities.SubscriptionEvent.list('-created_date'),
    enabled: !!user && !isCheckingAuth
  });

  const updateSubscriptionMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Subscription.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-subscriptions'] });
      alert("✅ Assinatura atualizada!");
    }
  });

  const handleManualActivation = (subscription) => {
    if (window.confirm(`Ativar manualmente a assinatura de ${subscription.user_name}?`)) {
      updateSubscriptionMutation.mutate({
        id: subscription.id,
        data: { status: 'authorized' }
      });
    }
  };

  const handleCancelSubscription = (subscription) => {
    if (window.confirm(`Cancelar assinatura de ${subscription.user_name}?`)) {
      updateSubscriptionMutation.mutate({
        id: subscription.id,
        data: { status: 'cancelled' }
      });
    }
  };

  const filteredSubscriptions = subscriptions.filter(sub => {
    const matchesSearch = !searchQuery || 
      sub.user_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      sub.user_email?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesTab = activeTab === 'all' || sub.status === activeTab;

    return matchesSearch && matchesTab;
  });

  const stats = {
    total: subscriptions.length,
    active: subscriptions.filter(s => s.status === 'authorized').length,
    pending: subscriptions.filter(s => s.status === 'pending').length,
    cancelled: subscriptions.filter(s => s.status === 'cancelled').length,
    totalRevenue: subscriptions
      .filter(s => s.status === 'authorized' || s.status === 'pending')
      .reduce((sum, s) => sum + (s.amount || 0), 0)
  };

  const exportReport = () => {
    const report = {
      generated_at: new Date().toISOString(),
      statistics: stats,
      subscriptions: subscriptions.map(sub => ({
        user_email: sub.user_email,
        user_name: sub.user_name,
        status: sub.status,
        amount: sub.amount,
        currency: sub.currency,
        start_date: sub.start_date,
        plan_id: sub.plan_id
      }))
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `subscriptions-report-${format(new Date(), 'yyyy-MM-dd')}.json`;
    a.click();
  };

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-orange-50">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-red-500 to-orange-500 animate-pulse">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Verificando Permissões...</h2>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-red-50/50 via-orange-50/50 to-yellow-50/50">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-red-500 to-orange-500 shadow-xl">
                  <Shield className="w-10 h-10 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">
                    Gerenciar Assinaturas
                  </h1>
                  <p className="text-lg text-gray-600 mt-1">Painel Administrativo</p>
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => refetch()}
                className="gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Atualizar
              </Button>
              <Button
                onClick={exportReport}
                className="bg-gradient-to-r from-blue-500 to-purple-500 gap-2"
              >
                <Download className="w-4 h-4" />
                Exportar
              </Button>
            </div>
          </div>

          {/* Admin Badge */}
          <Alert className="border-2 border-red-500 bg-gradient-to-r from-red-50 to-orange-50 mb-6">
            <Crown className="h-6 w-6 text-red-600" />
            <AlertDescription className="text-red-900">
              <strong className="text-lg">🛡️ Modo Administrador</strong>
              <p className="mt-1">Você está visualizando e gerenciando todas as assinaturas da plataforma.</p>
            </AlertDescription>
          </Alert>
        </motion.div>

        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <StatCard
            title="Total de Assinantes"
            value={stats.total}
            icon={Users}
            gradient="from-blue-500 to-blue-600"
          />
          <StatCard
            title="Assinaturas Ativas"
            value={stats.active}
            icon={CheckCircle}
            gradient="from-emerald-500 to-emerald-600"
            description="Pagamento em dia"
          />
          <StatCard
            title="Pendentes"
            value={stats.pending}
            icon={Clock}
            gradient="from-yellow-500 to-yellow-600"
            description="Aguardando pagamento"
          />
          <StatCard
            title="Canceladas"
            value={stats.cancelled}
            icon={XCircle}
            gradient="from-red-500 to-red-600"
          />
          <StatCard
            title="Receita Mensal"
            value={`R$ ${stats.totalRevenue.toLocaleString('pt-BR')}`}
            icon={DollarSign}
            gradient="from-purple-500 to-purple-600"
          />
        </div>

        {/* Search and Filters */}
        <Card className="border-none shadow-lg mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Buscar por nome ou email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12"
                />
              </div>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="bg-gray-100 h-12">
                  <TabsTrigger value="all">Todas</TabsTrigger>
                  <TabsTrigger value="authorized">Ativas</TabsTrigger>
                  <TabsTrigger value="pending">Pendentes</TabsTrigger>
                  <TabsTrigger value="cancelled">Canceladas</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardContent>
        </Card>

        {/* Subscriptions List */}
        {isLoading ? (
          <Card className="p-12 text-center">
            <Loader2 className="w-12 h-12 text-red-600 mx-auto mb-4 animate-spin" />
            <p className="text-gray-600">Carregando assinaturas...</p>
          </Card>
        ) : filteredSubscriptions.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSubscriptions.map((subscription) => (
              <SubscriptionCard
                key={subscription.id}
                subscription={subscription}
                events={events}
                onEdit={handleManualActivation}
                onCancel={handleCancelSubscription}
              />
            ))}
          </div>
        ) : (
          <Card className="p-16 text-center border-2 border-dashed border-gray-300">
            <Users className="w-20 h-20 text-gray-400 mx-auto mb-4" />
            <h3 className="text-2xl font-semibold text-gray-900 mb-2">
              Nenhuma assinatura encontrada
            </h3>
            <p className="text-gray-600">
              {searchQuery ? 'Tente outro termo de busca' : 'Aguardando primeiros assinantes'}
            </p>
          </Card>
        )}

        {/* Recent Events */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-12"
        >
          <Card className="border-none shadow-xl">
            <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-6 h-6 text-purple-600" />
                Eventos Recentes
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {events.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {events.slice(0, 20).map((event) => (
                    <div key={event.id} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <div className={`p-2 rounded-lg ${
                        event.event_type === 'payment_received' ? 'bg-emerald-500' :
                        event.event_type === 'payment_failed' ? 'bg-red-500' :
                        event.event_type === 'subscription_created' ? 'bg-blue-500' :
                        'bg-gray-500'
                      }`}>
                        {event.event_type === 'payment_received' ? <CheckCircle className="w-5 h-5 text-white" /> :
                         event.event_type === 'payment_failed' ? <XCircle className="w-5 h-5 text-white" /> :
                         event.event_type === 'subscription_created' ? <Crown className="w-5 h-5 text-white" /> :
                         <Clock className="w-5 h-5 text-white" />}
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-sm text-gray-900">{event.user_name}</p>
                        <p className="text-xs text-gray-600">
                          {event.event_type === 'payment_received' ? '💰 Pagamento recebido' :
                           event.event_type === 'payment_failed' ? '❌ Pagamento falhou' :
                           event.event_type === 'subscription_created' ? '🆕 Nova assinatura' :
                           event.event_type === 'subscription_renewed' ? '🔄 Renovada' :
                           event.event_type === 'subscription_cancelled' ? '🚫 Cancelada' :
                           event.event_type}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-gray-900">
                          {event.amount ? `${event.currency} ${event.amount.toLocaleString()}` : '-'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {format(new Date(event.created_date), "dd/MM HH:mm")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Activity className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Nenhum evento registrado ainda</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}