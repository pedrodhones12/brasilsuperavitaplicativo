import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ChartBar, 
  DollarSign,
  TrendingUp,
  FileText,
  Users,
  Target,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle,
  AlertCircle,
  Loader2
} from "lucide-react";
import { motion } from "framer-motion";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

const COLORS = ['#059669', '#0284c7', '#8b5cf6', '#f59e0b'];

const sectorNames = {
  tecnologico: "Tecnológico",
  cultural: "Cultural",
  sustentabilidade: "Sustentabilidade",
  infraestrutura: "Infraestrutura",
  educacao: "Educação",
  saude: "Saúde",
  turismo: "Turismo",
  comercio: "Comércio",
  inovacao: "Inovação"
};

export default function Transparency() {
  const { data: projects = [], isLoading: loadingProjects, error: errorProjects } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list(),
    retry: 2
  });

  const { data: investments = [], isLoading: loadingInvestments, error: errorInvestments } = useQuery({
    queryKey: ['investments'],
    queryFn: () => base44.entities.Investment.list(),
    retry: 2
  });

  const { data: transactions = [], isLoading: loadingTransactions, error: errorTransactions } = useQuery({
    queryKey: ['transactions'],
    queryFn: () => base44.entities.Transaction.list('-created_date'),
    retry: 2
  });

  const isLoading = loadingProjects || loadingInvestments || loadingTransactions;
  const hasError = errorProjects || errorInvestments || errorTransactions;

  // Calculate metrics with safe checks
  const totalInvestments = investments.filter(inv => inv.status === 'confirmado').length;
  const totalAmount = projects.reduce((sum, p) => sum + (p.current_funding || 0), 0);
  const platformFees = transactions
    .filter(t => t.type === 'investimento')
    .reduce((sum, t) => sum + (t.fee_amount || 0), 0);
  const activeProjects = projects.filter(p => p.status === 'ativa').length;
  const completedProjects = projects.filter(p => p.status === 'finalizada').length;

  // Data for charts with safe checks
  const projectsBySector = Object.keys(sectorNames)
    .map(sector => ({
      name: sectorNames[sector],
      value: projects.filter(p => p.sector === sector).length,
      amount: projects.filter(p => p.sector === sector).reduce((sum, p) => sum + (p.current_funding || 0), 0)
    }))
    .filter(item => item.value > 0);

  const topProjects = projects
    .filter(p => (p.current_funding || 0) > 0)
    .sort((a, b) => (b.current_funding || 0) - (a.current_funding || 0))
    .slice(0, 5)
    .map(p => ({
      name: p.title && p.title.length > 20 ? p.title.substring(0, 20) + '...' : (p.title || 'Sem título'),
      value: p.current_funding || 0
    }));

  const recentTransactions = transactions.slice(0, 10);

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/50 to-blue-50/50 flex items-center justify-center">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <Loader2 className="w-16 h-16 text-emerald-600 mx-auto animate-spin" />
            <h2 className="text-2xl font-bold text-gray-900">Carregando dados...</h2>
            <p className="text-gray-600">Aguarde enquanto buscamos as informações</p>
          </div>
        </Card>
      </div>
    );
  }

  if (hasError) {
    return (
      <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/50 to-blue-50/50 flex items-center justify-center">
        <Card className="p-12 max-w-md border-red-200">
          <div className="text-center space-y-4">
            <AlertCircle className="w-16 h-16 text-red-600 mx-auto" />
            <h2 className="text-2xl font-bold text-gray-900">Erro ao carregar</h2>
            <p className="text-gray-600">
              {errorProjects?.message || errorInvestments?.message || errorTransactions?.message || 'Não foi possível carregar os dados'}
            </p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/50 to-blue-50/50">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-3">
            <ChartBar className="w-10 h-10 text-emerald-600" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
              Painel de Transparência
            </h1>
          </div>
          <p className="text-lg text-gray-600">
            Acompanhe em tempo real os investimentos e o impacto da plataforma
          </p>
        </motion.div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="border-none shadow-lg overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-500 to-emerald-600 opacity-5" />
              <CardContent className="p-6 relative">
                <div className="flex justify-between items-start mb-3">
                  <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600">
                    <DollarSign className="w-6 h-6 text-white" />
                  </div>
                  <ArrowUpRight className="w-5 h-5 text-emerald-600" />
                </div>
                <p className="text-sm text-gray-500 mb-1">Volume Total</p>
                <p className="text-3xl font-bold text-gray-900">
                  R$ {totalAmount.toLocaleString('pt-BR')}
                </p>
                <p className="text-xs text-emerald-600 mt-2">Investido na plataforma</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="border-none shadow-lg overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-blue-600 opacity-5" />
              <CardContent className="p-6 relative">
                <div className="flex justify-between items-start mb-3">
                  <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <CheckCircle className="w-5 h-5 text-blue-600" />
                </div>
                <p className="text-sm text-gray-500 mb-1">Projetos Ativos</p>
                <p className="text-3xl font-bold text-gray-900">{activeProjects}</p>
                <p className="text-xs text-blue-600 mt-2">{completedProjects} finalizados</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="border-none shadow-lg overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-purple-600 opacity-5" />
              <CardContent className="p-6 relative">
                <div className="flex justify-between items-start mb-3">
                  <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <ArrowUpRight className="w-5 h-5 text-purple-600" />
                </div>
                <p className="text-sm text-gray-500 mb-1">Total de Investimentos</p>
                <p className="text-3xl font-bold text-gray-900">{totalInvestments}</p>
                <p className="text-xs text-purple-600 mt-2">Confirmados</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="border-none shadow-lg overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-yellow-500 to-yellow-600 opacity-5" />
              <CardContent className="p-6 relative">
                <div className="flex justify-between items-start mb-3">
                  <div className="p-3 rounded-xl bg-gradient-to-br from-yellow-500 to-yellow-600">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <ArrowDownRight className="w-5 h-5 text-gray-400" />
                </div>
                <p className="text-sm text-gray-500 mb-1">Taxas Arrecadadas</p>
                <p className="text-3xl font-bold text-gray-900">
                  R$ {platformFees.toLocaleString('pt-BR')}
                </p>
                <p className="text-xs text-gray-600 mt-2">6,5% do total</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Charts Section */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="border-none shadow-xl">
              <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                <CardTitle>Distribuição por Setor</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {projectsBySector.length > 0 ? (
                  <>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={projectsBySector}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {projectsBySector.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="mt-6 space-y-3">
                      {projectsBySector.map((sector, index) => (
                        <div key={sector.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-4 h-4 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                            <span className="font-medium text-gray-900">{sector.name}</span>
                          </div>
                          <span className="text-sm text-gray-600">
                            R$ {sector.amount.toLocaleString('pt-BR')}
                          </span>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="h-96 flex items-center justify-center text-gray-500">
                    <div className="text-center">
                      <ChartBar className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                      <p>Nenhum projeto por setor ainda</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="border-none shadow-xl">
              <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                <CardTitle>Top 5 Projetos por Investimento</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                {topProjects.length > 0 ? (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={topProjects}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                      <YAxis />
                      <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
                      <Bar dataKey="value" fill="url(#colorGradient)" />
                      <defs>
                        <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#059669" stopOpacity={1} />
                          <stop offset="100%" stopColor="#0284c7" stopOpacity={1} />
                        </linearGradient>
                      </defs>
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-96 flex items-center justify-center text-gray-500">
                    <div className="text-center">
                      <TrendingUp className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                      <p>Nenhum projeto com investimento ainda</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Recent Transactions */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
        >
          <Card className="border-none shadow-xl">
            <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-6 h-6 text-emerald-600" />
                Transações Recentes
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-3">
                {recentTransactions.length > 0 ? (
                  recentTransactions.map((transaction) => (
                    <div 
                      key={transaction.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`p-2 rounded-lg ${
                          transaction.type === 'investimento' 
                            ? 'bg-emerald-100' 
                            : transaction.type === 'saque'
                            ? 'bg-blue-100'
                            : 'bg-gray-100'
                        }`}>
                          {transaction.type === 'investimento' ? (
                            <TrendingUp className="w-5 h-5 text-emerald-600" />
                          ) : transaction.type === 'saque' ? (
                            <ArrowDownRight className="w-5 h-5 text-blue-600" />
                          ) : (
                            <FileText className="w-5 h-5 text-gray-600" />
                          )}
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900">{transaction.description || 'Sem descrição'}</p>
                          <p className="text-sm text-gray-500">{transaction.user_email || 'Sistema'}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-gray-900">
                          R$ {(transaction.amount || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </p>
                        {transaction.fee_amount > 0 && (
                          <p className="text-xs text-gray-500">
                            Taxa: R$ {(transaction.fee_amount || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </p>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <FileText className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                    <p className="text-lg font-semibold mb-2">Nenhuma transação encontrada</p>
                    <p className="text-sm">As transações aparecerão aqui quando houver atividade</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}