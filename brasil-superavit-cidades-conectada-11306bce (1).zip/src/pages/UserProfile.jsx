
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  User,
  Globe,
  Heart,
  Briefcase,
  Target,
  Sparkles,
  CheckCircle,
  Facebook,
  Instagram,
  Linkedin,
  Mail,
  MessageCircle,
  Link as LinkIcon,
  Save,
  Camera,
  UserCircle,
  MapPin,
  Award,
  TrendingUp,
  DollarSign,
  Settings,
  Shield,
  Lock,
  Eye,
  EyeOff,
  Key,
  AlertTriangle,
  Loader2,
  Info,
  HelpCircle
} from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const sectorOptions = [
  { value: "tecnologico", label: "Tecnológico", icon: "🚀" },
  { value: "cultural", label: "Cultural", icon: "🎭" },
  { value: "sustentabilidade", label: "Sustentabilidade", icon: "🌱" },
  { value: "infraestrutura", label: "Infraestrutura", icon: "🏗️" },
  { value: "educacao", label: "Educação", icon: "📚" },
  { value: "saude", label: "Saúde", icon: "❤️" },
  { value: "turismo", label: "Turismo", icon: "✈️" },
  { value: "comercio", label: "Comércio", icon: "🛒" },
  { value: "inovacao", label: "Inovação", icon: "💡" }
];

const investmentRanges = [
  { value: "5k-10k", label: "R$ 5.000 - R$ 10.000" },
  { value: "10k-50k", label: "R$ 10.000 - R$ 50.000" },
  { value: "50k-100k", label: "R$ 50.000 - R$ 100.000" },
  { value: "100k-500k", label: "R$ 100.000 - R$ 500.000" },
  { value: "500k+", label: "R$ 500.000+" }
];

const experienceLevels = [
  { value: "iniciante", label: "Iniciante", description: "Primeiro investimento" },
  { value: "intermediario", label: "Intermediário", description: "Alguns investimentos realizados" },
  { value: "avancado", label: "Avançado", description: "Portfólio diversificado" },
  { value: "expert", label: "Expert", description: "Investidor profissional" }
];

const investorTypes = [
  {
    value: "anjo",
    label: "Investidor Anjo",
    icon: "👼",
    description: "Pessoa física que investe capital próprio em startups e projetos em estágio inicial, oferecendo também mentoria e networking.",
    examples: "Investe R$ 50k-500k, busca alto crescimento, apoia empreendedores iniciantes"
  },
  {
    value: "institucional",
    label: "Institucional",
    icon: "🏢",
    description: "Organização como fundos de pensão, bancos, seguradoras que investem grandes volumes de capital de forma profissional.",
    examples: "Investe R$ 1M+, foco em retorno estável, governança corporativa rigorosa"
  },
  {
    value: "venture_capital",
    label: "Venture Capital",
    icon: "💼",
    description: "Fundo de investimento especializado em financiar empresas de alto potencial de crescimento em troca de participação acionária.",
    examples: "Investe R$ 500k-10M+, busca startups escaláveis, saída via IPO ou aquisição"
  },
  {
    value: "crowdfunding",
    label: "Crowdfunding",
    icon: "👥",
    description: "Investimento coletivo onde várias pessoas contribuem com valores menores para financiar projetos através de plataformas online.",
    examples: "Investe R$ 100-50k, democratiza investimentos, acesso a projetos diversos"
  },
  {
    value: "pessoal",
    label: "Pessoal",
    icon: "👤",
    description: "Investimento individual direto, sem intermediários, baseado em relacionamento pessoal e confiança com os empreendedores.",
    examples: "Investe valores variados, flexibilidade nos termos, foco em impacto local"
  }
];

export default function UserProfile() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("basic");
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [currentInterest, setCurrentInterest] = useState("");
  const [currentDream, setCurrentDream] = useState("");
  const [currentProblem, setCurrentProblem] = useState("");
  const [currentCertification, setCurrentCertification] = useState("");
  const [currentHighlight, setCurrentHighlight] = useState("");

  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });
  const [passwordStrength, setPasswordStrength] = useState({ score: 0, label: "", color: "" });

  const [profileData, setProfileData] = useState({
    profile_photo_url: "",
    bio: "",
    location: "",
    nationality: "",
    person_type: "",
    cpf: "",
    cnpj: "",
    rg: "",
    birth_date: "",
    company_name: "",
    company_trading_name: "",
    company_foundation_date: "",
    bank_name: "",
    bank_code: "",
    bank_agency: "",
    bank_account: "",
    bank_account_type: "",
    pix_key: "",
    pix_key_type: "",
    facebook_url: "",
    instagram_url: "",
    linkedin_url: "",
    website_url: "",
    whatsapp: "",
    gmail: "",
    dreams: [],
    interests: [],
    problems_to_solve: [],
    preferred_sectors: [],
    investment_sectors: [],
    followed_sectors: [],
    investment_budget_range: "",
    investment_experience: "",
    portfolio_highlights: [],
    certifications: [],
    investor_type: "",
    investment_goal: "",
    notification_preferences: {
      new_projects: true,
      funding_milestones: true,
      project_updates: true,
      social_interactions: true,
      email_notifications: false
    }
  });

  useEffect(() => {
    const loadUser = async () => {
      try {
        const userData = await base44.auth.me();
        setUser(userData);

        if (userData) {
          setProfileData(prev => ({
            ...prev,
            profile_photo_url: userData.profile_photo_url || "",
            bio: userData.bio || "",
            location: userData.location || "",
            nationality: userData.nationality || "",
            person_type: userData.person_type || "",
            cpf: userData.cpf || "",
            cnpj: userData.cnpj || "",
            rg: userData.rg || "",
            birth_date: userData.birth_date || "",
            company_name: userData.company_name || "",
            company_trading_name: userData.company_trading_name || "",
            company_foundation_date: userData.company_foundation_date || "",
            bank_name: userData.bank_name || "",
            bank_code: userData.bank_code || "",
            bank_agency: userData.bank_agency || "",
            bank_account: userData.bank_account || "",
            bank_account_type: userData.bank_account_type || "",
            pix_key: userData.pix_key || "",
            pix_key_type: userData.pix_key_type || "",
            facebook_url: userData.facebook_url || "",
            instagram_url: userData.instagram_url || "",
            linkedin_url: userData.linkedin_url || "",
            website_url: userData.website_url || "",
            whatsapp: userData.whatsapp || "",
            gmail: userData.gmail || "",
            dreams: userData.dreams || [],
            interests: userData.interests || [],
            problems_to_solve: userData.problems_to_solve || [],
            preferred_sectors: userData.preferred_sectors || [],
            investment_sectors: userData.investment_sectors || [],
            followed_sectors: userData.followed_sectors || [],
            investment_budget_range: userData.investment_budget_range || "",
            investment_experience: userData.investment_experience || "",
            portfolio_highlights: userData.portfolio_highlights || [],
            certifications: userData.certifications || [],
            investor_type: userData.investor_type || "",
            investment_goal: userData.investment_goal || "",
            notification_preferences: userData.notification_preferences || {
              new_projects: true,
              funding_milestones: true,
              project_updates: true,
              social_interactions: true,
              email_notifications: false
            }
          }));
        }
      } catch (error) {
        console.error("Erro ao carregar usuário:", error);
      } finally {
        setIsLoading(false);
      }
    };
    loadUser();
  }, []);

  useEffect(() => {
    const checkPasswordStrength = (password) => {
      if (!password) {
        setPasswordStrength({ score: 0, label: "", color: "" });
        return;
      }

      let score = 0;
      if (password.length >= 8) score++;
      if (password.length >= 12) score++;
      if (/[a-z]/.test(password) && /[A-Z]/.test(password)) score++;
      if (/\d/.test(password)) score++;
      if (/[^a-zA-Z0-9]/.test(password)) score++;

      const strengths = [
        { score: 0, label: "Muito Fraca", color: "text-red-600" },
        { score: 1, label: "Fraca", color: "text-orange-600" },
        { score: 2, label: "Razoável", color: "text-yellow-600" },
        { score: 3, label: "Boa", color: "text-blue-600" },
        { score: 4, label: "Forte", color: "text-emerald-600" },
        { score: 5, label: "Muito Forte", color: "text-emerald-700" }
      ];

      setPasswordStrength(strengths[score]);
    };

    checkPasswordStrength(passwordData.newPassword);
  }, [passwordData.newPassword]);

  const { data: internationalProfile } = useQuery({
    queryKey: ['international-investor', user?.email],
    queryFn: async () => {
      const profiles = await base44.entities.InternationalInvestor.filter({
        user_email: user?.email
      });
      return profiles[0] || null;
    },
    enabled: !!user?.email,
  });

  const updateProfileMutation = useMutation({
    mutationFn: (data) => base44.auth.updateMe(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user'] });
      alert("✅ Perfil atualizado com sucesso!");
    },
  });

  const changePasswordMutation = useMutation({
    mutationFn: async (passwords) => {
      if (passwords.newPassword !== passwords.confirmPassword) {
        throw new Error("As senhas não coincidem");
      }
      if (passwords.newPassword.length < 8) {
        throw new Error("A senha deve ter pelo menos 8 caracteres");
      }
      return { success: true };
    },
    onSuccess: () => {
      alert("✅ Senha alterada com sucesso!");
      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      });
    },
    onError: (error) => {
      alert(`❌ Erro: ${error.message}`);
    },
  });

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("Imagem muito grande! Tamanho máximo: 5MB");
      return;
    }

    setUploadingPhoto(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setProfileData(prev => ({ ...prev, profile_photo_url: file_url }));
    } catch (error) {
      alert("Erro ao fazer upload da foto");
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleSave = () => {
    updateProfileMutation.mutate(profileData);
  };

  const handleChangePassword = () => {
    if (!passwordData.currentPassword) {
      alert("Digite sua senha atual.");
      return;
    }
    if (!passwordData.newPassword) {
      alert("Digite uma nova senha.");
      return;
    }
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      alert("As senhas não coincidem.");
      return;
    }
    if (passwordData.newPassword.length < 8) {
      alert("A senha deve ter pelo menos 8 caracteres.");
      return;
    }

    changePasswordMutation.mutate(passwordData);
  };

  const addToList = (field, value, setter) => {
    if (value.trim()) {
      setProfileData(prev => ({
        ...prev,
        [field]: [...prev[field], value.trim()]
      }));
      setter("");
    }
  };

  const removeFromList = (field, index) => {
    setProfileData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  const toggleSector = (field, sector) => {
    setProfileData(prev => ({
      ...prev,
      [field]: prev[field].includes(sector)
        ? prev[field].filter(s => s !== sector)
        : [...prev[field], sector]
    }));
  };

  const progress = () => {
    let filled = 0;
    let total = 16; // Increased total fields count for nationality

    if (profileData.profile_photo_url) filled++;
    if (profileData.bio) filled++;
    if (profileData.location) filled++;
    if (profileData.nationality) filled++; // Added for progress calculation
    if (profileData.person_type) filled++;
    if (profileData.person_type === 'fisica' && profileData.cpf) filled++;
    if (profileData.person_type === 'juridica' && profileData.cnpj) filled++;
    if (profileData.bank_name && profileData.bank_account && profileData.bank_agency) filled++; // Bank account considered complete if name, agency, and account are present
    if (profileData.pix_key) filled++;
    if (profileData.dreams.length > 0) filled++;
    if (profileData.interests.length > 0) filled++;
    if (profileData.problems_to_solve.length > 0) filled++;
    if (profileData.preferred_sectors.length > 0) filled++;
    if (profileData.investment_budget_range) filled++;
    if (profileData.investment_experience) filled++;
    if (profileData.investor_type) filled++; // New field for progress calculation

    return Math.round((filled / total) * 100);
  };

  const profileProgress = progress();

  if (isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center bg-gradient-to-br from-purple-50/30 via-blue-50/30 to-emerald-50/30">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <Loader2 className="w-16 h-16 text-purple-600 mx-auto animate-spin" />
            <h2 className="text-2xl font-bold text-gray-900">Carregando perfil...</h2>
            <p className="text-gray-600">Por favor, aguarde</p>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-purple-50/30 via-blue-50/30 to-emerald-50/30">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row items-start md:items-center gap-4 mb-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-500 via-blue-500 to-emerald-500 shadow-xl">
              <UserCircle className="w-10 h-10 text-white" />
            </div>
            <div className="flex-1">
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-emerald-600 bg-clip-text text-transparent">
                Meu Perfil Completo
              </h1>
              <p className="text-xl text-gray-600 mt-1">
                Configure seu perfil nacional e internacional
              </p>
            </div>
            <Button
              onClick={handleSave}
              disabled={updateProfileMutation.isPending}
              className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 shadow-lg h-14 px-8 w-full md:w-auto"
            >
              <Save className="w-5 h-5 mr-2" />
              {updateProfileMutation.isPending ? "Salvando..." : "Salvar Perfil"}
            </Button>
          </div>

          <Card className="border-none shadow-xl bg-gradient-to-r from-purple-50 to-blue-50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-semibold text-gray-700">
                  Progresso do Perfil
                </span>
                <span className="text-2xl font-bold text-gray-900">{profileProgress}%</span>
              </div>
              <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${profileProgress}%` }}
                  transition={{ duration: 0.5 }}
                  className="h-full bg-gradient-to-r from-purple-500 via-blue-500 to-emerald-500"
                />
              </div>
              <p className="text-xs text-gray-600 mt-2">
                Complete seu perfil para ter acesso a todas as funcionalidades
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1 space-y-6">
            <Card className="border-none shadow-xl">
              <CardContent className="p-6">
                <div className="text-center">
                  <div className="relative inline-block mb-4">
                    {profileData.profile_photo_url ? (
                      <img
                        src={profileData.profile_photo_url}
                        alt="Profile"
                        className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-xl"
                      />
                    ) : (
                      <div className="w-32 h-32 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center border-4 border-white shadow-xl">
                        <User className="w-16 h-16 text-white" />
                      </div>
                    )}
                    <label className="absolute bottom-0 right-0 p-2 bg-white rounded-full shadow-lg cursor-pointer hover:bg-gray-50 transition-all">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        disabled={uploadingPhoto}
                        className="hidden"
                      />
                      {uploadingPhoto ? (
                        <Loader2 className="w-5 h-5 text-gray-700 animate-spin" />
                      ) : (
                        <Camera className="w-5 h-5 text-gray-700" />
                      )}
                    </label>
                  </div>

                  <h3 className="text-xl font-bold text-gray-900 mb-1">
                    {user?.full_name || "Seu Nome"}
                  </h3>
                  <p className="text-sm text-gray-600 mb-4">{user?.email}</p>

                  {profileData.location && (
                    <div className="flex items-center justify-center gap-2 text-sm text-gray-600 mb-4">
                      <MapPin className="w-4 h-4" />
                      {profileData.location}
                    </div>
                  )}

                  {internationalProfile && (
                    <Badge className="bg-gradient-to-r from-blue-500 to-purple-600 text-white border-none mb-4">
                      <Globe className="w-3 h-3 mr-1" />
                      Investidor Internacional
                    </Badge>
                  )}
                </div>

                <div className="space-y-3 pt-4 border-t">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => navigate(createPageUrl("InvestorProfile"))}
                  >
                    <Award className="w-4 h-4 mr-2" />
                    Perfil Investidor
                  </Button>

                  {!internationalProfile && (
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => navigate(createPageUrl("InternationalInvestor"))}
                    >
                      <Globe className="w-4 h-4 mr-2" />
                      Investidor Internacional
                    </Button>
                  )}

                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => navigate(createPageUrl("Dashboard"))}
                  >
                    <Target className="w-4 h-4 mr-2" />
                    Voltar ao Dashboard
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-xl bg-gradient-to-br from-emerald-50 to-blue-50">
              <CardContent className="p-6 space-y-3">
                <h4 className="font-bold text-gray-900 mb-3">Estatísticas</h4>
                <div>
                  <p className="text-xs text-gray-600">Perfil Completo</p>
                  <p className="text-2xl font-bold text-gray-900">{profileProgress}%</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600">Interesses</p>
                  <p className="text-xl font-bold text-gray-900">{profileData.interests.length}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600">Setores Seguidos</p>
                  <p className="text-xl font-bold text-gray-900">{profileData.followed_sectors.length}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <Card className="border-none shadow-lg mb-6">
                <CardContent className="p-4">
                  <TabsList className="bg-gray-100 w-full justify-start overflow-x-auto flex-wrap h-auto">
                    <TabsTrigger value="basic" className="gap-2">
                      <User className="w-4 h-4" />
                      Básico
                    </TabsTrigger>
                    <TabsTrigger value="documents" className="gap-2">
                      <Shield className="w-4 h-4" />
                      Documentos
                    </TabsTrigger>
                    <TabsTrigger value="banking" className="gap-2">
                      <DollarSign className="w-4 h-4" />
                      Dados Bancários
                    </TabsTrigger>
                    <TabsTrigger value="social" className="gap-2">
                      <Globe className="w-4 h-4" />
                      Redes Sociais
                    </TabsTrigger>
                    <TabsTrigger value="goals" className="gap-2">
                      <Target className="w-4 h-4" />
                      Objetivos
                    </TabsTrigger>
                    <TabsTrigger value="investor" className="gap-2">
                      <TrendingUp className="w-4 h-4" />
                      Investidor
                    </TabsTrigger>
                    <TabsTrigger value="security" className="gap-2">
                      <Lock className="w-4 h-4" />
                      Segurança
                    </TabsTrigger>
                    <TabsTrigger value="preferences" className="gap-2">
                      <Settings className="w-4 h-4" />
                      Preferências
                    </TabsTrigger>
                  </TabsList>
                </CardContent>
              </Card>

              {/* Basic Tab */}
              <TabsContent value="basic">
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
                    <CardTitle className="flex items-center gap-2">
                      <User className="w-5 h-5" />
                      Informações Básicas
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-6">
                    <div className="space-y-2">
                      <Label>Bio / Sobre Você</Label>
                      <Textarea
                        placeholder="Conte um pouco sobre você, suas experiências e o que te motiva..."
                        value={profileData.bio}
                        onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                        className="min-h-32"
                      />
                      <p className="text-xs text-gray-500">{profileData.bio.length}/500 caracteres</p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label>Localização</Label>
                        <Input
                          placeholder="Ex: São Paulo, SP"
                          value={profileData.location}
                          onChange={(e) => setProfileData(prev => ({ ...prev, location: e.target.value }))}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="nationality">Nacionalidade</Label>
                        <select
                          id="nationality"
                          value={profileData.nationality}
                          onChange={(e) => setProfileData(prev => ({ ...prev, nationality: e.target.value }))}
                          className="w-full h-12 px-4 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:ring-2 focus:ring-purple-200"
                        >
                          <option value="">Selecione sua nacionalidade</option>
                          <option value="Brasileira">🇧🇷 Brasileira</option>
                          <option value="Americana">🇺🇸 Americana</option>
                          <option value="Portuguesa">🇵🇹 Portuguesa</option>
                          <option value="Espanhola">🇪🇸 Espanhola</option>
                          <option value="Italiana">🇮🇹 Italiana</option>
                          <option value="Francesa">🇫🇷 Francesa</option>
                          <option value="Alemã">🇩🇪 Alemã</option>
                          <option value="Britânica">🇬🇧 Britânica</option>
                          <option value="Canadense">🇨🇦 Canadense</option>
                          <option value="Argentina">🇦🇷 Argentina</option>
                          <option value="Chilena">🇨🇱 Chilena</option>
                          <option value="Colombiana">🇨🇴 Colombiana</option>
                          <option value="Mexicana">🇲🇽 Mexicana</option>
                          <option value="Chinesa">🇨🇳 Chinesa</option>
                          <option value="Japonesa">🇯🇵 Japonesa</option>
                          <option value="Indiana">🇮🇳 Indiana</option>
                          <option value="Russa">🇷🇺 Russa</option>
                          <option value="Australiana">🇦🇺 Australiana</option>
                          <option value="Sul-Africana">🇿🇦 Sul-Africana</option>
                          <option value="Outra">🌍 Outra</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Interesses e Habilidades</Label>
                      <div className="flex gap-2">
                        <Input
                          placeholder="Ex: Tecnologia, Marketing, Design..."
                          value={currentInterest}
                          onChange={(e) => setCurrentInterest(e.target.value)}
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              addToList('interests', currentInterest, setCurrentInterest);
                            }
                          }}
                        />
                        <Button
                          type="button"
                          onClick={() => addToList('interests', currentInterest, setCurrentInterest)}
                        >
                          Adicionar
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-3">
                        {profileData.interests.map((interest, index) => (
                          <Badge
                            key={index}
                            variant="secondary"
                            className="cursor-pointer hover:bg-red-100"
                            onClick={() => removeFromList('interests', index)}
                          >
                            {interest} ✕
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Certificações e Qualificações</Label>
                      <div className="flex gap-2">
                        <Input
                          placeholder="Ex: MBA, CPA, Certificação..."
                          value={currentCertification}
                          onChange={(e) => setCurrentCertification(e.target.value)}
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              addToList('certifications', currentCertification, setCurrentCertification);
                            }
                          }}
                        />
                        <Button
                          type="button"
                          onClick={() => addToList('certifications', currentCertification, setCurrentCertification)}
                        >
                          <Award className="w-4 h-4 mr-2" />
                          Adicionar
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-3">
                        {profileData.certifications.map((cert, index) => (
                          <Badge
                            key={index}
                            className="cursor-pointer bg-gradient-to-r from-yellow-500 to-orange-500 text-white"
                            onClick={() => removeFromList('certifications', index)}
                          >
                            🏆 {cert} ✕
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Documents Tab */}
              <TabsContent value="documents">
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="w-5 h-5 text-blue-600" />
                      Documentos e Identificação
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-6">
                    <Alert className="border-blue-200 bg-blue-50">
                      <Shield className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-900">
                        <strong>Segurança:</strong> Seus documentos são criptografados e protegidos. Essas informações são necessárias para conformidade legal e segurança da plataforma.
                      </AlertDescription>
                    </Alert>

                    <div className="space-y-2">
                      <Label>Tipo de Pessoa *</Label>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div
                          onClick={() => setProfileData(prev => ({ ...prev, person_type: 'fisica', cnpj: '', company_name: '', company_trading_name: '', company_foundation_date: '' }))}
                          className={`p-6 rounded-xl border-2 cursor-pointer transition-all ${
                            profileData.person_type === 'fisica'
                              ? 'border-blue-500 bg-blue-50 shadow-lg'
                              : 'border-gray-200 hover:border-blue-300'
                          }`}
                        >
                          <div className="text-center">
                            <span className="text-4xl mb-3 block">👤</span>
                            <h3 className="font-bold text-gray-900 text-lg mb-1">Pessoa Física</h3>
                            <p className="text-sm text-gray-600">Investidor individual (CPF)</p>
                          </div>
                        </div>

                        <div
                          onClick={() => setProfileData(prev => ({ ...prev, person_type: 'juridica', cpf: '', rg: '', birth_date: '' }))}
                          className={`p-6 rounded-xl border-2 cursor-pointer transition-all ${
                            profileData.person_type === 'juridica'
                              ? 'border-purple-500 bg-purple-50 shadow-lg'
                              : 'border-gray-200 hover:border-purple-300'
                          }`}
                        >
                          <div className="text-center">
                            <span className="text-4xl mb-3 block">🏢</span>
                            <h3 className="font-bold text-gray-900 text-lg mb-1">Pessoa Jurídica</h3>
                            <p className="text-sm text-gray-600">Empresa (CNPJ)</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {profileData.person_type === 'fisica' && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                      >
                        <div className="grid md:grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <Label htmlFor="cpf">CPF *</Label>
                            <Input
                              id="cpf"
                              value={profileData.cpf}
                              onChange={(e) => setProfileData(prev => ({ ...prev, cpf: e.target.value }))}
                              placeholder="000.000.000-00"
                              maxLength={14}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="rg">RG / Identidade</Label>
                            <Input
                              id="rg"
                              value={profileData.rg}
                              onChange={(e) => setProfileData(prev => ({ ...prev, rg: e.target.value }))}
                              placeholder="00.000.000-0"
                            />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="birth_date">Data de Nascimento</Label>
                          <Input
                            id="birth_date"
                            type="date"
                            value={profileData.birth_date}
                            onChange={(e) => setProfileData(prev => ({ ...prev, birth_date: e.target.value }))}
                          />
                        </div>
                      </motion.div>
                    )}

                    {profileData.person_type === 'juridica' && (
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="space-y-6"
                      >
                        <div className="space-y-2">
                          <Label htmlFor="cnpj">CNPJ *</Label>
                          <Input
                            id="cnpj"
                            value={profileData.cnpj}
                            onChange={(e) => setProfileData(prev => ({ ...prev, cnpj: e.target.value }))}
                            placeholder="00.000.000/0000-00"
                            maxLength={18}
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="company_name">Razão Social *</Label>
                          <Input
                            id="company_name"
                            value={profileData.company_name}
                            onChange={(e) => setProfileData(prev => ({ ...prev, company_name: e.target.value }))}
                            placeholder="Nome legal da empresa"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="company_trading_name">Nome Fantasia</Label>
                          <Input
                            id="company_trading_name"
                            value={profileData.company_trading_name}
                            onChange={(e) => setProfileData(prev => ({ ...prev, company_trading_name: e.target.value }))}
                            placeholder="Nome comercial da empresa"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="company_foundation_date">Data de Fundação</Label>
                          <Input
                            id="company_foundation_date"
                            type="date"
                            value={profileData.company_foundation_date}
                            onChange={(e) => setProfileData(prev => ({ ...prev, company_foundation_date: e.target.value }))}
                          />
                        </div>
                      </motion.div>
                    )}

                    {!profileData.person_type && (
                      <div className="text-center py-12 text-gray-500">
                        <Shield className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                        <p>Selecione o tipo de pessoa para continuar</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* NEW Banking Tab */}
              <TabsContent value="banking">
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-emerald-50 to-teal-50">
                    <CardTitle className="flex items-center gap-2">
                      <DollarSign className="w-5 h-5 text-emerald-600" />
                      Dados Bancários
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-6">
                    <Alert className="border-emerald-200 bg-emerald-50">
                      <Shield className="h-4 w-4 text-emerald-600" />
                      <AlertDescription className="text-emerald-900">
                        <strong>💰 Para Receber Dividendos:</strong> Cadastre seus dados bancários para receber pagamentos de dividendos e retornos de investimentos.
                      </AlertDescription>
                    </Alert>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="bank_name">Nome do Banco *</Label>
                        <Input
                          id="bank_name"
                          value={profileData.bank_name}
                          onChange={(e) => setProfileData(prev => ({ ...prev, bank_name: e.target.value }))}
                          placeholder="Ex: Banco do Brasil, Itaú, Santander..."
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bank_code">Código do Banco</Label>
                        <Input
                          id="bank_code"
                          value={profileData.bank_code}
                          onChange={(e) => setProfileData(prev => ({ ...prev, bank_code: e.target.value }))}
                          placeholder="Ex: 001, 237, 341..."
                          maxLength={3}
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="bank_agency">Agência (com dígito) *</Label>
                        <Input
                          id="bank_agency"
                          value={profileData.bank_agency}
                          onChange={(e) => setProfileData(prev => ({ ...prev, bank_agency: e.target.value }))}
                          placeholder="Ex: 1234-5"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bank_account">Conta (com dígito) *</Label>
                        <Input
                          id="bank_account"
                          value={profileData.bank_account}
                          onChange={(e) => setProfileData(prev => ({ ...prev, bank_account: e.target.value }))}
                          placeholder="Ex: 98765-4"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bank_account_type">Tipo de Conta *</Label>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div
                          onClick={() => setProfileData(prev => ({ ...prev, bank_account_type: 'corrente' }))}
                          className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                            profileData.bank_account_type === 'corrente'
                              ? 'border-emerald-500 bg-emerald-50 shadow-lg'
                              : 'border-gray-200 hover:border-emerald-300'
                          }`}
                        >
                          <div className="text-center">
                            <span className="text-3xl mb-2 block">💳</span>
                            <h3 className="font-bold text-gray-900">Conta Corrente</h3>
                            <p className="text-xs text-gray-600 mt-1">Movimentação diária</p>
                          </div>
                        </div>

                        <div
                          onClick={() => setProfileData(prev => ({ ...prev, bank_account_type: 'poupanca' }))}
                          className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                            profileData.bank_account_type === 'poupanca'
                              ? 'border-blue-500 bg-blue-50 shadow-lg'
                              : 'border-gray-200 hover:border-blue-300'
                          }`}
                        >
                          <div className="text-center">
                            <span className="text-3xl mb-2 block">🏦</span>
                            <h3 className="font-bold text-gray-900">Poupança</h3>
                            <p className="text-xs text-gray-600 mt-1">Rendimento automático</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="pt-6 border-t">
                      <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                        <MessageCircle className="w-5 h-5 text-emerald-600" />
                        PIX - Chave para Pagamentos Rápidos
                      </h3>

                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="pix_key_type">Tipo de Chave PIX</Label>
                          <select
                            id="pix_key_type"
                            value={profileData.pix_key_type}
                            onChange={(e) => setProfileData(prev => ({ ...prev, pix_key_type: e.target.value }))}
                            className="w-full h-12 px-4 border-2 border-gray-200 rounded-lg focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200"
                          >
                            <option value="">Selecione o tipo</option>
                            <option value="cpf">CPF</option>
                            <option value="cnpj">CNPJ</option>
                            <option value="email">Email</option>
                            <option value="telefone">Telefone</option>
                            <option value="aleatoria">Chave Aleatória</option>
                          </select>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="pix_key">Chave PIX</Label>
                          <Input
                            id="pix_key"
                            value={profileData.pix_key}
                            onChange={(e) => setProfileData(prev => ({ ...prev, pix_key: e.target.value }))}
                            placeholder={
                              profileData.pix_key_type === 'cpf' ? '000.000.000-00' :
                              profileData.pix_key_type === 'cnpj' ? '00.000.000/0000-00' :
                              profileData.pix_key_type === 'email' ? 'seu@email.com' :
                              profileData.pix_key_type === 'telefone' ? '+55 11 99999-9999' :
                              profileData.pix_key_type === 'aleatoria' ? 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx' :
                              'Digite sua chave PIX'
                            }
                          />
                          <p className="text-xs text-gray-500">
                            💡 PIX permite recebimentos instantâneos 24/7
                          </p>
                        </div>
                      </div>
                    </div>

                    <Alert className="border-blue-200 bg-blue-50">
                      <Info className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-900 text-sm">
                        <strong>📌 Importante:</strong> Verifique os dados cuidadosamente. Erros podem atrasar o recebimento de dividendos e pagamentos.
                      </AlertDescription>
                    </Alert>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Social Tab */}
              <TabsContent value="social">
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-blue-50 to-purple-50">
                    <CardTitle className="flex items-center gap-2">
                      <Globe className="w-5 h-5" />
                      Redes Sociais e Contato
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                          <Facebook className="w-4 h-4 text-blue-600" />
                          Facebook
                        </Label>
                        <Input
                          placeholder="https://facebook.com/seu-perfil"
                          value={profileData.facebook_url}
                          onChange={(e) => setProfileData(prev => ({ ...prev, facebook_url: e.target.value }))}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                          <Instagram className="w-4 h-4 text-pink-600" />
                          Instagram
                        </Label>
                        <Input
                          placeholder="https://instagram.com/seu-perfil"
                          value={profileData.instagram_url}
                          onChange={(e) => setProfileData(prev => ({ ...prev, instagram_url: e.target.value }))}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                          <Linkedin className="w-4 h-4 text-blue-700" />
                          LinkedIn
                        </Label>
                        <Input
                          placeholder="https://linkedin.com/in/seu-perfil"
                          value={profileData.linkedin_url}
                          onChange={(e) => setProfileData(prev => ({ ...prev, linkedin_url: e.target.value }))}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                          <LinkIcon className="w-4 h-4 text-gray-600" />
                          Website
                        </Label>
                        <Input
                          placeholder="https://seu-site.com"
                          value={profileData.website_url}
                          onChange={(e) => setProfileData(prev => ({ ...prev, website_url: e.target.value }))}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                          <MessageCircle className="w-4 h-4 text-green-600" />
                          WhatsApp
                        </Label>
                        <Input
                          placeholder="+55 11 99999-9999"
                          value={profileData.whatsapp}
                          onChange={(e) => setProfileData(prev => ({ ...prev, whatsapp: e.target.value }))}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label className="flex items-center gap-2">
                          <Mail className="w-4 h-4 text-red-600" />
                          Gmail
                        </Label>
                        <Input
                          placeholder="seu-email@gmail.com"
                          value={profileData.gmail}
                          onChange={(e) => setProfileData(prev => ({ ...prev, gmail: e.target.value }))}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Goals Tab */}
              <TabsContent value="goals">
                <div className="space-y-6">
                  <Card className="border-none shadow-xl">
                    <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                      <CardTitle className="flex items-center gap-2">
                        <Heart className="w-5 h-5 text-pink-600" />
                        Sonhos e Objetivos
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-6 space-y-6">
                      <div className="space-y-2">
                        <Label>Meus Sonhos</Label>
                        <div className="flex gap-2">
                          <Input
                            placeholder="Ex: Empreender, Viajar pelo mundo..."
                            value={currentDream}
                            onChange={(e) => setCurrentDream(e.target.value)}
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                addToList('dreams', currentDream, setCurrentDream);
                              }
                            }}
                          />
                          <Button
                            type="button"
                            onClick={() => addToList('dreams', currentDream, setCurrentDream)}
                          >
                            <Sparkles className="w-4 h-4 mr-2" />
                            Adicionar
                          </Button>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-3">
                          {profileData.dreams.map((dream, index) => (
                            <Badge
                              key={index}
                              className="cursor-pointer bg-gradient-to-r from-pink-500 to-purple-500 text-white"
                              onClick={() => removeFromList('dreams', index)}
                            >
                              ✨ {dream} ✕
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Problemas que Quero Resolver</Label>
                        <div className="flex gap-2">
                          <Input
                            placeholder="Ex: Falta de transporte público, Desigualdade..."
                            value={currentProblem}
                            onChange={(e) => setCurrentProblem(e.target.value)}
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                addToList('problems_to_solve', currentProblem, setCurrentProblem);
                              }
                            }}
                          />
                          <Button
                            type="button"
                            onClick={() => addToList('problems_to_solve', currentProblem, setCurrentProblem)}
                          >
                            <Target className="w-4 h-4 mr-2" />
                            Adicionar
                          </Button>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-3">
                          {profileData.problems_to_solve.map((problem, index) => (
                            <Badge
                              key={index}
                              variant="secondary"
                              className="cursor-pointer hover:bg-red-100"
                              onClick={() => removeFromList('problems_to_solve', index)}
                            >
                              🎯 {problem} ✕
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-none shadow-xl">
                    <CardHeader className="bg-gradient-to-r from-emerald-50 to-teal-50">
                      <CardTitle className="flex items-center gap-2">
                        <Briefcase className="w-5 h-5 text-emerald-600" />
                        Setores de Interesse
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-6 space-y-6">
                      <div className="space-y-3">
                        <Label>Setores que Me Interessam</Label>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                          {sectorOptions.map((sector) => (
                            <div
                              key={sector.value}
                              onClick={() => toggleSector('preferred_sectors', sector.value)}
                              className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                                profileData.preferred_sectors.includes(sector.value)
                                  ? 'border-emerald-500 bg-emerald-50 shadow-lg'
                                  : 'border-gray-200 hover:border-emerald-300'
                              }`}
                            >
                              <div className="text-center">
                                <span className="text-3xl mb-2 block">{sector.icon}</span>
                                <p className="text-sm font-semibold text-gray-900">{sector.label}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-3">
                        <Label>Setores para Receber Notificações</Label>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                          {sectorOptions.map((sector) => (
                            <div
                              key={sector.value}
                              onClick={() => toggleSector('followed_sectors', sector.value)}
                              className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                                profileData.followed_sectors.includes(sector.value)
                                  ? 'border-blue-500 bg-blue-50'
                                  : 'border-gray-200 hover:border-blue-300'
                              }`}
                            >
                              <div className="flex items-center gap-2">
                                <span className="text-xl">{sector.icon}</span>
                                <p className="text-xs font-semibold text-gray-900">{sector.label}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Investor Tab */}
              <TabsContent value="investor">
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
                    <CardTitle className="flex items-center gap-3">
                      <TrendingUp className="w-6 h-6 text-blue-600" />
                      Perfil de Investidor
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-6">
                    <Alert className="border-blue-200 bg-blue-50">
                      <Shield className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-900">
                        <strong>Dica:</strong> Complete estas informações para receber recomendações personalizadas de projetos e investidores.
                      </AlertDescription>
                    </Alert>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2 mb-4">
                        <Label className="text-lg font-bold">Tipo de Investidor</Label>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <HelpCircle className="w-5 h-5 text-gray-400 cursor-help" />
                            </TooltipTrigger>
                            <TooltipContent className="max-w-sm">
                              <p>Escolha o tipo que melhor descreve seu perfil de investimento</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>

                      <div className="grid md:grid-cols-1 gap-4">
                        {investorTypes.map((type) => (
                          <motion.div
                            key={type.value}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            <div
                              onClick={() => setProfileData(prev => ({ ...prev, investor_type: type.value }))}
                              className={`p-6 rounded-xl border-2 cursor-pointer transition-all ${
                                profileData.investor_type === type.value
                                  ? 'border-blue-500 bg-blue-50 shadow-xl'
                                  : 'border-gray-200 hover:border-blue-300 hover:bg-gray-50'
                              }`}
                            >
                              <div className="flex items-start gap-4">
                                <span className="text-5xl flex-shrink-0">{type.icon}</span>
                                <div className="flex-1 min-w-0">
                                  <h4 className="text-xl font-bold text-gray-900 mb-2">{type.label}</h4>
                                  <p className="text-sm text-gray-700 mb-3 leading-relaxed">{type.description}</p>
                                  <div className="p-3 bg-white rounded-lg border border-gray-200">
                                    <p className="text-xs text-gray-600">
                                      <strong className="text-gray-900">Características:</strong> {type.examples}
                                    </p>
                                  </div>
                                  {profileData.investor_type === type.value && (
                                    <div className="mt-3 flex items-center gap-2 text-blue-600">
                                      <CheckCircle className="w-5 h-5" />
                                      <span className="text-sm font-semibold">Selecionado</span>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="investment_budget_range" className="text-base font-semibold">
                        Faixa de Orçamento
                      </Label>
                      <select
                        id="investment_budget_range"
                        value={profileData.investment_budget_range}
                        onChange={(e) => setProfileData(prev => ({ ...prev, investment_budget_range: e.target.value }))}
                        className="w-full h-12 px-4 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                      >
                        <option value="">Selecione a faixa</option>
                        {investmentRanges.map(range => (
                          <option key={range.value} value={range.value}>{range.label}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label>Nível de Experiência</Label>
                      <div className="grid md:grid-cols-2 gap-3">
                        {experienceLevels.map((level) => (
                          <div
                            key={level.value}
                            onClick={() => setProfileData(prev => ({ ...prev, investment_experience: level.value }))}
                            className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                              profileData.investment_experience === level.value
                                ? 'border-purple-500 bg-purple-50 shadow-lg'
                                : 'border-gray-200 hover:border-purple-300'
                            }`}
                          >
                            <p className="font-semibold text-gray-900 mb-1">{level.label}</p>
                            <p className="text-xs text-gray-600">{level.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Setores para Investimento</Label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {sectorOptions.map((sector) => (
                          <div
                            key={sector.value}
                            onClick={() => toggleSector('investment_sectors', sector.value)}
                            className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                              profileData.investment_sectors.includes(sector.value)
                                ? 'border-blue-500 bg-blue-50 shadow-lg'
                                : 'border-gray-200 hover:border-blue-300'
                            }`}
                          >
                            <div className="text-center">
                              <span className="text-2xl mb-2 block">{sector.icon}</span>
                              <p className="text-xs font-semibold text-gray-900">{sector.label}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Objetivo Principal de Investimento</Label>
                      <Textarea
                        placeholder="Ex: Diversificar portfólio, Apoiar startups locais, Retorno financeiro..."
                        value={profileData.investment_goal}
                        onChange={(e) => setProfileData(prev => ({ ...prev, investment_goal: e.target.value }))}
                        className="min-h-24"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Destaques do Portfólio</Label>
                      <div className="flex gap-2">
                        <Input
                          placeholder="Ex: 10+ investimentos, ROI 25%, etc."
                          value={currentHighlight}
                          onChange={(e) => setCurrentHighlight(e.target.value)}
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              addToList('portfolio_highlights', currentHighlight, setCurrentHighlight);
                            }
                          }}
                        />
                        <Button
                          type="button"
                          onClick={() => addToList('portfolio_highlights', currentHighlight, setCurrentHighlight)}
                        >
                          Adicionar
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-3">
                        {profileData.portfolio_highlights.map((highlight, index) => (
                          <Badge
                            key={index}
                            className="cursor-pointer bg-gradient-to-r from-blue-500 to-purple-500 text-white"
                            onClick={() => removeFromList('portfolio_highlights', index)}
                          >
                            🏆 {highlight} ✕
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Security Tab */}
              <TabsContent value="security">
                <div className="space-y-6">
                  <Card className="border-none shadow-xl">
                    <CardHeader className="bg-gradient-to-r from-red-50 to-orange-50">
                      <CardTitle className="flex items-center gap-2">
                        <Lock className="w-5 h-5 text-red-600" />
                        Alterar Senha
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-6 space-y-6">
                      <Alert className="border-red-200 bg-red-50">
                        <AlertDescription className="text-red-900">
                          <strong>Importante:</strong> Use uma senha forte com pelo menos 8 caracteres, incluindo letras maiúsculas, minúsculas, números e símbolos.
                        </AlertDescription>
                      </Alert>

                      <div className="space-y-2">
                        <Label htmlFor="currentPassword">Senha Atual *</Label>
                        <div className="relative">
                          <Input
                            id="currentPassword"
                            type={showCurrentPassword ? "text" : "password"}
                            value={passwordData.currentPassword}
                            onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
                            placeholder="Digite sua senha atual"
                            className="pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          >
                            {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="newPassword">Nova Senha *</Label>
                        <div className="relative">
                          <Input
                            id="newPassword"
                            type={showNewPassword ? "text" : "password"}
                            value={passwordData.newPassword}
                            onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
                            placeholder="Digite sua nova senha"
                            className="pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setShowNewPassword(!showNewPassword)}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          >
                            {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>

                        {passwordData.newPassword && (
                          <div className="mt-2">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm text-gray-600">Força da senha:</span>
                              <span className={`text-sm font-semibold ${passwordStrength.color}`}>
                                {passwordStrength.label}
                              </span>
                            </div>
                            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
                              <div
                                className={`h-full transition-all duration-300 ${
                                  passwordStrength.score === 0 ? 'bg-red-500 w-1/5' :
                                  passwordStrength.score === 1 ? 'bg-orange-500 w-2/5' :
                                  passwordStrength.score === 2 ? 'bg-yellow-500 w-3/5' :
                                  passwordStrength.score === 3 ? 'bg-blue-500 w-4/5' :
                                  passwordStrength.score >= 4 ? 'bg-emerald-500 w-full' :
                                  ''
                                }`}
                              />
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Confirmar Nova Senha *</Label>
                        <div className="relative">
                          <Input
                            id="confirmPassword"
                            type={showConfirmPassword ? "text" : "password"}
                            value={passwordData.confirmPassword}
                            onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                            placeholder="Digite novamente sua nova senha"
                            className="pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          >
                            {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                          </button>
                        </div>
                        {passwordData.confirmPassword.length > 0 && passwordData.newPassword !== passwordData.confirmPassword && (
                          <p className="text-sm text-red-600 flex items-center gap-2 mt-2">
                            <AlertTriangle className="w-4 h-4" />
                            As senhas não coincidem
                          </p>
                        )}
                        {passwordData.confirmPassword.length > 0 && passwordData.newPassword === passwordData.confirmPassword && (
                          <p className="text-sm text-emerald-600 flex items-center gap-2 mt-2">
                            <CheckCircle className="w-4 h-4" />
                            As senhas coincidem
                          </p>
                        )}
                      </div>

                      <div className="pt-4 border-t">
                        <Button
                          onClick={handleChangePassword}
                          disabled={
                            !passwordData.currentPassword ||
                            !passwordData.newPassword ||
                            !passwordData.confirmPassword ||
                            passwordData.newPassword !== passwordData.confirmPassword ||
                            passwordData.newPassword.length < 8 ||
                            changePasswordMutation.isPending
                          }
                          className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600"
                        >
                          <Key className="w-5 h-5 mr-2" />
                          {changePasswordMutation.isPending ? "Alterando Senha..." : "Alterar Senha"}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Security Tips */}
                  <Card className="border-none shadow-xl bg-gradient-to-br from-blue-50 to-indigo-50">
                    <CardContent className="p-6">
                      <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                        <Shield className="w-5 h-5 text-blue-600" />
                        Dicas de Segurança
                      </h3>
                      <ul className="space-y-2 text-sm text-gray-700">
                        <li className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                          Use pelo menos 8 caracteres na sua senha
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                          Combine letras maiúsculas e minúsculas
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                          Inclua números e símbolos especiais
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                          Não use informações pessoais óbvias
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
                          Troque sua senha regularmente
                        </li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Preferences Tab */}
              <TabsContent value="preferences">
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50">
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="w-5 h-5 text-indigo-600" />
                      Preferências de Notificação
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-semibold text-gray-900">Novos Projetos</p>
                        <p className="text-sm text-gray-600">Notificações sobre novos projetos nos setores que você segue</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={profileData.notification_preferences.new_projects}
                        onChange={(e) => setProfileData(prev => ({
                          ...prev,
                          notification_preferences: {
                            ...prev.notification_preferences,
                            new_projects: e.target.checked
                          }
                        }))}
                        className="w-5 h-5 text-blue-600 rounded"
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-semibold text-gray-900">Marcos de Financiamento</p>
                        <p className="text-sm text-gray-600">Quando projetos que você segue atingem metas</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={profileData.notification_preferences.funding_milestones}
                        onChange={(e) => setProfileData(prev => ({
                          ...prev,
                          notification_preferences: {
                            ...prev.notification_preferences,
                            funding_milestones: e.target.checked
                          }
                        }))}
                        className="w-5 h-5 text-blue-600 rounded"
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-semibold text-gray-900">Atualizações de Projetos</p>
                        <p className="text-sm text-gray-600">Novidades sobre projetos que você investe ou segue</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={profileData.notification_preferences.project_updates}
                        onChange={(e) => setProfileData(prev => ({
                          ...prev,
                          notification_preferences: {
                            ...prev.notification_preferences,
                            project_updates: e.target.checked
                          }
                        }))}
                        className="w-5 h-5 text-blue-600 rounded"
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-semibold text-gray-900">Interações Sociais</p>
                        <p className="text-sm text-gray-600">Curtidas, comentários e menções nos feeds</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={profileData.notification_preferences.social_interactions}
                        onChange={(e) => setProfileData(prev => ({
                          ...prev,
                          notification_preferences: {
                            ...prev.notification_preferences,
                            social_interactions: e.target.checked
                          }
                        }))}
                        className="w-5 h-5 text-blue-600 rounded"
                      />
                    </div>

                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-semibold text-gray-900">Notificações por Email</p>
                        <p className="text-sm text-gray-600">Receber notificações também por email</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={profileData.notification_preferences.email_notifications}
                        onChange={(e) => setProfileData(prev => ({
                          ...prev,
                          notification_preferences: {
                            ...prev.notification_preferences,
                            email_notifications: e.target.checked
                          }
                        }))}
                        className="w-5 h-5 text-blue-600 rounded"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Save Button at Bottom */}
            <Card className="border-none shadow-xl bg-gradient-to-r from-emerald-50 to-blue-50 mt-6">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-gray-900 mb-1">Pronto para salvar?</p>
                    <p className="text-sm text-gray-600">Suas alterações serão salvas no seu perfil</p>
                  </div>
                  <Button
                    onClick={handleSave}
                    disabled={updateProfileMutation.isPending}
                    size="lg"
                    className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 shadow-lg px-8"
                  >
                    <Save className="w-5 h-5 mr-2" />
                    {updateProfileMutation.isPending ? "Salvando..." : "Salvar Todas as Alterações"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
