import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  CheckCircle, 
  XCircle, 
  Clock,
  Loader2,
  ArrowRight,
  AlertTriangle,
  DollarSign,
  Receipt
} from "lucide-react";
import { motion } from "framer-motion";

export default function PaymentCallback() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  const investmentId = searchParams.get("investment_id");
  const status = searchParams.get("status"); // success, failure, pending
  const paymentId = searchParams.get("payment_id");
  const merchantOrderId = searchParams.get("merchant_order_id");

  const [investment, setInvestment] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    const loadInvestment = async () => {
      try {
        const investments = await base44.entities.Investment.filter({ id: investmentId });
        if (investments.length > 0) {
          setInvestment(investments[0]);
          
          // Update investment status based on payment status
          if (status === "success") {
            await updateInvestmentStatus("confirmado", "aprovado");
          } else if (status === "failure") {
            await updateInvestmentStatus("cancelado", "rejeitado");
          } else if (status === "pending") {
            await updateInvestmentStatus("processando", "processando");
          }
        }
      } catch (error) {
        console.error("Error loading investment:", error);
      } finally {
        setIsLoading(false);
      }
    };

    if (investmentId) {
      loadInvestment();
    }
  }, [investmentId, status]);

  const updateInvestmentStatus = async (investmentStatus, paymentStatus) => {
    setIsUpdating(true);
    try {
      // Update investment
      await base44.entities.Investment.update(investmentId, {
        status: investmentStatus,
        payment_status: paymentStatus,
        transaction_id: paymentId || investment?.transaction_id
      });

      // Update transaction
      if (investment?.project_id) {
        const transactions = await base44.entities.Transaction.filter({
          project_id: investment.project_id,
          user_email: investment.investor_email,
          type: "investimento"
        });
        
        if (transactions.length > 0) {
          const transaction = transactions[transactions.length - 1]; // Get most recent
          await base44.entities.Transaction.update(transaction.id, {
            status: investmentStatus === "confirmado" ? "concluida" : investmentStatus === "cancelado" ? "falhou" : "processando"
          });
        }

        // If payment is successful, update project funding
        if (investmentStatus === "confirmado") {
          const projects = await base44.entities.Project.filter({ id: investment.project_id });
          if (projects.length > 0) {
            const project = projects[0];
            const newFunding = (project.current_funding || 0) + investment.amount;
            const newInvestors = (project.investors_count || 0) + 1;
            
            await base44.entities.Project.update(project.id, {
              current_funding: newFunding,
              investors_count: newInvestors
            });
          }
        }
      }
    } catch (error) {
      console.error("Error updating investment status:", error);
    } finally {
      setIsUpdating(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <Loader2 className="w-16 h-16 text-blue-600 mx-auto animate-spin" />
            <h2 className="text-2xl font-bold text-gray-900">Processando pagamento...</h2>
            <p className="text-gray-600">Aguarde enquanto verificamos seu pagamento</p>
          </div>
        </Card>
      </div>
    );
  }

  const statusConfig = {
    success: {
      icon: CheckCircle,
      color: "text-emerald-600",
      bgColor: "from-emerald-50 to-green-50",
      borderColor: "border-emerald-200",
      title: "🎉 Pagamento Aprovado!",
      message: "Seu investimento foi confirmado com sucesso.",
      details: "O projeto receberá os fundos e você já é oficialmente um investidor!",
      action: "Ver Meus Investimentos",
      actionUrl: "MyInvestments"
    },
    failure: {
      icon: XCircle,
      color: "text-red-600",
      bgColor: "from-red-50 to-pink-50",
      borderColor: "border-red-200",
      title: "❌ Pagamento Recusado",
      message: "Não foi possível processar seu pagamento.",
      details: "Verifique seus dados de pagamento e tente novamente. Nenhuma cobrança foi realizada.",
      action: "Tentar Novamente",
      actionUrl: "Invest"
    },
    pending: {
      icon: Clock,
      color: "text-yellow-600",
      bgColor: "from-yellow-50 to-orange-50",
      borderColor: "border-yellow-200",
      title: "⏳ Pagamento Pendente",
      message: "Seu pagamento está sendo processado.",
      details: "Isso pode levar alguns minutos. Você receberá uma notificação quando o pagamento for confirmado.",
      action: "Acompanhar Investimentos",
      actionUrl: "MyInvestments"
    }
  };

  const config = statusConfig[status] || statusConfig.pending;
  const StatusIcon = config.icon;

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Card className={`border-2 ${config.borderColor} shadow-2xl overflow-hidden`}>
            <div className={`h-3 bg-gradient-to-r ${config.bgColor}`} />
            <CardContent className="p-12">
              <div className="text-center space-y-6">
                <div className={`inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br ${config.bgColor} border-2 ${config.borderColor}`}>
                  <StatusIcon className={`w-12 h-12 ${config.color}`} />
                </div>

                <div>
                  <h1 className="text-4xl font-bold text-gray-900 mb-3">
                    {config.title}
                  </h1>
                  <p className="text-xl text-gray-700 mb-2">
                    {config.message}
                  </p>
                  <p className="text-gray-600">
                    {config.details}
                  </p>
                </div>

                {investment && (
                  <div className="p-6 bg-gray-50 rounded-xl border border-gray-200">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Detalhes do Investimento</h3>
                    <div className="space-y-3 text-left">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Projeto:</span>
                        <span className="font-semibold text-gray-900">{investment.project_title}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Valor:</span>
                        <span className="font-bold text-emerald-600 text-lg">
                          R$ {investment.amount?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Categoria:</span>
                        <span className="font-semibold text-gray-900 capitalize">{investment.category}</span>
                      </div>
                      {investment.equity_percentage > 0 && (
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600">Participação:</span>
                          <span className="font-semibold text-purple-600">
                            {investment.equity_percentage?.toFixed(3)}%
                          </span>
                        </div>
                      )}
                      {paymentId && (
                        <div className="flex justify-between items-center pt-3 border-t border-gray-300">
                          <span className="text-gray-600 text-sm">ID do Pagamento:</span>
                          <span className="font-mono text-xs text-gray-500">{paymentId}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                <Alert className={`border-2 ${config.borderColor} bg-gradient-to-r ${config.bgColor}`}>
                  <AlertTriangle className={`h-5 w-5 ${config.color}`} />
                  <AlertDescription className="text-gray-900">
                    {status === "success" && (
                      <>
                        <strong>Próximos passos:</strong> Você receberá um email com o recibo e os detalhes do investimento. 
                        Acompanhe o progresso do projeto em "Meus Investimentos".
                      </>
                    )}
                    {status === "failure" && (
                      <>
                        <strong>Dica:</strong> Verifique se há saldo suficiente, se os dados do cartão estão corretos, 
                        ou tente outro método de pagamento.
                      </>
                    )}
                    {status === "pending" && (
                      <>
                        <strong>Importante:</strong> Mantenha esta página aberta ou salve o número do investimento. 
                        Você pode acompanhar o status em "Meus Investimentos".
                      </>
                    )}
                  </AlertDescription>
                </Alert>

                <div className="flex gap-4 justify-center pt-4">
                  <Button
                    onClick={() => navigate(createPageUrl(config.actionUrl))}
                    size="lg"
                    className={`${
                      status === "success" 
                        ? "bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600" 
                        : status === "failure"
                        ? "bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600"
                        : "bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                    } text-white px-8`}
                  >
                    {config.action}
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                  
                  {status !== "failure" && (
                    <Button
                      onClick={() => navigate(createPageUrl("Dashboard"))}
                      variant="outline"
                      size="lg"
                    >
                      Ir para Dashboard
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Additional Help Section */}
          <Card className="mt-6 border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-lg bg-blue-50">
                  <Receipt className="w-6 h-6 text-blue-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-2">Precisa de Ajuda?</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    Se você tiver dúvidas sobre seu investimento ou pagamento, nossa equipe está pronta para ajudar.
                  </p>
                  <Button variant="outline" size="sm">
                    Entrar em Contato com Suporte
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}