import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  FileText, 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  Users, 
  DollarSign,
  Scale,
  Ban,
  UserX,
  Mail,
  Gavel
} from "lucide-react";
import { motion } from "framer-motion";

const SectionCard = ({ icon: Icon, title, children, color = "blue" }) => {
  const colors = {
    blue: "from-blue-500 to-blue-600",
    emerald: "from-emerald-500 to-emerald-600",
    purple: "from-purple-500 to-purple-600",
    orange: "from-orange-500 to-orange-600",
    red: "from-red-500 to-red-600",
    yellow: "from-yellow-500 to-yellow-600"
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-none shadow-lg mb-6">
        <CardHeader className="bg-gradient-to-r from-gray-50 to-blue-50">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-xl bg-gradient-to-br ${colors[color]} shadow-lg`}>
              <Icon className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-xl font-bold text-gray-900">{title}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {children}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50/30 p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-xl">
              <FileText className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Termos de Serviço
              </h1>
              <p className="text-gray-600 mt-1">Brasil Superávit: Cidades Conectadas</p>
            </div>
          </div>
          
          <Alert className="border-blue-200 bg-blue-50">
            <CheckCircle className="h-5 w-5 text-blue-600" />
            <AlertDescription className="text-blue-900">
              <strong>Última atualização:</strong> 18 de novembro de 2025
              <br />
              Ao utilizar nossa plataforma, você concorda com estes termos. Leia atentamente antes de prosseguir.
            </AlertDescription>
          </Alert>
        </motion.div>

        {/* Introduction */}
        <SectionCard icon={FileText} title="1. Aceitação dos Termos" color="blue">
          <div className="prose prose-blue max-w-none">
            <p className="text-gray-700 mb-4">
              Bem-vindo à <strong>Brasil Superávit: Cidades Conectadas</strong>. Estes Termos de Serviço ("Termos") regem o uso de nossa plataforma de conexão entre empreendedores, investidores e cidades.
            </p>
            <p className="text-gray-700 mb-4">
              Ao criar uma conta, acessar ou utilizar nossos serviços, você concorda em cumprir e estar vinculado a estes Termos, nossa Política de Privacidade e todas as leis e regulamentações aplicáveis.
            </p>
            <p className="text-gray-700">
              Se você não concordar com qualquer parte destes Termos, não utilize nossos serviços.
            </p>
          </div>
        </SectionCard>

        {/* Platform Description */}
        <SectionCard icon={Users} title="2. Descrição da Plataforma" color="emerald">
          <div className="space-y-4">
            <p className="text-gray-700 mb-4">
              A Brasil Superávit é uma plataforma que oferece:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                <span><strong>Criação de projetos:</strong> Empreendedores podem apresentar ideias e buscar investimento</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                <span><strong>Oportunidades de investimento:</strong> Investidores podem apoiar projetos e receber retorno financeiro</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                <span><strong>Rede social:</strong> Conexão entre usuários, compartilhamento de conteúdo e networking</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                <span><strong>Educação:</strong> Tutoriais e recursos para empreendedores e investidores</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                <span><strong>Proteção legal:</strong> Ferramentas para registro e proteção de propriedade intelectual</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                <span><strong>Reuniões virtuais:</strong> Ferramentas de comunicação com IA integrada</span>
              </li>
            </ul>
          </div>
        </SectionCard>

        {/* User Accounts */}
        <SectionCard icon={Users} title="3. Contas de Usuário" color="purple">
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-gray-900 mb-3">3.1. Registro</h3>
            <ul className="space-y-2 text-gray-700 mb-4">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>Você deve ter pelo menos 18 anos para criar uma conta</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>As informações fornecidas devem ser precisas, completas e atualizadas</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>Você é responsável por manter a confidencialidade de sua senha</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>Notifique-nos imediatamente sobre qualquer uso não autorizado de sua conta</span>
              </li>
            </ul>

            <h3 className="text-lg font-bold text-gray-900 mb-3">3.2. Responsabilidades do Usuário</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span>Você é responsável por todas as atividades realizadas através de sua conta</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span>Não compartilhe suas credenciais de acesso com terceiros</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span>Você concorda em não criar múltiplas contas para abusar da plataforma</span>
              </li>
            </ul>
          </div>
        </SectionCard>

        {/* Fees and Payments */}
        <SectionCard icon={DollarSign} title="4. Taxas e Pagamentos" color="yellow">
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-gray-900 mb-3">4.1. Plano Freemium</h3>
            <p className="text-gray-700 mb-4">
              A plataforma oferece funcionalidades gratuitas e premium:
            </p>
            <ul className="space-y-2 text-gray-700 mb-4">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                <span><strong>Gratuito:</strong> Visualização de projetos, criação de rascunhos, acesso a tutoriais</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <span><strong>Premium:</strong> Publicação de projetos, investimentos, interações sociais (curtir/comentar)</span>
              </li>
            </ul>

            <h3 className="text-lg font-bold text-gray-900 mb-3">4.2. Taxa da Plataforma</h3>
            <div className="bg-yellow-50 p-4 rounded-lg border-2 border-yellow-200">
              <p className="text-yellow-900 font-semibold mb-2">
                A Brasil Superávit cobra uma taxa de <strong>3% sobre investimentos bem-sucedidos</strong>:
              </p>
              <ul className="space-y-2 text-yellow-800">
                <li>• A taxa é deduzida automaticamente no momento da transação</li>
                <li>• Não há taxas para projetos que não recebem investimento</li>
                <li>• Taxas de gateway de pagamento (Mercado Pago/Stripe) são adicionais</li>
              </ul>
            </div>

            <h3 className="text-lg font-bold text-gray-900 mb-3 mt-4">4.3. Assinatura Premium</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <DollarSign className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <span>Planos mensais e anuais disponíveis em BRL, USD e EUR</span>
              </li>
              <li className="flex items-start gap-2">
                <DollarSign className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <span>Renovação automática, cancelável a qualquer momento</span>
              </li>
              <li className="flex items-start gap-2">
                <DollarSign className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                <span>Sem reembolso após o período de teste de 7 dias</span>
              </li>
            </ul>
          </div>
        </SectionCard>

        {/* Investment Terms */}
        <SectionCard icon={Scale} title="5. Termos de Investimento" color="blue">
          <div className="space-y-4">
            <Alert className="border-red-300 bg-red-50 mb-4">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              <AlertDescription className="text-red-900">
                <strong>AVISO IMPORTANTE:</strong> Investimentos envolvem riscos. Você pode perder parte ou todo o capital investido. 
                Leia cuidadosamente todos os documentos do projeto antes de investir.
              </AlertDescription>
            </Alert>

            <h3 className="text-lg font-bold text-gray-900 mb-3">5.1. Responsabilidade do Investidor</h3>
            <ul className="space-y-2 text-gray-700 mb-4">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <span>Você é responsável por avaliar os riscos de cada investimento</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <span>Investimento mínimo: R$ 5.000,00 por projeto</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <span>Todos os investimentos são vinculados a contratos digitais</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <span>A plataforma não garante retorno financeiro</span>
              </li>
            </ul>

            <h3 className="text-lg font-bold text-gray-900 mb-3">5.2. Responsabilidade do Empreendedor</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>Todas as informações do projeto devem ser verídicas e completas</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>Você deve cumprir os termos acordados com os investidores</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>É sua responsabilidade manter os investidores informados sobre o progresso</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>Fraude ou informações falsas resultarão em banimento permanente</span>
              </li>
            </ul>

            <h3 className="text-lg font-bold text-gray-900 mb-3 mt-4">5.3. Papel da Plataforma</h3>
            <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
              <p className="text-blue-900 mb-2">
                A Brasil Superávit atua como <strong>intermediadora</strong> entre empreendedores e investidores:
              </p>
              <ul className="space-y-2 text-blue-800">
                <li>• Não somos responsáveis pelo sucesso ou fracasso dos projetos</li>
                <li>• Não participamos ativamente da gestão dos projetos</li>
                <li>• Facilitamos a comunicação e transações financeiras</li>
                <li>• Não oferecemos consultoria financeira ou jurídica</li>
              </ul>
            </div>
          </div>
        </SectionCard>

        {/* Prohibited Activities */}
        <SectionCard icon={Ban} title="6. Atividades Proibidas" color="red">
          <div className="space-y-4">
            <p className="text-gray-700 mb-4">
              É expressamente proibido:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <Ban className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Publicar conteúdo falso, enganoso ou fraudulento</span>
              </li>
              <li className="flex items-start gap-2">
                <Ban className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Usar a plataforma para atividades ilegais ou lavagem de dinheiro</span>
              </li>
              <li className="flex items-start gap-2">
                <Ban className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Assediar, ameaçar ou intimidar outros usuários</span>
              </li>
              <li className="flex items-start gap-2">
                <Ban className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Violar direitos de propriedade intelectual de terceiros</span>
              </li>
              <li className="flex items-start gap-2">
                <Ban className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Tentar acessar contas de outros usuários sem autorização</span>
              </li>
              <li className="flex items-start gap-2">
                <Ban className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Manipular ou interferir no funcionamento da plataforma</span>
              </li>
              <li className="flex items-start gap-2">
                <Ban className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Publicar spam, malware ou conteúdo prejudicial</span>
              </li>
              <li className="flex items-start gap-2">
                <Ban className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Criar projetos de pirâmide financeira ou esquemas fraudulentos</span>
              </li>
            </ul>
          </div>
        </SectionCard>

        {/* Intellectual Property */}
        <SectionCard icon={Shield} title="7. Propriedade Intelectual" color="purple">
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-gray-900 mb-3">7.1. Conteúdo da Plataforma</h3>
            <p className="text-gray-700 mb-4">
              Todo conteúdo da plataforma (design, código, logotipos, textos) é propriedade da Brasil Superávit e está protegido por direitos autorais.
            </p>

            <h3 className="text-lg font-bold text-gray-900 mb-3">7.2. Conteúdo do Usuário</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>Você mantém todos os direitos sobre o conteúdo que publica</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>Ao publicar, você nos concede licença para exibir e promover seu conteúdo na plataforma</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span>Você garante que possui direitos para publicar todo o conteúdo enviado</span>
              </li>
            </ul>
          </div>
        </SectionCard>

        {/* Account Termination */}
        <SectionCard icon={UserX} title="8. Suspensão e Encerramento de Conta" color="orange">
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-gray-900 mb-3">8.1. Encerramento por Você</h3>
            <p className="text-gray-700 mb-4">
              Você pode encerrar sua conta a qualquer momento através das configurações de perfil ou entrando em contato conosco.
            </p>

            <h3 className="text-lg font-bold text-gray-900 mb-3">8.2. Suspensão pela Plataforma</h3>
            <p className="text-gray-700 mb-4">
              Reservamo-nos o direito de suspender ou encerrar sua conta imediatamente, sem aviso prévio, se:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span>Você violar qualquer disposição destes Termos</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span>Houver suspeita de fraude ou atividade ilegal</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span>Você fornecer informações falsas</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span>Houver reclamações repetidas de outros usuários</span>
              </li>
            </ul>
          </div>
        </SectionCard>

        {/* Disclaimers */}
        <SectionCard icon={AlertTriangle} title="9. Isenções de Responsabilidade" color="red">
          <div className="space-y-4">
            <Alert className="border-red-300 bg-red-50 mb-4">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              <AlertDescription className="text-red-900">
                <strong>AVISO LEGAL:</strong> A plataforma é fornecida "como está" sem garantias de qualquer tipo.
              </AlertDescription>
            </Alert>

            <ul className="space-y-3 text-gray-700">
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Não garantimos que a plataforma estará sempre disponível ou livre de erros</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Não somos responsáveis por perdas financeiras resultantes de investimentos</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Não verificamos a veracidade de todas as informações publicadas por usuários</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Não somos responsáveis por disputas entre usuários</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span>Não oferecemos consultoria jurídica, financeira ou de investimento</span>
              </li>
            </ul>
          </div>
        </SectionCard>

        {/* Limitation of Liability */}
        <SectionCard icon={Scale} title="10. Limitação de Responsabilidade" color="blue">
          <div className="prose prose-blue max-w-none">
            <p className="text-gray-700 mb-4">
              Na máxima extensão permitida por lei, a Brasil Superávit não será responsável por:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li>• Danos indiretos, incidentais, especiais ou consequenciais</li>
              <li>• Perda de lucros, receita, dados ou uso</li>
              <li>• Danos resultantes de acesso não autorizado ou alteração de transmissões/dados</li>
              <li>• Declarações ou condutas de terceiros na plataforma</li>
              <li>• Qualquer outro assunto relacionado ao serviço</li>
            </ul>
            <p className="text-gray-700 mt-4">
              Nossa responsabilidade total não excederá o valor pago por você nos últimos 12 meses.
            </p>
          </div>
        </SectionCard>

        {/* Governing Law */}
        <SectionCard icon={Gavel} title="11. Lei Aplicável e Jurisdição" color="purple">
          <div className="prose prose-purple max-w-none">
            <p className="text-gray-700 mb-4">
              Estes Termos são regidos pelas leis da <strong>República Federativa do Brasil</strong>.
            </p>
            <p className="text-gray-700 mb-4">
              Qualquer disputa relacionada a estes Termos será submetida à jurisdição exclusiva dos tribunais do <strong>Estado de São Paulo, Brasil</strong>.
            </p>
            <p className="text-gray-700">
              Para investidores internacionais, aplicam-se as convenções internacionais relevantes e acordos bilaterais entre o Brasil e seu país de origem.
            </p>
          </div>
        </SectionCard>

        {/* Changes to Terms */}
        <SectionCard icon={FileText} title="12. Alterações nos Termos" color="orange">
          <div className="prose prose-orange max-w-none">
            <p className="text-gray-700 mb-4">
              Reservamo-nos o direito de modificar estes Termos a qualquer momento. Quando fizermos alterações significativas:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li>• Notificaremos você por e-mail ou através de um aviso na plataforma</li>
              <li>• As alterações entrarão em vigor 30 dias após a notificação</li>
              <li>• O uso continuado da plataforma após as alterações constitui aceitação dos novos termos</li>
              <li>• Se não concordar com as alterações, você deve encerrar sua conta</li>
            </ul>
          </div>
        </SectionCard>

        {/* Contact */}
        <SectionCard icon={Mail} title="13. Contato" color="emerald">
          <div className="prose prose-emerald max-w-none">
            <p className="text-gray-700 mb-4">
              Para questões relacionadas a estes Termos de Serviço, entre em contato:
            </p>
            <div className="bg-emerald-50 p-6 rounded-xl border-2 border-emerald-200">
              <h3 className="text-lg font-bold text-emerald-900 mb-4">Brasil Superávit: Cidades Conectadas</h3>
              <ul className="space-y-2 text-emerald-900">
                <li className="flex items-center gap-2">
                  <Mail className="w-5 h-5 text-emerald-600" />
                  <span><strong>Suporte:</strong> suporte@brasilsuperavit.com.br</span>
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-5 h-5 text-emerald-600" />
                  <span><strong>Jurídico:</strong> juridico@brasilsuperavit.com.br</span>
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-5 h-5 text-emerald-600" />
                  <span><strong>Investimentos:</strong> investimentos@brasilsuperavit.com.br</span>
                </li>
              </ul>
            </div>
          </div>
        </SectionCard>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-8"
        >
          <Alert className="border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
            <FileText className="h-5 w-5 text-blue-600" />
            <AlertDescription className="text-gray-900">
              <strong>Ao usar a Brasil Superávit, você concorda com estes Termos de Serviço e nossa Política de Privacidade.</strong>
              <br />
              Estes documentos formam um acordo legal vinculante entre você e a Brasil Superávit.
            </AlertDescription>
          </Alert>
        </motion.div>
      </div>
    </div>
  );
}