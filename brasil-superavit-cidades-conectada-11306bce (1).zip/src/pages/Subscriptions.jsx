import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  CreditCard, 
  CheckCircle, 
  Star, 
  Zap, 
  Shield,
  Globe,
  TrendingUp,
  Users,
  Sparkles,
  Crown,
  DollarSign,
  Info,
  Lock,
  Gift,
  Clock,
  Percent,
  Check,
  Loader2,
  AlertTriangle,
  ExternalLink,
  ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

// ✅ FUNÇÃO PARA VERIFICAR SE É ADMIN
const isAdminUser = (email) => {
  const adminEmails = ['pedrodhones15@gmail.com', 'pedrodhones15.com'];
  return adminEmails.some(adminEmail => email?.toLowerCase().includes(adminEmail.toLowerCase()));
};

const SUBSCRIPTION_PLANS = {
  monthly: {
    BRL: { amount: 50.00, symbol: "R$", period: "mês" },
    USD: { amount: 9.30, symbol: "$", period: "month" },
    EUR: { amount: 8.50, symbol: "€", period: "month" }
  },
  yearly: {
    BRL: { amount: 528.00, symbol: "R$", period: "ano", monthlyEquivalent: 44.00, discount: 12 },
    USD: { amount: 99.00, symbol: "$", period: "year", monthlyEquivalent: 8.25, discount: 11 },
    EUR: { amount: 91.00, symbol: "€", period: "year", monthlyEquivalent: 7.58, discount: 11 }
  }
};

const CURRENCY_COUNTRIES = {
  BRL: { name: "BRL", country: "Brasil", flag: "🇧🇷" },
  USD: { name: "USD", country: "Internacional", flag: "🌎" },
  EUR: { name: "EUR", country: "Europa", flag: "🇪🇺" }
};

const FREE_TRIAL_DAYS = 7;

const BENEFITS = [
  { icon: Zap, text: "Acesso prioritário a novos projetos", color: "text-yellow-600", bgColor: "bg-yellow-50" },
  { icon: TrendingUp, text: "Dashboard de análise avançado", color: "text-blue-600", bgColor: "bg-blue-50" },
  { icon: Shield, text: "Proteção legal premium", color: "text-emerald-600", bgColor: "bg-emerald-50" },
  { icon: Users, text: "Networking exclusivo", color: "text-purple-600", bgColor: "bg-purple-50" },
  { icon: Sparkles, text: "IA para recomendações", color: "text-pink-600", bgColor: "bg-pink-50" },
  { icon: Crown, text: "Badge de membro premium", color: "text-amber-600", bgColor: "bg-amber-50" },
  { icon: Globe, text: "Feed internacional", color: "text-cyan-600", bgColor: "bg-cyan-50" },
  { icon: Star, text: "Suporte 24/7", color: "text-orange-600", bgColor: "bg-orange-50" }
];

const detectUserCurrency = (userLocation, userNationality) => {
  const location = (userLocation || userNationality || "").toLowerCase();
  
  if (location.includes('brasil') || location.includes('brazil')) return 'BRL';
  if (location.includes('europa') || location.includes('europe') || 
      location.includes('portugal') || location.includes('espanha') || 
      location.includes('italia') || location.includes('frança')) return 'EUR';
  
  return 'USD';
};

export default function Subscriptions() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCurrency, setSelectedCurrency] = useState('USD');
  const [selectedPlan, setSelectedPlan] = useState('yearly');
  const [isCreatingCheckout, setIsCreatingCheckout] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const isAuthenticated = await base44.auth.isAuthenticated();
        
        if (!isAuthenticated) {
          base44.auth.redirectToLogin(window.location.pathname);
          return;
        }

        const userData = await base44.auth.me();
        setUser(userData);

        // ✅ VERIFICAR SE É ADMIN
        const adminStatus = isAdminUser(userData.email);
        setIsAdmin(adminStatus);
        
        const detectedCurrency = detectUserCurrency(userData.location, userData.nationality);
        setSelectedCurrency(detectedCurrency);
        
        setIsLoading(false);
      } catch (error) {
        console.error("Auth error:", error);
        base44.auth.redirectToLogin(window.location.pathname);
      }
    };
    loadUser();
  }, []);

  const { data: subscription } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: async () => {
      const subs = await base44.entities.Subscription.filter({ 
        user_email: user?.email 
      });
      return subs[0] || null;
    },
    enabled: !!user?.email
  });

  const handleSubscribe = async () => {
    setIsCreatingCheckout(true);
    
    try {
      const currentPrice = SUBSCRIPTION_PLANS[selectedPlan][selectedCurrency];
      
      // Create subscription record
      const subscriptionData = {
        user_email: user.email,
        user_name: user.full_name,
        status: 'pending',
        amount: currentPrice.amount,
        currency: selectedCurrency,
        plan_id: `${selectedPlan}_${selectedCurrency}`,
        billing_day: new Date().getDate(),
        start_date: new Date().toISOString().split('T')[0],
        payment_method: selectedCurrency === 'BRL' ? 'mercado_pago' : 'stripe',
        external_reference: `sub_${user.email}_${Date.now()}`
      };

      await base44.entities.Subscription.create(subscriptionData);

      // ✅ CHECKOUT URLS - TODOS OS PLANOS CONFIGURADOS
      const checkoutUrls = {
        BRL: {
          monthly: 'https://www.mercadopago.com.br/subscriptions/checkout?preapproval_plan_id=fb263d64f49e482eb78febde348fe651',
          yearly: 'https://www.mercadopago.com.br/subscriptions/checkout?preapproval_plan_id=6e1f161c134e4d138d06e20989b290bb'
        },
        USD: {
          monthly: 'https://buy.stripe.com/dRm3cvg3Hc3zbrzgoBcs800',
          yearly: 'https://buy.stripe.com/3cIcN56t7ffLdzHb4hcs801'
        },
        EUR: {
          monthly: null,
          yearly: null
        }
      };

      const checkoutUrl = checkoutUrls[selectedCurrency]?.[selectedPlan];

      if (!checkoutUrl) {
        toast.error(`⚠️ Plano ${selectedPlan === 'monthly' ? 'Mensal' : 'Anual'} ${selectedCurrency} ainda não está disponível!`);
        
        if (selectedCurrency === 'EUR') {
          toast.info(`💡 No momento, apenas planos BRL (Brasil) e USD (Internacional) estão disponíveis. Planos EUR estão sendo configurados!`, {
            duration: 5000
          });
        } else {
          toast.error("Erro interno. Entre em contato com o suporte.");
        }
        
        setIsCreatingCheckout(false);
        return;
      }

      // Add external reference to URL (for tracking)
      const separator = checkoutUrl.includes('?') ? '&' : '?';
      const finalUrl = selectedCurrency === 'BRL' 
        ? `${checkoutUrl}&external_reference=${subscriptionData.external_reference}&payer_email=${user.email}`
        : `${checkoutUrl}${separator}client_reference_id=${subscriptionData.external_reference}`;
      
      toast.success(`🚀 Redirecionando para ${selectedCurrency === 'BRL' ? 'Mercado Pago' : 'Stripe'}...`);
      
      setTimeout(() => {
        window.location.href = finalUrl;
      }, 1000);

    } catch (error) {
      console.error("Error creating checkout:", error);
      toast.error("Erro ao criar checkout. Tente novamente ou entre em contato com o suporte.");
      setIsCreatingCheckout(false);
    }
  };

  const hasActiveSubscription = subscription && (subscription.status === 'authorized' || subscription.status === 'pending');

  // ✅ ADMIN tem acesso direto sem assinatura - mostrar badge especial
  if (isAdmin && !isLoading) {
    return (
      <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-purple-50/50 via-blue-50/50 to-emerald-50/50">
        <div className="max-w-4xl mx-auto">
          <Card className="border-2 border-red-500 shadow-2xl">
            <div className="h-3 bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500" />
            <CardContent className="p-12 text-center">
              <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-red-500 to-orange-500 mb-6">
                <Crown className="w-16 h-16 text-white" />
              </div>
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                🛡️ Acesso de Administrador
              </h2>
              <p className="text-xl text-gray-600 mb-6">
                Você é o <strong>proprietário da plataforma</strong> e tem acesso completo a todas as funcionalidades sem necessidade de assinatura.
              </p>
              <div className="grid md:grid-cols-2 gap-4 max-w-2xl mx-auto mb-8">
                <div className="p-4 bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl border-2 border-emerald-300">
                  <CheckCircle className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                  <p className="font-bold text-gray-900">Acesso Total</p>
                  <p className="text-sm text-gray-600">Todas as funcionalidades liberadas</p>
                </div>
                <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border-2 border-blue-300">
                  <Shield className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <p className="font-bold text-gray-900">Privilégios de Admin</p>
                  <p className="text-sm text-gray-600">Controle total da plataforma</p>
                </div>
              </div>
              <Badge className="bg-red-600 text-white text-2xl px-8 py-3">
                ADMINISTRADOR
              </Badge>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50/50 to-blue-50/50">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 animate-pulse">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Carregando...</h2>
          </div>
        </Card>
      </div>
    );
  }

  const monthlyPrice = SUBSCRIPTION_PLANS.monthly[selectedCurrency];
  const yearlyPrice = SUBSCRIPTION_PLANS.yearly[selectedCurrency];
  
  const yearlyTotalMonthly = monthlyPrice.amount * 12;
  const yearlySavings = yearlyTotalMonthly - yearlyPrice.amount;

  const isConfigured = selectedCurrency === 'BRL' || selectedCurrency === 'USD';

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-purple-50/50 via-blue-50/50 to-emerald-50/50">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-500 via-blue-500 to-emerald-500 shadow-2xl">
              <Crown className="w-12 h-12 text-white" />
            </div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-3">
                <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-emerald-600 bg-clip-text text-transparent">
                  Premium
                </h1>
                <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-none text-lg px-5 py-2 animate-pulse shadow-lg">
                  <Gift className="w-5 h-5 mr-2" />
                  {FREE_TRIAL_DAYS} DIAS GRÁTIS!
                </Badge>
              </div>
              <p className="text-lg text-gray-600 mt-2">
                Desbloqueie todo o potencial da plataforma
              </p>
            </div>
          </div>
        </motion.div>

        {/* Free Trial Banner */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
          <Alert className="mb-8 border-2 border-yellow-300 bg-gradient-to-r from-yellow-50 via-orange-50 to-yellow-50 shadow-xl">
            <Gift className="h-7 w-7 text-yellow-600" />
            <AlertDescription className="text-yellow-900 text-lg">
              <strong className="block mb-2 text-2xl">🎁 TESTE GRÁTIS POR {FREE_TRIAL_DAYS} DIAS!</strong>
              <p className="mb-2">✨ Experimente todos os benefícios Premium <strong>sem compromisso</strong></p>
              <p className="text-sm">💡 Cancele quando quiser • Sem taxas ocultas • Pagamento seguro</p>
            </AlertDescription>
          </Alert>
        </motion.div>

        {/* Currency Selector */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mb-8">
          <Card className="border-none shadow-2xl bg-gradient-to-r from-blue-50 to-purple-50 overflow-hidden">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <Globe className="w-7 h-7 text-blue-600" />
                <h3 className="text-2xl font-bold text-gray-900">Escolha sua Moeda</h3>
              </div>
              <div className="grid grid-cols-3 gap-4">
                {Object.entries(CURRENCY_COUNTRIES).map(([currency, data]) => {
                  const configured = currency === 'BRL' || currency === 'USD';
                  return (
                    <motion.div 
                      key={currency} 
                      whileHover={{ scale: configured ? 1.05 : 1 }} 
                      whileTap={{ scale: configured ? 0.95 : 1 }}
                    >
                      <button 
                        onClick={() => configured && setSelectedCurrency(currency)}
                        disabled={!configured}
                        className={`w-full p-6 rounded-2xl border-3 transition-all ${
                          selectedCurrency === currency 
                            ? 'border-purple-500 bg-purple-50 shadow-2xl scale-105' 
                            : configured
                            ? 'border-gray-200 hover:border-purple-300 bg-white'
                            : 'border-gray-200 bg-gray-50 opacity-50 cursor-not-allowed'
                        }`}
                      >
                        <div className="text-center">
                          <div className="text-5xl mb-3">{data.flag}</div>
                          <p className="text-2xl font-bold text-gray-900 mb-2">
                            {SUBSCRIPTION_PLANS.monthly[currency].symbol}
                          </p>
                          <p className="text-sm font-semibold text-gray-700 mb-1">{data.name}</p>
                          <p className="text-xs text-gray-500">{data.country}</p>
                          {selectedCurrency === currency && (
                            <CheckCircle className="w-6 h-6 text-purple-600 mx-auto mt-3" />
                          )}
                          {!configured && (
                            <Badge variant="outline" className="mt-2 text-xs">Em breve</Badge>
                          )}
                        </div>
                      </button>
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Plan Comparison */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mb-8">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Monthly Plan */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              onClick={() => setSelectedPlan('monthly')}
            >
              <Card className={`border-3 transition-all cursor-pointer h-full ${
                selectedPlan === 'monthly' 
                  ? 'border-blue-500 shadow-2xl scale-105' 
                  : 'border-gray-200 hover:border-blue-300'
              }`}>
                <div className="h-3 bg-gradient-to-r from-blue-400 to-indigo-500" />
                <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 pb-8">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <CardTitle className="text-3xl font-bold text-gray-900 mb-2">Mensal</CardTitle>
                      <p className="text-gray-600">Flexibilidade total</p>
                    </div>
                    {selectedPlan === 'monthly' && (
                      <Badge className="bg-blue-500 text-white text-lg px-4 py-2">
                        <Check className="w-5 h-5 mr-1" />
                        Selecionado
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-6xl font-bold text-gray-900">
                      {monthlyPrice.symbol}{monthlyPrice.amount.toLocaleString(selectedCurrency === 'BRL' ? 'pt-BR' : 'en-US')}
                    </span>
                    <span className="text-2xl text-gray-600">/{monthlyPrice.period}</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-3">Cobrado mensalmente • Cancele quando quiser</p>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="space-y-4">
                    {BENEFITS.slice(0, 4).map((benefit, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${benefit.bgColor}`}>
                          <benefit.icon className={`w-5 h-5 ${benefit.color}`} />
                        </div>
                        <span className="text-gray-700">{benefit.text}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Yearly Plan */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              onClick={() => setSelectedPlan('yearly')}
            >
              <Card className={`border-3 transition-all cursor-pointer relative overflow-hidden h-full ${
                selectedPlan === 'yearly' 
                  ? 'border-emerald-500 shadow-2xl scale-105' 
                  : 'border-gray-200 hover:border-emerald-300'
              }`}>
                <div className="absolute top-6 right-6 z-10">
                  <Badge className="bg-gradient-to-r from-emerald-500 to-green-500 text-white text-xl px-6 py-3 shadow-2xl animate-pulse">
                    <Sparkles className="w-6 h-6 mr-2" />
                    -{yearlyPrice.discount}% OFF
                  </Badge>
                </div>
                <div className="h-3 bg-gradient-to-r from-emerald-400 via-green-500 to-emerald-600" />
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-green-50 pb-8">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <CardTitle className="text-3xl font-bold text-gray-900 mb-2">Anual</CardTitle>
                      <p className="text-emerald-700 font-bold">🏆 Melhor Valor!</p>
                    </div>
                    {selectedPlan === 'yearly' && (
                      <Badge className="bg-emerald-500 text-white text-lg px-4 py-2">
                        <Check className="w-5 h-5 mr-1" />
                        Selecionado
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-baseline gap-2 mb-4">
                    <span className="text-6xl font-bold text-gray-900">
                      {yearlyPrice.symbol}{yearlyPrice.amount.toLocaleString(selectedCurrency === 'BRL' ? 'pt-BR' : 'en-US')}
                    </span>
                    <span className="text-2xl text-gray-600">/{yearlyPrice.period}</span>
                  </div>
                  <div className="p-4 bg-emerald-100 rounded-xl border-2 border-emerald-300">
                    <p className="text-sm font-bold text-emerald-900 mb-1">
                      💰 Apenas {yearlyPrice.symbol}{yearlyPrice.monthlyEquivalent.toLocaleString(selectedCurrency === 'BRL' ? 'pt-BR' : 'en-US')}/{monthlyPrice.period}
                    </p>
                    <p className="text-xs text-emerald-700">
                      Economize {yearlyPrice.symbol}{yearlySavings.toLocaleString(selectedCurrency === 'BRL' ? 'pt-BR' : 'en-US')} por ano!
                    </p>
                  </div>
                </CardHeader>
                <CardContent className="p-8">
                  <div className="space-y-4">
                    {BENEFITS.slice(0, 4).map((benefit, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${benefit.bgColor}`}>
                          <benefit.icon className={`w-5 h-5 ${benefit.color}`} />
                        </div>
                        <span className="text-gray-700">{benefit.text}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </motion.div>

        {/* All Benefits */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="mb-8">
          <Card className="border-none shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
              <CardTitle className="text-2xl font-bold text-center">
                ✨ Todos os Benefícios Premium
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {BENEFITS.map((benefit, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + idx * 0.05 }}
                    className="text-center"
                  >
                    <div className={`inline-flex p-4 rounded-2xl ${benefit.bgColor} mb-3`}>
                      <benefit.icon className={`w-8 h-8 ${benefit.color}`} />
                    </div>
                    <p className="text-sm font-semibold text-gray-900">{benefit.text}</p>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Subscribe Button / Active Subscription */}
        {!hasActiveSubscription ? (
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
            >
              <Button
                onClick={handleSubscribe}
                disabled={isCreatingCheckout || !isConfigured}
                className="w-full max-w-3xl h-24 text-2xl bg-gradient-to-r from-purple-500 via-blue-500 to-emerald-500 hover:from-purple-600 hover:via-blue-600 hover:to-emerald-600 shadow-2xl hover:shadow-3xl transition-all disabled:opacity-50"
              >
                {isCreatingCheckout ? (
                  <>
                    <Loader2 className="w-8 h-8 mr-3 animate-spin" />
                    Redirecionando para pagamento...
                  </>
                ) : !isConfigured ? (
                  <>
                    <AlertTriangle className="w-8 h-8 mr-3" />
                    Planos {selectedCurrency} em breve
                  </>
                ) : (
                  <>
                    <CreditCard className="w-8 h-8 mr-3" />
                    {selectedPlan === 'monthly' 
                      ? `Assinar Agora - ${monthlyPrice.symbol}${monthlyPrice.amount.toLocaleString()}/${monthlyPrice.period}`
                      : `Assinar Agora - ${yearlyPrice.symbol}${yearlyPrice.amount.toLocaleString()}/${yearlyPrice.period}`
                    }
                    <ArrowRight className="w-8 h-8 ml-3" />
                  </>
                )}
              </Button>
              <div className="mt-6 space-y-2">
                <p className="text-gray-600 flex items-center justify-center gap-2">
                  <Lock className="w-4 h-4" />
                  Pagamento 100% seguro via {selectedCurrency === 'BRL' ? 'Mercado Pago' : 'Stripe'}
                </p>
                <p className="text-gray-600">
                  🎁 Sem compromisso • Cancele quando quiser • {FREE_TRIAL_DAYS} dias grátis
                </p>
                {selectedPlan === 'yearly' && isConfigured && (
                  <p className="text-emerald-700 font-bold text-lg">
                    💰 Economize {yearlyPrice.symbol}{yearlySavings.toLocaleString()} no plano anual!
                  </p>
                )}
              </div>
            </motion.div>

            {/* Info Box */}
            <Alert className={`mt-8 max-w-3xl mx-auto ${
              isConfigured 
                ? 'border-blue-200 bg-blue-50' 
                : 'border-orange-200 bg-orange-50'
            }`}>
              <Info className={`h-5 w-5 ${isConfigured ? 'text-blue-600' : 'text-orange-600'}`} />
              <AlertDescription className={isConfigured ? 'text-blue-900' : 'text-orange-900'}>
                {isConfigured ? (
                  <>
                    <strong>✅ PAGAMENTO CONFIGURADO:</strong> Planos <strong>{selectedCurrency}</strong> estão ativos e prontos para uso. 
                    {selectedCurrency === 'BRL' && ' Pagamento via Mercado Pago.'}
                    {selectedCurrency === 'USD' && ' Pagamento via Stripe (aceita cartões internacionais).'}
                  </>
                ) : (
                  <>
                    <strong>⏳ EM BREVE:</strong> Planos <strong>EUR</strong> estão sendo configurados. 
                    No momento, você pode assinar usando <strong>USD (Internacional)</strong> ou <strong>BRL (Brasil)</strong>.
                  </>
                )}
              </AlertDescription>
            </Alert>
          </div>
        ) : (
          <Card className="border-2 border-emerald-500 shadow-2xl">
            <CardContent className="p-12 text-center">
              <CheckCircle className="w-20 h-20 text-emerald-600 mx-auto mb-6" />
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Você é Premium! 🎉
              </h2>
              <p className="text-xl text-gray-600 mb-6">
                Status: <Badge className={`text-white text-xl px-6 py-2 ${
                  subscription.status === 'pending' ? 'bg-yellow-500' : 'bg-emerald-500'
                }`}>
                  {subscription.status === 'pending' ? '⏳ Aguardando Pagamento' : '✅ Ativo'}
                </Badge>
              </p>
              {subscription.status === 'pending' && (
                <Alert className="max-w-2xl mx-auto border-yellow-300 bg-yellow-50">
                  <Clock className="h-5 w-5 text-yellow-600" />
                  <AlertDescription className="text-yellow-900">
                    Aguardando confirmação do pagamento. Geralmente leva alguns minutos.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}