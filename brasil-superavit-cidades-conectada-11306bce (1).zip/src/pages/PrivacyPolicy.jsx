import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  Lock, 
  Eye, 
  Database, 
  UserCheck, 
  Mail, 
  AlertTriangle,
  CheckCircle,
  FileText,
  Globe
} from "lucide-react";
import { motion } from "framer-motion";

const SectionCard = ({ icon: Icon, title, children, color = "blue" }) => {
  const colors = {
    blue: "from-blue-500 to-blue-600",
    emerald: "from-emerald-500 to-emerald-600",
    purple: "from-purple-500 to-purple-600",
    orange: "from-orange-500 to-orange-600",
    red: "from-red-500 to-red-600"
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-none shadow-lg mb-6">
        <CardHeader className="bg-gradient-to-r from-gray-50 to-blue-50">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-xl bg-gradient-to-br ${colors[color]} shadow-lg`}>
              <Icon className="w-6 h-6 text-white" />
            </div>
            <CardTitle className="text-xl font-bold text-gray-900">{title}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          {children}
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50/30 p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-xl">
              <Shield className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Política de Privacidade
              </h1>
              <p className="text-gray-600 mt-1">Brasil Superávit: Cidades Conectadas</p>
            </div>
          </div>
          
          <Alert className="border-blue-200 bg-blue-50">
            <CheckCircle className="h-5 w-5 text-blue-600" />
            <AlertDescription className="text-blue-900">
              <strong>Última atualização:</strong> 18 de novembro de 2025
              <br />
              Esta política está em conformidade com a <strong>LGPD (Lei Geral de Proteção de Dados)</strong> e garante a proteção de seus dados pessoais.
            </AlertDescription>
          </Alert>
        </motion.div>

        {/* Introduction */}
        <SectionCard icon={FileText} title="1. Introdução" color="blue">
          <div className="prose prose-blue max-w-none">
            <p className="text-gray-700 mb-4">
              Bem-vindo à <strong>Brasil Superávit: Cidades Conectadas</strong>. Esta Política de Privacidade descreve como coletamos, usamos, armazenamos e protegemos suas informações pessoais ao utilizar nossa plataforma.
            </p>
            <p className="text-gray-700 mb-4">
              Levamos sua privacidade a sério e estamos comprometidos em proteger seus dados pessoais de acordo com a Lei Geral de Proteção de Dados (LGPD - Lei nº 13.709/2018) e outras legislações aplicáveis.
            </p>
            <p className="text-gray-700">
              Ao utilizar nossa plataforma, você concorda com os termos desta política. Se não concordar, recomendamos que não utilize nossos serviços.
            </p>
          </div>
        </SectionCard>

        {/* Data Collection */}
        <SectionCard icon={Database} title="2. Dados Coletados" color="emerald">
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-3">2.1. Dados Fornecidos por Você</h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Dados de cadastro:</strong> nome completo, e-mail, senha (criptografada), foto de perfil</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Dados de perfil:</strong> nacionalidade, localização, interesses, habilidades, problemas que deseja resolver</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Dados de investidor:</strong> documentos de identificação, informações bancárias, dados fiscais</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Dados de projetos:</strong> informações sobre projetos criados, investimentos realizados, transações financeiras</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Dados de comunicação:</strong> mensagens enviadas através da plataforma, suporte ao cliente</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-bold text-gray-900 mb-3">2.2. Dados Coletados Automaticamente</h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Dados de navegação:</strong> páginas visitadas, tempo de permanência, cliques, dispositivo utilizado</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Dados técnicos:</strong> endereço IP, tipo de navegador, sistema operacional, cookies</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                  <span><strong>Dados de uso:</strong> funcionalidades acessadas, preferências, histórico de interações</span>
                </li>
              </ul>
            </div>
          </div>
        </SectionCard>

        {/* Data Usage */}
        <SectionCard icon={Eye} title="3. Como Usamos Seus Dados" color="purple">
          <div className="space-y-3">
            <p className="text-gray-700 mb-4">
              Utilizamos seus dados pessoais para as seguintes finalidades:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span><strong>Prestação de serviços:</strong> gerenciar sua conta, processar transações, facilitar investimentos e projetos</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span><strong>Comunicação:</strong> enviar notificações importantes, atualizações de projetos, suporte ao cliente</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span><strong>Personalização:</strong> recomendar projetos relevantes, adaptar a experiência às suas preferências</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span><strong>Segurança:</strong> detectar e prevenir fraudes, proteger a plataforma e usuários</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span><strong>Melhorias:</strong> analisar o uso da plataforma para aprimorar funcionalidades e serviços</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                <span><strong>Compliance:</strong> cumprir obrigações legais, regulatórias e contratuais</span>
              </li>
            </ul>
          </div>
        </SectionCard>

        {/* Data Sharing */}
        <SectionCard icon={Globe} title="4. Compartilhamento de Dados" color="orange">
          <div className="space-y-4">
            <p className="text-gray-700">
              Seus dados pessoais podem ser compartilhados nas seguintes situações:
            </p>
            <ul className="space-y-3 text-gray-700">
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span><strong>Processadores de pagamento:</strong> Mercado Pago e Stripe para processar transações financeiras</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span><strong>Serviços de IA:</strong> Integrações com serviços de inteligência artificial para funcionalidades da plataforma</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span><strong>Provedores de serviços:</strong> Empresas que nos auxiliam na operação da plataforma (hospedagem, armazenamento, análises)</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span><strong>Parceiros de negócio:</strong> Outros usuários da plataforma (investidores, empreendedores) conforme necessário para facilitar transações</span>
              </li>
              <li className="flex items-start gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                <span><strong>Autoridades legais:</strong> Quando exigido por lei, ordem judicial ou para proteger direitos legais</span>
              </li>
            </ul>
            <Alert className="border-orange-200 bg-orange-50 mt-4">
              <Shield className="h-5 w-5 text-orange-600" />
              <AlertDescription className="text-orange-900">
                <strong>Importante:</strong> Nunca vendemos seus dados pessoais a terceiros. Todo compartilhamento é realizado com garantias contratuais de proteção de dados.
              </AlertDescription>
            </Alert>
          </div>
        </SectionCard>

        {/* Data Security */}
        <SectionCard icon={Lock} title="5. Segurança dos Dados" color="red">
          <div className="space-y-3">
            <p className="text-gray-700 mb-4">
              Implementamos medidas técnicas e organizacionais para proteger seus dados:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <Lock className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span><strong>Criptografia:</strong> Senhas criptografadas e comunicações protegidas via HTTPS</span>
              </li>
              <li className="flex items-start gap-2">
                <Lock className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span><strong>Controle de acesso:</strong> Apenas pessoal autorizado tem acesso aos dados pessoais</span>
              </li>
              <li className="flex items-start gap-2">
                <Lock className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span><strong>Monitoramento:</strong> Sistemas de detecção de atividades suspeitas e invasões</span>
              </li>
              <li className="flex items-start gap-2">
                <Lock className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span><strong>Backups:</strong> Cópias de segurança regulares para prevenir perda de dados</span>
              </li>
              <li className="flex items-start gap-2">
                <Lock className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                <span><strong>Auditorias:</strong> Revisões periódicas de segurança e conformidade</span>
              </li>
            </ul>
          </div>
        </SectionCard>

        {/* User Rights */}
        <SectionCard icon={UserCheck} title="6. Seus Direitos (LGPD)" color="emerald">
          <div className="space-y-4">
            <p className="text-gray-700 mb-4">
              De acordo com a LGPD, você tem os seguintes direitos sobre seus dados pessoais:
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-emerald-50 rounded-lg">
                <h4 className="font-bold text-emerald-900 mb-2">✅ Acesso</h4>
                <p className="text-sm text-emerald-800">Consultar quais dados temos sobre você</p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-bold text-blue-900 mb-2">✏️ Correção</h4>
                <p className="text-sm text-blue-800">Corrigir dados incompletos ou desatualizados</p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <h4 className="font-bold text-purple-900 mb-2">🗑️ Exclusão</h4>
                <p className="text-sm text-purple-800">Solicitar a remoção de seus dados</p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <h4 className="font-bold text-orange-900 mb-2">📦 Portabilidade</h4>
                <p className="text-sm text-orange-800">Receber seus dados em formato estruturado</p>
              </div>
              <div className="p-4 bg-red-50 rounded-lg">
                <h4 className="font-bold text-red-900 mb-2">🚫 Revogação</h4>
                <p className="text-sm text-red-800">Retirar consentimento para tratamento</p>
              </div>
              <div className="p-4 bg-gray-100 rounded-lg">
                <h4 className="font-bold text-gray-900 mb-2">ℹ️ Informação</h4>
                <p className="text-sm text-gray-800">Saber sobre compartilhamento de dados</p>
              </div>
            </div>
            <Alert className="border-emerald-200 bg-emerald-50 mt-4">
              <Mail className="h-5 w-5 text-emerald-600" />
              <AlertDescription className="text-emerald-900">
                <strong>Para exercer seus direitos:</strong> Entre em contato conosco através do e-mail{" "}
                <a href="mailto:privacidade@brasilsuperavit.com.br" className="font-bold underline">
                  privacidade@brasilsuperavit.com.br
                </a>
              </AlertDescription>
            </Alert>
          </div>
        </SectionCard>

        {/* Data Retention */}
        <SectionCard icon={Database} title="7. Retenção de Dados" color="blue">
          <div className="prose prose-blue max-w-none">
            <p className="text-gray-700 mb-4">
              Mantemos seus dados pessoais pelo tempo necessário para cumprir as finalidades descritas nesta política, ou conforme exigido por lei.
            </p>
            <ul className="space-y-2 text-gray-700">
              <li><strong>Dados de conta ativa:</strong> Enquanto sua conta estiver ativa</li>
              <li><strong>Dados financeiros:</strong> 5 anos após a última transação (exigência fiscal)</li>
              <li><strong>Dados de suporte:</strong> 2 anos após o último contato</li>
              <li><strong>Dados de navegação:</strong> Até 12 meses</li>
            </ul>
            <p className="text-gray-700 mt-4">
              Após os períodos de retenção, os dados serão anonimizados ou excluídos de forma segura.
            </p>
          </div>
        </SectionCard>

        {/* Cookies */}
        <SectionCard icon={Globe} title="8. Cookies e Tecnologias Similares" color="purple">
          <div className="prose prose-purple max-w-none">
            <p className="text-gray-700 mb-4">
              Utilizamos cookies e tecnologias similares para melhorar sua experiência na plataforma:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li><strong>Cookies essenciais:</strong> Necessários para o funcionamento básico da plataforma</li>
              <li><strong>Cookies de desempenho:</strong> Ajudam a entender como os usuários interagem com a plataforma</li>
              <li><strong>Cookies de funcionalidade:</strong> Permitem personalizar sua experiência</li>
              <li><strong>Cookies de marketing:</strong> Usados para exibir conteúdo relevante (somente com seu consentimento)</li>
            </ul>
            <p className="text-gray-700 mt-4">
              Você pode gerenciar suas preferências de cookies através das configurações do seu navegador.
            </p>
          </div>
        </SectionCard>

        {/* Children Privacy */}
        <SectionCard icon={AlertTriangle} title="9. Privacidade de Crianças e Adolescentes" color="red">
          <div className="prose prose-red max-w-none">
            <p className="text-gray-700 mb-4">
              Nossa plataforma não é destinada a menores de 18 anos. Não coletamos intencionalmente dados de crianças ou adolescentes sem o consentimento dos pais ou responsáveis legais.
            </p>
            <p className="text-gray-700">
              Se tomarmos conhecimento de que coletamos dados de menores sem autorização, tomaremos medidas para excluir essas informações imediatamente.
            </p>
          </div>
        </SectionCard>

        {/* Changes to Policy */}
        <SectionCard icon={FileText} title="10. Alterações nesta Política" color="orange">
          <div className="prose prose-orange max-w-none">
            <p className="text-gray-700 mb-4">
              Podemos atualizar esta Política de Privacidade periodicamente para refletir mudanças em nossas práticas ou por requisitos legais.
            </p>
            <p className="text-gray-700 mb-4">
              Quando fizermos alterações significativas, notificaremos você por e-mail ou através de um aviso destacado na plataforma.
            </p>
            <p className="text-gray-700">
              Recomendamos que você revise esta política regularmente para se manter informado sobre como protegemos seus dados.
            </p>
          </div>
        </SectionCard>

        {/* Contact */}
        <SectionCard icon={Mail} title="11. Contato" color="emerald">
          <div className="prose prose-emerald max-w-none">
            <p className="text-gray-700 mb-4">
              Se você tiver dúvidas, preocupações ou solicitações relacionadas a esta Política de Privacidade ou ao tratamento de seus dados pessoais, entre em contato conosco:
            </p>
            <div className="bg-emerald-50 p-6 rounded-xl border-2 border-emerald-200">
              <h3 className="text-lg font-bold text-emerald-900 mb-4">Encarregado de Proteção de Dados (DPO)</h3>
              <ul className="space-y-2 text-emerald-900">
                <li className="flex items-center gap-2">
                  <Mail className="w-5 h-5 text-emerald-600" />
                  <span><strong>E-mail:</strong> privacidade@brasilsuperavit.com.br</span>
                </li>
                <li className="flex items-center gap-2">
                  <Globe className="w-5 h-5 text-emerald-600" />
                  <span><strong>Plataforma:</strong> Brasil Superávit: Cidades Conectadas</span>
                </li>
              </ul>
            </div>
            <p className="text-gray-700 mt-4">
              Responderemos às suas solicitações dentro dos prazos estabelecidos pela LGPD (até 15 dias).
            </p>
          </div>
        </SectionCard>

        {/* Footer Note */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-8"
        >
          <Alert className="border-blue-200 bg-gradient-to-r from-blue-50 to-purple-50">
            <Shield className="h-5 w-5 text-blue-600" />
            <AlertDescription className="text-gray-900">
              <strong>Compromisso com a Privacidade:</strong> A Brasil Superávit está comprometida em proteger sua privacidade e manter seus dados seguros. 
              Esta política reflete nosso compromisso com a transparência e conformidade com a LGPD.
            </AlertDescription>
          </Alert>
        </motion.div>
      </div>
    </div>
  );
}