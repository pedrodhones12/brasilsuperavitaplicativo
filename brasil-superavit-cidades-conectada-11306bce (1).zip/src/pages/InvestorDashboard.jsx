import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  TrendingUp,
  DollarSign,
  Target,
  PieChart as PieChartIcon,
  Award,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  Bell,
  MapPin,
  BarChart3,
  Download,
  FileText,
  Clock,
  Percent,
  TrendingDown,
  AlertCircle,
  CheckCircle2,
  Loader2
} from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { PieChart, Pie, Cell, BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from "recharts";
import ProjectRecommendations from "../components/recommendations/ProjectRecommendations";

const COLORS = ['#059669', '#0284c7', '#8b5cf6', '#f59e0b', '#ef4444', '#06b6d4', '#ec4899'];

const categoryColors = {
  bronze: "from-amber-600 to-amber-700",
  prata: "from-gray-400 to-gray-500",
  ouro: "from-yellow-400 to-yellow-600",
};

const StatCard = ({ title, value, subtitle, icon: Icon, trend, trendValue, gradient, onClick }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    whileHover={{ y: -4 }}
    transition={{ duration: 0.3 }}
    onClick={onClick}
    className={onClick ? "cursor-pointer" : ""}
  >
    <Card className="border-none shadow-xl overflow-hidden group">
      <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-5 group-hover:opacity-10 transition-opacity`} />
      <CardContent className="p-6 relative">
        <div className="flex justify-between items-start mb-4">
          <div className={`p-3 rounded-xl bg-gradient-to-br ${gradient} shadow-lg group-hover:scale-110 transition-transform`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
          {trend && (
            <div className={`flex items-center gap-1 px-2 py-1 rounded-full ${
              trend === 'up' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'
            }`}>
              {trend === 'up' ? (
                <ArrowUpRight className="w-4 h-4" />
              ) : (
                <ArrowDownRight className="w-4 h-4" />
              )}
              <span className="text-xs font-semibold">{trendValue}</span>
            </div>
          )}
        </div>
        <div>
          <p className="text-sm text-gray-500 mb-1">{title}</p>
          <p className="text-3xl font-bold text-gray-900 mb-1">{value}</p>
          {subtitle && (
            <p className="text-xs text-gray-600">{subtitle}</p>
          )}
        </div>
      </CardContent>
    </Card>
  </motion.div>
);

const InvestmentCard = ({ project, investment }) => {
  const progress = (project.current_funding / project.funding_goal) * 100;
  const roi = ((project.current_funding - investment.amount) / investment.amount) * 100;
  const daysInvested = Math.floor((new Date() - new Date(investment.investment_date)) / (1000 * 60 * 60 * 24));
  const estimatedValue = investment.amount * (1 + progress / 200); // Simplified calculation

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="pb-3 bg-gradient-to-r from-emerald-50 to-blue-50">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <CardTitle className="text-lg mb-2 line-clamp-1">{project.title}</CardTitle>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="w-4 h-4" />
                <span>{project.city}/{project.state}</span>
              </div>
            </div>
            <Badge className={`bg-gradient-to-r ${categoryColors[investment.category]} text-white border-none`}>
              {investment.category.charAt(0).toUpperCase() + investment.category.slice(1)}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-gray-500 mb-1">Investido</p>
              <p className="text-xl font-bold text-gray-900">
                R$ {investment.amount?.toLocaleString('pt-BR')}
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-1">Valor Atual</p>
              <p className="text-xl font-bold text-emerald-600">
                R$ {estimatedValue.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500 mb-1">ROI Estimado</p>
              <div className="flex items-center gap-1">
                {roi >= 0 ? (
                  <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                ) : (
                  <ArrowDownRight className="w-4 h-4 text-red-600" />
                )}
                <p className={`text-lg font-bold ${roi >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {roi.toFixed(1)}%
                </p>
              </div>
            </div>
            <div className="p-3 bg-gray-50 rounded-lg">
              <p className="text-xs text-gray-500 mb-1">Tempo Investido</p>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4 text-blue-600" />
                <p className="text-lg font-bold text-gray-900">
                  {daysInvested}d
                </p>
              </div>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-600">Progresso do Projeto</span>
              <span className="text-sm font-semibold text-emerald-600">{progress.toFixed(0)}%</span>
            </div>
            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                style={{ width: `${Math.min(progress, 100)}%` }}
                className="h-full bg-gradient-to-r from-emerald-500 to-blue-500 transition-all duration-500"
              />
            </div>
            <div className="flex justify-between mt-2 text-xs text-gray-500">
              <span>R$ {project.current_funding?.toLocaleString('pt-BR')}</span>
              <span>R$ {project.funding_goal?.toLocaleString('pt-BR')}</span>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-gray-200">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Calendar className="w-4 h-4" />
              <span>{format(new Date(investment.investment_date), "dd MMM yyyy", { locale: ptBR })}</span>
            </div>
            {progress >= 100 ? (
              <Badge className="bg-emerald-100 text-emerald-700">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                Concluído
              </Badge>
            ) : (
              <Badge variant="outline" className="text-blue-600 border-blue-600">
                <Activity className="w-3 h-3 mr-1" />
                Em Progresso
              </Badge>
            )}
          </div>

          <Link to={createPageUrl(`Projects`)}>
            <Button variant="outline" size="sm" className="w-full">
              Ver Detalhes
            </Button>
          </Link>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function InvestorDashboard() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [timeRange, setTimeRange] = useState("all"); // all, 30d, 90d, 1y

  useEffect(() => {
    const loadUser = async () => {
      const userData = await base44.auth.me();
      setUser(userData);
    };
    loadUser();
  }, []);

  const { data: investments = [] } = useQuery({
    queryKey: ['my-investments', user?.email],
    queryFn: () => base44.entities.Investment.filter({ investor_email: user?.email, status: 'confirmado' }, '-created_date'),
    enabled: !!user?.email,
  });

  const { data: allProjects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list(),
  });

  // Calculate comprehensive metrics
  const metrics = useMemo(() => {
    const totalInvested = investments.reduce((sum, inv) => sum + (inv.amount || 0), 0);
    const projectsCount = new Set(investments.map(inv => inv.project_id)).size;

    // Calculate portfolio value
    const portfolioValue = investments.reduce((sum, inv) => {
      const project = allProjects.find(p => p.id === inv.project_id);
      if (!project) return sum;
      const progress = (project.current_funding / project.funding_goal);
      return sum + (inv.amount * (1 + progress * 0.1));
    }, 0);

    const totalReturn = portfolioValue - totalInvested;
    const returnPercentage = totalInvested > 0 ? (totalReturn / totalInvested) * 100 : 0;

    // Calculate average ROI
    const avgROI = investments.reduce((sum, inv) => {
      const project = allProjects.find(p => p.id === inv.project_id);
      if (!project) return sum;
      const progress = (project.current_funding / project.funding_goal);
      const roi = progress * 10; // Simplified
      return sum + roi;
    }, 0) / (investments.length || 1);

    // Calculate diversification score (0-100)
    const sectors = new Set(investments.map(inv => {
      const project = allProjects.find(p => p.id === inv.project_id);
      return project?.sector;
    }).filter(Boolean));
    const diversificationScore = Math.min(100, (sectors.size / 9) * 100); // 9 total sectors

    // Calculate active investments
    const activeInvestments = investments.filter(inv => {
      const project = allProjects.find(p => p.id === inv.project_id);
      return project && project.status === 'ativa';
    }).length;

    // Best performing investment
    const bestPerformer = investments.reduce((best, inv) => {
      const project = allProjects.find(p => p.id === inv.project_id);
      if (!project) return best;
      const progress = (project.current_funding / project.funding_goal) * 100;
      return progress > best.progress ? { ...inv, progress, project } : best;
    }, { progress: 0 });

    return {
      totalInvested,
      portfolioValue,
      totalReturn,
      returnPercentage,
      projectsCount,
      avgROI,
      diversificationScore,
      activeInvestments,
      bestPerformer
    };
  }, [investments, allProjects]);

  // Investment distribution by category
  const categoryDistribution = useMemo(() => {
    const dist = investments.reduce((acc, inv) => {
      const category = inv.category;
      acc[category] = (acc[category] || 0) + inv.amount;
      return acc;
    }, {});

    return Object.entries(dist).map(([name, value]) => ({
      name: name.charAt(0).toUpperCase() + name.slice(1),
      value,
    }));
  }, [investments]);

  // Investment distribution by sector
  const sectorDistribution = useMemo(() => {
    const dist = investments.reduce((acc, inv) => {
      const project = allProjects.find(p => p.id === inv.project_id);
      if (!project) return acc;
      const sector = project.sector;
      acc[sector] = (acc[sector] || 0) + inv.amount;
      return acc;
    }, {});

    return Object.entries(dist).map(([name, value]) => ({
      name: name === 'tecnologico' ? 'Tecnológico' : name === 'cultural' ? 'Cultural' : name === 'sustentabilidade' ? 'Sustentabilidade' : name,
      value,
    }));
  }, [investments, allProjects]);

  // Monthly investment trend (last 12 months)
  const monthlyTrend = useMemo(() => {
    const last12Months = Array.from({ length: 12 }, (_, i) => {
      const date = new Date();
      date.setMonth(date.getMonth() - (11 - i));
      return {
        month: format(date, "MMM", { locale: ptBR }),
        invested: 0,
        value: 0,
        return: 0
      };
    });

    investments.forEach(inv => {
      const invDate = new Date(inv.investment_date);
      const monthIndex = last12Months.findIndex(m => {
        const testDate = new Date();
        testDate.setMonth(testDate.getMonth() - (11 - last12Months.indexOf(m)));
        return invDate.getMonth() === testDate.getMonth() && invDate.getFullYear() === testDate.getFullYear();
      });

      if (monthIndex !== -1) {
        last12Months[monthIndex].invested += inv.amount;
        
        const project = allProjects.find(p => p.id === inv.project_id);
        if (project) {
          const progress = (project.current_funding / project.funding_goal);
          const currentValue = inv.amount * (1 + progress * 0.1);
          last12Months[monthIndex].value += currentValue;
          last12Months[monthIndex].return += (currentValue - inv.amount);
        }
      }
    });

    // Cumulative values
    let cumInvested = 0;
    let cumValue = 0;
    return last12Months.map(m => {
      cumInvested += m.invested;
      cumValue += m.value;
      return {
        ...m,
        invested: cumInvested,
        value: cumValue,
        return: cumValue - cumInvested
      };
    });
  }, [investments, allProjects]);

  // Top performing projects
  const topProjects = useMemo(() => {
    return investments
      .map(inv => {
        const project = allProjects.find(p => p.id === inv.project_id);
        if (!project) return null;
        const progress = (project.current_funding / project.funding_goal) * 100;
        const roi = ((project.current_funding - inv.amount) / inv.amount) * 100;
        return { ...inv, project, progress, roi };
      })
      .filter(Boolean)
      .sort((a, b) => b.roi - a.roi)
      .slice(0, 5);
  }, [investments, allProjects]);

  // Generate downloadable report
  const generateReport = () => {
    const reportData = {
      generatedAt: new Date().toISOString(),
      investor: {
        name: user?.full_name,
        email: user?.email,
      },
      summary: {
        totalInvested: metrics.totalInvested,
        portfolioValue: metrics.portfolioValue,
        totalReturn: metrics.totalReturn,
        returnPercentage: metrics.returnPercentage,
        activeInvestments: metrics.activeInvestments,
        totalProjects: metrics.projectsCount,
      },
      investments: investments.map(inv => {
        const project = allProjects.find(p => p.id === inv.project_id);
        return {
          projectTitle: inv.project_title,
          amount: inv.amount,
          category: inv.category,
          date: inv.investment_date,
          projectProgress: project ? ((project.current_funding / project.funding_goal) * 100).toFixed(2) + '%' : 'N/A',
        };
      }),
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `portfolio-report-${format(new Date(), 'yyyy-MM-dd')}.json`;
    a.click();
  };

  if (!user) {
    return (
      <div className="min-h-screen p-4 md:p-8 flex items-center justify-center">
        <Card className="p-12 max-w-md">
          <div className="text-center space-y-4">
            <Loader2 className="w-16 h-16 text-emerald-600 mx-auto animate-spin" />
            <h2 className="text-2xl font-bold text-gray-900">Carregando dashboard...</h2>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gradient-to-br from-emerald-50/30 via-blue-50/30 to-purple-50/30">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Activity className="w-10 h-10 text-emerald-600" />
                <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
                  Meu Portfólio
                </h1>
              </div>
              <p className="text-lg text-gray-600">
                Acompanhe seus investimentos e performance em tempo real
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={generateReport}
                className="gap-2"
              >
                <Download className="w-4 h-4" />
                Baixar Relatório
              </Button>
              <Link to={createPageUrl("Invest")}>
                <Button className="bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600 shadow-lg">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Novo Investimento
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Investimento Total"
            value={`R$ ${metrics.totalInvested.toLocaleString('pt-BR')}`}
            subtitle="Capital investido"
            icon={DollarSign}
            gradient="from-emerald-500 to-emerald-600"
            trend="up"
            trendValue="100%"
          />
          <StatCard
            title="Valor do Portfólio"
            value={`R$ ${metrics.portfolioValue.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
            subtitle="Valor atual estimado"
            icon={PieChartIcon}
            gradient="from-blue-500 to-blue-600"
            trend={metrics.returnPercentage >= 0 ? 'up' : 'down'}
            trendValue={`${metrics.returnPercentage.toFixed(1)}%`}
          />
          <StatCard
            title="Retorno Total"
            value={`R$ ${metrics.totalReturn.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
            subtitle={metrics.returnPercentage >= 0 ? 'Ganho acumulado' : 'Perda acumulada'}
            icon={metrics.returnPercentage >= 0 ? TrendingUp : TrendingDown}
            gradient={metrics.returnPercentage >= 0 ? "from-green-500 to-green-600" : "from-red-500 to-red-600"}
            trend={metrics.returnPercentage >= 0 ? 'up' : 'down'}
            trendValue={`${Math.abs(metrics.returnPercentage).toFixed(1)}%`}
          />
          <StatCard
            title="Projetos Ativos"
            value={metrics.activeInvestments}
            subtitle={`${metrics.projectsCount} projetos no total`}
            icon={Target}
            gradient="from-purple-500 to-purple-600"
          />
        </div>

        {/* Additional Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <div className="p-3 rounded-xl bg-gradient-to-br from-yellow-500 to-orange-500">
                  <Percent className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-blue-100 text-blue-700">ROI Médio</Badge>
              </div>
              <p className="text-sm text-gray-500 mb-1">Retorno Médio</p>
              <p className="text-3xl font-bold text-gray-900">{metrics.avgROI.toFixed(1)}%</p>
              <p className="text-xs text-gray-600 mt-2">Calculado sobre todos os investimentos</p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <div className="p-3 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-500">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-purple-100 text-purple-700">Diversificação</Badge>
              </div>
              <p className="text-sm text-gray-500 mb-1">Score de Diversificação</p>
              <p className="text-3xl font-bold text-gray-900">{metrics.diversificationScore.toFixed(0)}/100</p>
              <p className="text-xs text-gray-600 mt-2">
                {metrics.diversificationScore >= 70 ? 'Excelente diversificação' : 
                 metrics.diversificationScore >= 50 ? 'Boa diversificação' : 
                 'Considere diversificar mais'}
              </p>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-emerald-50 to-blue-50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-3">
                <div className="p-3 rounded-xl bg-gradient-to-br from-emerald-500 to-blue-500">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-yellow-100 text-yellow-700">Melhor</Badge>
              </div>
              <p className="text-sm text-gray-500 mb-1">Melhor Investimento</p>
              {metrics.bestPerformer.progress > 0 ? (
                <>
                  <p className="text-lg font-bold text-gray-900 line-clamp-1">
                    {metrics.bestPerformer.project?.title || 'N/A'}
                  </p>
                  <p className="text-2xl font-bold text-emerald-600 mt-1">
                    {metrics.bestPerformer.progress.toFixed(0)}%
                  </p>
                </>
              ) : (
                <p className="text-gray-600">Nenhum investimento ainda</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* AI Recommendations */}
        {user && (
          <div className="mb-8">
            <ProjectRecommendations user={user} limit={3} />
          </div>
        )}

        {/* Tabs Section */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <TabsList className="bg-gray-100 w-full justify-start overflow-x-auto">
                <TabsTrigger value="overview" className="px-6">📊 Visão Geral</TabsTrigger>
                <TabsTrigger value="performance" className="px-6">📈 Performance</TabsTrigger>
                <TabsTrigger value="investments" className="px-6">💼 Investimentos</TabsTrigger>
                <TabsTrigger value="analytics" className="px-6">📉 Análises</TabsTrigger>
                <TabsTrigger value="reports" className="px-6">📄 Relatórios</TabsTrigger>
              </TabsList>
            </CardContent>
          </Card>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Category Distribution */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                    <CardTitle className="flex items-center gap-2">
                      <Award className="w-6 h-6 text-emerald-600" />
                      Distribuição por Categoria
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={categoryDistribution}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {categoryDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="mt-6 space-y-3">
                      {categoryDistribution.map((cat, index) => (
                        <div key={cat.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="w-4 h-4 rounded-full" style={{ backgroundColor: COLORS[index] }} />
                            <span className="font-medium text-gray-900">{cat.name}</span>
                          </div>
                          <span className="text-sm text-gray-600">
                            R$ {cat.value.toLocaleString('pt-BR')}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Sector Distribution */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="w-6 h-6 text-blue-600" />
                      Distribuição por Setor
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={sectorDistribution}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                        <YAxis />
                        <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
                        <Bar dataKey="value" fill="url(#colorGradient)" />
                        <defs>
                          <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#059669" stopOpacity={1} />
                            <stop offset="100%" stopColor="#0284c7" stopOpacity={1} />
                          </linearGradient>
                        </defs>
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </TabsContent>

          {/* Performance Tab */}
          <TabsContent value="performance" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="border-none shadow-xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-6 h-6 text-purple-600" />
                    Performance do Portfólio (12 meses)
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <ResponsiveContainer width="100%" height={400}>
                    <AreaChart data={monthlyTrend}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => `R$ ${value.toLocaleString('pt-BR')}`} />
                      <Legend />
                      <Area
                        type="monotone"
                        dataKey="invested"
                        stackId="1"
                        stroke="#059669"
                        fill="#059669"
                        fillOpacity={0.6}
                        name="Investido"
                      />
                      <Area
                        type="monotone"
                        dataKey="return"
                        stackId="1"
                        stroke="#0284c7"
                        fill="#0284c7"
                        fillOpacity={0.6}
                        name="Retorno"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>

            {/* Top Performers */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="border-none shadow-xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                  <CardTitle className="flex items-center gap-2">
                    <Award className="w-6 h-6 text-yellow-600" />
                    Top 5 Investimentos por Performance
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {topProjects.map((item, index) => (
                      <div key={item.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${
                          index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : 'bg-amber-600'
                        }`}>
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-gray-900 line-clamp-1">{item.project.title}</p>
                          <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                            <span>Investido: R$ {item.amount.toLocaleString('pt-BR')}</span>
                            <span>•</span>
                            <span>Progresso: {item.progress.toFixed(0)}%</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`text-xl font-bold ${item.roi >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                            {item.roi >= 0 ? '+' : ''}{item.roi.toFixed(1)}%
                          </p>
                          <p className="text-xs text-gray-500">ROI</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Investments Tab */}
          <TabsContent value="investments" className="space-y-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 }}
            >
              <Card className="border-none shadow-xl">
                <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                  <div className="flex justify-between items-center">
                    <CardTitle>Todos os Investimentos</CardTitle>
                    <Badge variant="outline" className="font-semibold">
                      {investments.length} {investments.length === 1 ? 'Investimento' : 'Investimentos'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  {investments.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {investments.map((investment) => {
                        const project = allProjects.find(p => p.id === investment.project_id);
                        if (!project) return null;
                        return (
                          <InvestmentCard 
                            key={investment.id} 
                            investment={investment}
                            project={project}
                          />
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Target className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600 text-lg mb-4">Você ainda não investiu em nenhum projeto</p>
                      <Link to={createPageUrl("Invest")}>
                        <Button className="bg-gradient-to-r from-emerald-500 to-blue-500">
                          Fazer Primeiro Investimento
                        </Button>
                      </Link>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Investment Summary */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-emerald-50 to-blue-50">
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="w-6 h-6 text-emerald-600" />
                      Resumo de Investimentos
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <div className="p-4 bg-gradient-to-r from-emerald-50 to-blue-50 rounded-xl">
                      <p className="text-sm text-gray-600 mb-1">Total Investido</p>
                      <p className="text-3xl font-bold text-gray-900">
                        R$ {metrics.totalInvested.toLocaleString('pt-BR')}
                      </p>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-xs text-gray-500 mb-1">Maior Investimento</p>
                        <p className="text-xl font-bold text-gray-900">
                          R$ {Math.max(...investments.map(i => i.amount)).toLocaleString('pt-BR')}
                        </p>
                      </div>
                      <div className="p-4 bg-gray-50 rounded-xl">
                        <p className="text-xs text-gray-500 mb-1">Ticket Médio</p>
                        <p className="text-xl font-bold text-gray-900">
                          R$ {(metrics.totalInvested / (investments.length || 1)).toLocaleString('pt-BR', { maximumFractionDigits: 0 })}
                        </p>
                      </div>
                    </div>
                    <div className="pt-4 border-t border-gray-200">
                      <h4 className="font-semibold text-gray-900 mb-3">Análise de Risco</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Diversificação</span>
                          <Badge variant="outline" className={
                            metrics.diversificationScore >= 70 ? 'bg-emerald-50 text-emerald-700' :
                            metrics.diversificationScore >= 50 ? 'bg-blue-50 text-blue-700' :
                            'bg-orange-50 text-orange-700'
                          }>
                            {metrics.diversificationScore >= 70 ? 'Alta' : 
                             metrics.diversificationScore >= 50 ? 'Média' : 'Baixa'}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Perfil</span>
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">
                            {investments.filter(i => i.category === 'ouro').length > investments.length / 2 ? 'Agressivo' : 
                             investments.filter(i => i.category === 'prata').length > investments.length / 2 ? 'Moderado' : 'Conservador'}
                          </Badge>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">ROI Médio</span>
                          <Badge variant="outline" className={
                            metrics.avgROI >= 15 ? 'bg-emerald-50 text-emerald-700' :
                            metrics.avgROI >= 10 ? 'bg-blue-50 text-blue-700' :
                            'bg-gray-50 text-gray-700'
                          }>
                            {metrics.avgROI.toFixed(1)}%
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Investment Timeline */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card className="border-none shadow-xl">
                  <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50">
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="w-6 h-6 text-blue-600" />
                      Linha do Tempo
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      {investments
                        .sort((a, b) => new Date(b.investment_date) - new Date(a.investment_date))
                        .slice(0, 10)
                        .map((inv, index) => (
                          <div key={inv.id} className="flex items-start gap-4 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                            <div className="flex flex-col items-center">
                              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-blue-500 flex items-center justify-center text-white text-xs font-bold">
                                {index + 1}
                              </div>
                              {index < 9 && <div className="w-0.5 h-8 bg-gray-300 mt-2" />}
                            </div>
                            <div className="flex-1">
                              <p className="font-semibold text-gray-900 text-sm line-clamp-1">{inv.project_title}</p>
                              <p className="text-xs text-gray-600 mt-1">
                                R$ {inv.amount.toLocaleString('pt-BR')} • {format(new Date(inv.investment_date), "dd MMM yyyy", { locale: ptBR })}
                              </p>
                              <Badge className={`mt-2 text-xs bg-gradient-to-r ${categoryColors[inv.category]} text-white border-none`}>
                                {inv.category.charAt(0).toUpperCase() + inv.category.slice(1)}
                              </Badge>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </TabsContent>

          {/* Reports Tab */}
          <TabsContent value="reports" className="space-y-6">
            <Card className="border-none shadow-xl">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-6 h-6 text-purple-600" />
                  Relatórios Personalizados
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="p-6 bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-xl border-2 border-emerald-200 cursor-pointer hover:shadow-lg transition-all">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 bg-white rounded-lg">
                        <DollarSign className="w-6 h-6 text-emerald-600" />
                      </div>
                      <Download className="w-5 h-5 text-emerald-600" />
                    </div>
                    <h3 className="font-bold text-gray-900 mb-2">Relatório Financeiro</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Resumo completo de investimentos, retornos e performance
                    </p>
                    <Button 
                      onClick={generateReport}
                      className="w-full bg-emerald-600 hover:bg-emerald-700"
                    >
                      Gerar Relatório
                    </Button>
                  </div>

                  <div className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl border-2 border-blue-200">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 bg-white rounded-lg">
                        <BarChart3 className="w-6 h-6 text-blue-600" />
                      </div>
                      <span className="text-xs bg-blue-600 text-white px-2 py-1 rounded-full">Em breve</span>
                    </div>
                    <h3 className="font-bold text-gray-900 mb-2">Análise de Portfolio</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Análise detalhada de diversificação e alocação de ativos
                    </p>
                    <Button variant="outline" className="w-full" disabled>
                      Em Desenvolvimento
                    </Button>
                  </div>

                  <div className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl border-2 border-purple-200">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-3 bg-white rounded-lg">
                        <TrendingUp className="w-6 h-6 text-purple-600" />
                      </div>
                      <span className="text-xs bg-purple-600 text-white px-2 py-1 rounded-full">Em breve</span>
                    </div>
                    <h3 className="font-bold text-gray-900 mb-2">Projeções Futuras</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Previsões baseadas em IA do crescimento do seu portfólio
                    </p>
                    <Button variant="outline" className="w-full" disabled>
                      Em Desenvolvimento
                    </Button>
                  </div>
                </div>

                {/* Report Summary */}
                <div className="mt-8 p-6 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl">
                  <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Resumo do Relatório Atual
                  </h3>
                  <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600 mb-1">Data de Geração</p>
                      <p className="font-semibold text-gray-900">{format(new Date(), "dd 'de' MMMM 'de' yyyy", { locale: ptBR })}</p>
                    </div>
                    <div>
                      <p className="text-gray-600 mb-1">Período Analisado</p>
                      <p className="font-semibold text-gray-900">Últimos 12 meses</p>
                    </div>
                    <div>
                      <p className="text-gray-600 mb-1">Total de Investimentos</p>
                      <p className="font-semibold text-gray-900">{investments.length}</p>
                    </div>
                    <div>
                      <p className="text-gray-600 mb-1">Performance Geral</p>
                      <p className={`font-semibold ${metrics.returnPercentage >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                        {metrics.returnPercentage >= 0 ? '+' : ''}{metrics.returnPercentage.toFixed(2)}%
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}