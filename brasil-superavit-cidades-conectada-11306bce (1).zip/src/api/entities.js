import { base44 } from './base44Client';


export const Project = base44.entities.Project;

export const Investment = base44.entities.Investment;

export const Transaction = base44.entities.Transaction;

export const Tutorial = base44.entities.Tutorial;

export const IntellectualProperty = base44.entities.IntellectualProperty;

export const Subscription = base44.entities.Subscription;

export const InternationalInvestor = base44.entities.InternationalInvestor;

export const SocialPost = base44.entities.SocialPost;

export const PostComment = base44.entities.PostComment;

export const PostLike = base44.entities.PostLike;

export const Partnership = base44.entities.Partnership;

export const CurrencyRate = base44.entities.CurrencyRate;

export const Meeting = base44.entities.Meeting;

export const Notification = base44.entities.Notification;

export const ProjectFollow = base44.entities.ProjectFollow;

export const SubscriptionEvent = base44.entities.SubscriptionEvent;



// auth sdk:
export const User = base44.auth;