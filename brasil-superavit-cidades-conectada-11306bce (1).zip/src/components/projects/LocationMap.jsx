import React, { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import { Card } from "@/components/ui/card";
import { MapPin, Navigation } from "lucide-react";
import { motion } from "framer-motion";
import "leaflet/dist/leaflet.css";

// Fix for default marker icons in react-leaflet
if (typeof window !== 'undefined') {
  delete L.Icon.Default.prototype._getIconUrl;
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  });
}

// Component to recenter map
function RecenterMap({ lat, lng }) {
  const map = useMap();
  
  useEffect(() => {
    if (lat && lng) {
      map.setView([lat, lng], 13, { animate: true });
    }
  }, [lat, lng, map]);
  
  return null;
}

export default function LocationMap({ 
  latitude, 
  longitude, 
  city, 
  state, 
  title,
  className = "" 
}) {
  const [coords, setCoords] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const getCoordinates = async () => {
      // If coordinates are provided, use them
      if (latitude && longitude) {
        setCoords({ lat: latitude, lng: longitude });
        setLoading(false);
        return;
      }

      // Otherwise, geocode the city
      if (!city || !state) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const query = `${city}, ${state}, Brazil`;
        const response = await fetch(
          `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`
        );
        const data = await response.json();
        
        if (data && data.length > 0) {
          setCoords({
            lat: parseFloat(data[0].lat),
            lng: parseFloat(data[0].lon)
          });
        } else {
          setError('Localização não encontrada');
        }
      } catch (err) {
        console.error('Error geocoding:', err);
        setError('Erro ao carregar mapa');
      } finally {
        setLoading(false);
      }
    };

    getCoordinates();
  }, [latitude, longitude, city, state]);

  if (loading) {
    return (
      <Card className={`p-8 bg-gray-50 ${className}`}>
        <div className="flex items-center justify-center gap-3">
          <MapPin className="w-5 h-5 text-gray-400 animate-pulse" />
          <span className="text-gray-500">Carregando mapa...</span>
        </div>
      </Card>
    );
  }

  if (error || !coords) {
    return (
      <Card className={`p-6 bg-gray-50 ${className}`}>
        <div className="flex items-center gap-3">
          <MapPin className="w-5 h-5 text-gray-400" />
          <div>
            <p className="font-semibold text-gray-700">{city}, {state}</p>
            <p className="text-sm text-gray-500">Visualização de mapa indisponível</p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={className}
    >
      <div className="relative rounded-xl overflow-hidden shadow-lg">
        <MapContainer
          center={[coords.lat, coords.lng]}
          zoom={13}
          style={{ height: '400px', width: '100%' }}
          className="z-0"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <Marker position={[coords.lat, coords.lng]}>
            <Popup>
              <div className="p-2">
                <p className="font-bold text-gray-900">{title || city}</p>
                <p className="text-sm text-gray-600">{city}, {state}</p>
              </div>
            </Popup>
          </Marker>
          <RecenterMap lat={coords.lat} lng={coords.lng} />
        </MapContainer>

        {/* Location Info Overlay */}
        <div className="absolute top-4 left-4 z-[1000] bg-white/95 backdrop-blur-sm px-4 py-3 rounded-lg shadow-lg">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <Navigation className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="font-bold text-gray-900">{city}</p>
              <p className="text-sm text-gray-600">{state}, Brasil</p>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}