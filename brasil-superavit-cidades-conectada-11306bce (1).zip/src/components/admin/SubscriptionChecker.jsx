import React, { useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

/**
 * Componente invisível que verifica periodicamente o status das assinaturas
 * e atualiza automaticamente quando detecta mudanças nos pagamentos
 */
export default function SubscriptionChecker({ userEmail, onStatusChange }) {
  const { data: subscription, refetch } = useQuery({
    queryKey: ['subscription-status', userEmail],
    queryFn: async () => {
      const subs = await base44.entities.Subscription.filter({ 
        user_email: userEmail 
      });
      return subs[0] || null;
    },
    enabled: !!userEmail,
    refetchInterval: 60000, // Verificar a cada 1 minuto
    refetchIntervalInBackground: true
  });

  useEffect(() => {
    if (subscription && onStatusChange) {
      onStatusChange(subscription);
    }
  }, [subscription, onStatusChange]);

  // Componente invisível
  return null;
}