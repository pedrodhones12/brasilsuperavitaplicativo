import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Bell,
  TrendingUp,
  Calendar,
  Rocket,
  MessageCircle,
  Mail,
  Settings,
  CheckCircle2,
  Sparkles
} from "lucide-react";
import { motion } from "framer-motion";

export default function NotificationPreferences({ user, onUpdate }) {
  const [preferences, setPreferences] = useState({
    funding_milestones: true,
    project_deadlines: true,
    new_projects: true,
    project_updates: true,
    social_interactions: true,
    email_notifications: false,
    investment_recommendations: true,
    ...user?.notification_preferences
  });

  const queryClient = useQueryClient();

  const updatePreferencesMutation = useMutation({
    mutationFn: (newPrefs) => base44.auth.updateMe({ notification_preferences: newPrefs }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user'] });
      if (onUpdate) onUpdate();
    },
  });

  const handlePreferenceChange = (key, value) => {
    const newPrefs = { ...preferences, [key]: value };
    setPreferences(newPrefs);
    updatePreferencesMutation.mutate(newPrefs);
  };

  const notificationTypes = [
    {
      key: 'funding_milestones',
      title: 'Marcos de Financiamento',
      description: 'Receba alertas quando projetos atingirem 25%, 50%, 75% ou 100% da meta',
      icon: TrendingUp,
      color: 'from-emerald-500 to-green-600',
      badge: 'Importante'
    },
    {
      key: 'project_deadlines',
      title: 'Prazos Próximos',
      description: 'Alerta quando projetos que você investiu estão perto de terminar (7, 3, 1 dia)',
      icon: Calendar,
      color: 'from-orange-500 to-red-600',
      badge: 'Urgente'
    },
    {
      key: 'new_projects',
      title: 'Novos Projetos',
      description: 'Notificações sobre projetos que correspondem às suas preferências de investimento',
      icon: Rocket,
      color: 'from-blue-500 to-indigo-600',
      badge: 'Recomendado'
    },
    {
      key: 'investment_recommendations',
      title: 'Recomendações de IA',
      description: 'Sugestões personalizadas baseadas no seu perfil e histórico de investimentos',
      icon: Sparkles,
      color: 'from-purple-500 to-pink-600',
      badge: 'IA'
    },
    {
      key: 'project_updates',
      title: 'Atualizações de Projetos',
      description: 'Novidades e progresso dos projetos que você investiu',
      icon: Bell,
      color: 'from-cyan-500 to-blue-600',
      badge: 'Novo'
    },
    {
      key: 'social_interactions',
      title: 'Interações Sociais',
      description: 'Curtidas, comentários e menções no feed social',
      icon: MessageCircle,
      color: 'from-pink-500 to-rose-600',
      badge: 'Social'
    },
    {
      key: 'email_notifications',
      title: 'Notificações por Email',
      description: 'Receba também por email as notificações importantes',
      icon: Mail,
      color: 'from-gray-500 to-gray-600',
      badge: 'Email'
    }
  ];

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-xl bg-gradient-to-br from-emerald-50 to-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-br from-emerald-500 to-blue-500">
              <Settings className="w-6 h-6 text-white" />
            </div>
            Preferências de Notificações
          </CardTitle>
          <p className="text-sm text-gray-600 mt-2">
            Personalize quando e como você deseja ser notificado
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {notificationTypes.map((type, index) => {
            const Icon = type.icon;
            return (
              <motion.div
                key={type.key}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <div className={`p-4 rounded-xl border-2 transition-all duration-300 ${
                  preferences[type.key] 
                    ? 'bg-white border-emerald-200 shadow-md' 
                    : 'bg-gray-50 border-gray-200'
                }`}>
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${type.color} flex-shrink-0`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Label 
                          htmlFor={type.key} 
                          className="font-semibold text-gray-900 cursor-pointer"
                        >
                          {type.title}
                        </Label>
                        <Badge 
                          variant="outline" 
                          className="text-xs"
                        >
                          {type.badge}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">
                        {type.description}
                      </p>
                      <div className="flex items-center gap-2">
                        <Switch
                          id={type.key}
                          checked={preferences[type.key]}
                          onCheckedChange={(checked) => handlePreferenceChange(type.key, checked)}
                        />
                        <span className="text-xs text-gray-500">
                          {preferences[type.key] ? 'Ativado' : 'Desativado'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </CardContent>
      </Card>

      {/* Summary Card */}
      <Card className="border-none shadow-xl bg-gradient-to-br from-purple-50 to-pink-50">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500">
              <CheckCircle2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-gray-900 mb-2">Status das Notificações</h3>
              <div className="space-y-1 text-sm text-gray-600">
                <p>✅ {Object.values(preferences).filter(Boolean).length} notificações ativadas</p>
                <p>📱 Notificações no app sempre ativas</p>
                {preferences.email_notifications && (
                  <p>📧 Emails também ativados</p>
                )}
                {!preferences.email_notifications && (
                  <p>💡 Dica: Ative emails para não perder nada importante</p>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Info Card */}
      <Card className="border-none shadow-xl">
        <CardContent className="p-6">
          <div className="space-y-3 text-sm">
            <h4 className="font-semibold text-gray-900 flex items-center gap-2">
              <Bell className="w-4 h-4" />
              Como funcionam as notificações:
            </h4>
            <ul className="space-y-2 text-gray-600 ml-6">
              <li className="flex items-start gap-2">
                <span className="text-emerald-600 mt-1">•</span>
                <span><strong>Marcos de Financiamento:</strong> Notificações automáticas quando projetos atingem 25%, 50%, 75% e 100% da meta</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-orange-600 mt-1">•</span>
                <span><strong>Prazos:</strong> Alertas 7 dias, 3 dias e 1 dia antes do fim da campanha</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">•</span>
                <span><strong>Novos Projetos:</strong> Receba alertas de projetos que correspondem aos setores que você segue</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-purple-600 mt-1">•</span>
                <span><strong>IA:</strong> Algoritmo analisa seu perfil e sugere os melhores projetos para você</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}