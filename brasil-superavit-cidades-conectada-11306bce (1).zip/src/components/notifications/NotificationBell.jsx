
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Bell,
  Rocket,
  TrendingUp,
  Heart,
  MessageCircle,
  Award,
  DollarSign,
  Users,
  CheckCircle,
  X
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { useNavigate } from "react-router-dom";

const iconMap = {
  new_project: Rocket,
  funding_milestone: TrendingUp,
  project_update: Bell,
  comment: MessageCircle,
  like: Heart,
  investment_received: DollarSign,
  follow: Users,
  achievement: Award
};

const colorMap = {
  new_project: "from-blue-500 to-blue-600",
  funding_milestone: "from-emerald-500 to-emerald-600",
  project_update: "from-purple-500 to-purple-600",
  comment: "from-indigo-500 to-indigo-600",
  like: "from-red-500 to-pink-600",
  investment_received: "from-yellow-500 to-yellow-600",
  follow: "from-cyan-500 to-cyan-600",
  achievement: "from-orange-500 to-orange-600"
};

export default function NotificationBell({ user }) {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: notifications = [], refetch } = useQuery({
    queryKey: ['notifications', user?.email],
    queryFn: () => base44.entities.Notification.filter(
      { user_email: user?.email },
      '-created_date',
      15
    ),
    enabled: !!user?.email,
    refetchInterval: 120000,
    staleTime: 60000,
  });

  const unreadCount = notifications.filter(n => !n.is_read).length;

  const markAsReadMutation = useMutation({
    mutationFn: (notificationId) => 
      base44.entities.Notification.update(notificationId, { is_read: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unreadNotifications = notifications.filter(n => !n.is_read);
      await Promise.all(
        unreadNotifications.map(n => 
          base44.entities.Notification.update(n.id, { is_read: true })
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const deleteNotificationMutation = useMutation({
    mutationFn: (notificationId) => 
      base44.entities.Notification.delete(notificationId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const handleNotificationClick = (notification) => {
    if (!notification.is_read) {
      markAsReadMutation.mutate(notification.id);
    }
    if (notification.link) {
      navigate(notification.link);
      setIsOpen(false);
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative hover:bg-blue-50 transition-colors"
        >
          <Bell className="w-5 h-5 text-gray-700" />
          {unreadCount > 0 && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-1 -right-1"
            >
              <Badge className="bg-red-500 text-white px-1.5 py-0.5 text-xs min-w-[20px] h-5 flex items-center justify-center">
                {unreadCount > 9 ? '9+' : unreadCount}
              </Badge>
            </motion.div>
          )}
        </Button>
      </SheetTrigger>
      
      <SheetContent side="right" className="w-full sm:max-w-md p-0">
        <SheetHeader className="p-4 border-b bg-gradient-to-r from-blue-50 to-purple-50">
          <SheetTitle className="flex items-center justify-between">
            <span className="text-xl font-bold text-gray-900">Notificações</span>
            {unreadCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => markAllAsReadMutation.mutate()}
                className="text-xs h-8 px-3"
              >
                Marcar todas como lidas
              </Button>
            )}
          </SheetTitle>
        </SheetHeader>

        <ScrollArea className="h-[calc(100vh-80px)]">
          {notifications.length > 0 ? (
            <div className="p-2">
              <AnimatePresence>
                {notifications.map((notification) => {
                  const Icon = iconMap[notification.type] || Bell;
                  const gradient = colorMap[notification.type] || "from-gray-500 to-gray-600";
                  
                  return (
                    <motion.div
                      key={notification.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      className={`mb-2 p-3 rounded-lg cursor-pointer transition-all group relative ${
                        notification.is_read 
                          ? 'bg-white hover:bg-gray-50 border border-gray-200' 
                          : 'bg-blue-50 hover:bg-blue-100 border-2 border-blue-300'
                      }`}
                      onClick={() => handleNotificationClick(notification)}
                    >
                      <div className="flex gap-3">
                        <div className={`p-2 rounded-lg bg-gradient-to-br ${gradient} flex-shrink-0 shadow-md`}>
                          <Icon className="w-4 h-4 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm text-gray-900 mb-1 line-clamp-1">
                            {notification.title}
                          </p>
                          <p className="text-xs text-gray-600 mb-2 line-clamp-2">
                            {notification.message}
                          </p>
                          <p className="text-xs text-gray-400">
                            {format(new Date(notification.created_date), "dd MMM 'às' HH:mm", { locale: ptBR })}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 h-8 w-8"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteNotificationMutation.mutate(notification.id);
                          }}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 px-4">
              <Bell className="w-16 h-16 text-gray-300 mb-3" />
              <p className="text-gray-500 text-sm text-center">
                Nenhuma notificação ainda
              </p>
            </div>
          )}
        </ScrollArea>

        {notifications.length > 0 && (
          <div className="p-3 border-t bg-white">
            <Button
              variant="ghost"
              className="w-full text-sm"
              onClick={() => {
                navigate('/Notifications');
                setIsOpen(false);
              }}
            >
              Ver todas as notificações
            </Button>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
