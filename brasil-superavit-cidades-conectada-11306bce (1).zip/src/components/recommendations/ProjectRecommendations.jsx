
import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp,
  MapPin,
  Target,
  Sparkles,
  ExternalLink,
  Heart,
  DollarSign,
  Users,
  Calendar,
  Award,
  ArrowRight,
  Loader2
} from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

const sectorEmojis = {
  tecnologico: "🚀",
  cultural: "🎭",
  sustentabilidade: "🌱",
  infraestrutura: "🏗️",
  educacao: "📚",
  saude: "❤️",
  turismo: "✈️",
  comercio: "🛒",
  inovacao: "💡"
};

const calculateMatchScore = (project, user) => {
  let score = 0;
  let reasons = [];

  if (!user || !project) return { score: 0, reasons: [] };

  // Sector match (40 points)
  if (user.investment_sectors?.includes(project.sector)) {
    score += 40;
    reasons.push({
      icon: "🎯",
      text: `Matches your ${project.sector} sector interest`
    });
  } else if (user.preferred_sectors?.includes(project.sector)) {
    score += 30;
    reasons.push({
      icon: "⭐",
      text: `In your preferred sectors`
    });
  }

  // Investment range match (30 points)
  const userBudget = user.investment_budget_range;
  const projectMin = project.minimum_investment || 5000;
  
  if (userBudget === "5k-10k" && projectMin <= 10000) {
    score += 30;
    reasons.push({ icon: "💰", text: "Fits your investment budget" });
  } else if (userBudget === "10k-50k" && projectMin <= 50000) {
    score += 30;
    reasons.push({ icon: "💰", text: "Fits your investment budget" });
  } else if (userBudget === "50k-100k" && projectMin <= 100000) {
    score += 30;
    reasons.push({ icon: "💰", text: "Fits your investment budget" });
  } else if (userBudget && projectMin <= 500000) {
    score += 20;
  }

  // Project status and progress (20 points)
  const progress = (project.current_funding / project.funding_goal) * 100;
  if (progress > 20 && progress < 80) {
    score += 20;
    reasons.push({ icon: "📈", text: "Optimal investment timing" });
  } else if (progress < 20) {
    score += 15;
    reasons.push({ icon: "🌟", text: "Early-stage opportunity" });
  }

  // Experience level match (10 points)
  if (user.investment_experience === "expert" && project.funding_goal > 100000) {
    score += 10;
    reasons.push({ icon: "🏆", text: "Matches your expertise level" });
  } else if (user.investment_experience === "iniciante" && project.funding_goal <= 50000) {
    score += 10;
    reasons.push({ icon: "🎓", text: "Good starter project" });
  }

  return { score, reasons };
};

const ProjectCard = React.memo(({ project, index, onGetAIInsight, aiInsight, loadingInsight }) => {
  const progress = (project.current_funding / project.funding_goal) * 100;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
    >
      <Card className="border-none shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group">
        <div className={`h-2 bg-gradient-to-r ${
          project.matchScore >= 80 ? 'from-emerald-500 to-green-500' :
          project.matchScore >= 60 ? 'from-blue-500 to-cyan-500' :
          'from-purple-500 to-pink-500'
        }`} />
        
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-3xl">{sectorEmojis[project.sector]}</span>
                <Badge className={`${
                  project.matchScore >= 80 ? 'bg-emerald-100 text-emerald-700' :
                  project.matchScore >= 60 ? 'bg-blue-100 text-blue-700' :
                  'bg-purple-100 text-purple-700'
                }`}>
                  {project.matchScore}% Match
                </Badge>
                {index === 0 && project.matchScore >= 80 && (
                  <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white border-none">
                    <Award className="w-3 h-3 mr-1" />
                    Best Match
                  </Badge>
                )}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-1 group-hover:text-blue-600 transition-colors line-clamp-2">
                {project.title}
              </h3>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {project.city}/{project.state}
                </span>
                <span className="flex items-center gap-1">
                  <Users className="w-4 h-4" />
                  {project.investors_count || 0}
                </span>
              </div>
            </div>
          </div>

          {project.matchReasons.length > 0 && (
            <div className="mb-4 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg">
              <p className="text-xs font-semibold text-gray-700 mb-2">Why this matches you:</p>
              <div className="space-y-1">
                {project.matchReasons.slice(0, 3).map((reason, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                    <span>{reason.icon}</span>
                    <span>{reason.text}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {aiInsight && (
            <div className="mb-4 p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg border border-indigo-200">
              <div className="flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600 mt-1 flex-shrink-0" />
                <div>
                  <p className="text-xs font-semibold text-indigo-900 mb-1">AI Investment Insight</p>
                  <p className="text-sm text-gray-700 leading-relaxed">{aiInsight}</p>
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-3 gap-4 mb-4">
            <div>
              <p className="text-xs text-gray-500 mb-1">Goal</p>
              <p className="text-sm font-bold text-gray-900">
                R$ {(project.funding_goal / 1000).toFixed(0)}k
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-1">Raised</p>
              <p className="text-sm font-bold text-emerald-600">
                R$ {(project.current_funding / 1000).toFixed(0)}k
              </p>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-1">Min. Invest</p>
              <p className="text-sm font-bold text-blue-600">
                R$ {((project.minimum_investment || 5000) / 1000).toFixed(0)}k
              </p>
            </div>
          </div>

          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs text-gray-600">Progress</span>
              <span className="text-xs font-semibold text-gray-900">{progress.toFixed(0)}%</span>
            </div>
            <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                style={{ width: `${Math.min(progress, 100)}%` }}
                className="h-full bg-gradient-to-r from-emerald-500 to-blue-500"
              />
            </div>
          </div>

          <div className="flex gap-3">
            <Link to={createPageUrl(`Invest?project=${project.id}`)} className="flex-1">
              <Button className="w-full bg-gradient-to-r from-emerald-500 to-blue-500 hover:from-emerald-600 hover:to-blue-600">
                <ExternalLink className="w-4 h-4 mr-2" />
                View Details
              </Button>
            </Link>
            
            {!aiInsight && !loadingInsight && (
              <Button
                variant="outline"
                onClick={() => onGetAIInsight(project)}
                className="px-4"
              >
                <Sparkles className="w-4 h-4" />
              </Button>
            )}
            
            {loadingInsight && (
              <Button variant="outline" disabled className="px-4">
                <Loader2 className="w-4 h-4 animate-spin" />
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
});

ProjectCard.displayName = 'ProjectCard';

export default function ProjectRecommendations({ user, limit = 3 }) {
  const [aiInsights, setAiInsights] = useState({});
  const [loadingInsights, setLoadingInsights] = useState({});

  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['active-projects-recommendations'],
    queryFn: async () => {
      return await base44.entities.Project.filter(
        { status: 'ativa' },
        '-created_date',
        8
      );
    },
    staleTime: 15 * 60 * 1000,
    cacheTime: 20 * 60 * 1000,
  });

  const recommendedProjects = useMemo(() => {
    if (!user || !projects.length) return [];

    const projectsWithScores = projects.map(project => {
      const match = calculateMatchScore(project, user);
      return {
        ...project,
        matchScore: match.score,
        matchReasons: match.reasons
      };
    }).sort((a, b) => b.matchScore - a.matchScore);

    return projectsWithScores.slice(0, limit);
  }, [projects, user, limit]);

  const getAIInsights = async (project) => {
    setLoadingInsights(prev => ({ ...prev, [project.id]: true }));
    
    try {
      const prompt = `As an investment advisor, analyze this project briefly:

Project: ${project.title}
Sector: ${project.sector}
Goal: R$ ${project.funding_goal?.toLocaleString('pt-BR')}
Current: R$ ${project.current_funding?.toLocaleString('pt-BR')}

Provide 2 sentences: 1) Why good match, 2) Key advantage. Be concise.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            insight: { type: "string" }
          }
        }
      });

      setAiInsights(prev => ({
        ...prev,
        [project.id]: response.insight
      }));
    } catch (error) {
      console.error("Error getting AI insights:", error);
    } finally {
      setLoadingInsights(prev => ({ ...prev, [project.id]: false }));
    }
  };

  if (isLoading) {
    return (
      <Card className="border-none shadow-xl">
        <CardContent className="p-12 text-center">
          <Loader2 className="w-12 h-12 text-blue-600 mx-auto animate-spin mb-4" />
          <p className="text-gray-600">Finding matches...</p>
        </CardContent>
      </Card>
    );
  }

  if (recommendedProjects.length === 0) {
    return (
      <Card className="border-none shadow-xl bg-gradient-to-br from-purple-50 to-blue-50">
        <CardContent className="p-8 text-center">
          <Sparkles className="w-12 h-12 text-purple-600 mx-auto mb-4" />
          <h3 className="font-bold text-xl text-gray-900 mb-2">
            Complete Your Profile
          </h3>
          <p className="text-gray-600 mb-4">
            Add investment preferences for personalized recommendations
          </p>
          <Link to={createPageUrl("UserProfile")}>
            <Button className="bg-gradient-to-r from-purple-500 to-blue-500">
              Complete Profile
            </Button>
          </Link>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-gradient-to-br from-purple-100 to-blue-100">
            <Sparkles className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">AI Recommendations</h2>
            <p className="text-sm text-gray-600">Perfect matches for you</p>
          </div>
        </div>
        <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white border-none">
          {recommendedProjects.length} Matches
        </Badge>
      </div>

      <div className="grid gap-6">
        {recommendedProjects.map((project, index) => (
          <ProjectCard
            key={project.id}
            project={project}
            index={index}
            onGetAIInsight={getAIInsights}
            aiInsight={aiInsights[project.id]}
            loadingInsight={loadingInsights[project.id]}
          />
        ))}
      </div>

      {recommendedProjects.length > 0 && (
        <div className="text-center">
          <Link to={createPageUrl("Projects")}>
            <Button variant="outline" size="lg">
              Explore All Projects
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
